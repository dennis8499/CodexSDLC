# 修正輪登記

修正輪從 1 起算。正常輪用完且最新程式碼審查仍為 FAIL，依每項必修 ID 請使用者裁定是否接受風險。

啟用的 Codex hook 會在正式送出前登記。無 hooks 時，把同一份 handoff 透過 stdin 交給 handoff-lint.ps1 -SelfCheck -Register，成功後才送出。預覽使用 -SelfCheck，可加 -Json 取得結構化結果。