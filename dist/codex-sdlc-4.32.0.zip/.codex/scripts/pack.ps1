# pack.ps1
# 維護者用：把工具那半打成一份可發佈的 zip，附 manifest.json（每個檔一個 sha256）。
#
# manifest 是整條升級路徑的地基：沒有它，update 分不出「這個檔跟上一版一樣」與
# 「使用者改過」—— 而 README 本來就叫使用者去改 AGENTS.md，所以「改過」是常態不是例外。
#
# 打包前一定跑 agent-lint 與 fixture 測試，紅燈就不出貨：一份設定不一致的發佈物，
# 症狀會落在**別人的**專案裡，而且通常是靜默的。
#
# 打包時會把 agent toml 的 SDLC-TUNING 區塊清掉 —— 發佈物一律是原廠狀態。
# 維護者在自己 repo 跑過 apply 之後那些區塊會留在工作區，跟著出貨就等於把
# 維護者的調校偷渡進所有人的專案。
#
# repo 裡有 vscode-extension/ 時，出貨前也會 npm ci ＋ build ＋ 跑它自己的測試，產出 dist/codex-sdlc-{version}.vsix，
# 跟 zip 並排、在發佈頁上是各自的附件。zip 預設**不含** vsix：vsix 內附整份 payload，塞進 zip 等於同一份工作流帶兩次，
# 而且升級工作流的人多半早就裝好 extension 了。要 zip 裡帶 editor/（給 install -WithEditor 用）就加 -VsixInZip。
# 紅燈一樣不出貨。vsix **不進 manifest**：它不是工具那半、也不是使用者那半，是每台機器一份的編輯器外掛，
# 升級邏輯管不到、也不該管（理由見 docs/vscode-extension-plan.md 事實 1）。
#
# 從 4.10.0 起 vsix 還會**內附一份 payload**（vscode-extension/payload/），讓裝了 extension 的人在一個
# 還沒裝工作流的資料夾裡直接安裝。內附的那一份就是這一次 staging 算出來的那一份 —— 同一次 pack、
# 同一份 manifest，所以「兩份 payload 分岔」在構造上不可能發生；複製完還會從產出的 vsix 裡讀回版本再驗一次。
# payload 只在打包期間存在於工作區，finally 一定刪掉，而且不進版控。
#
# 給了 -NpmRegistry 時，另外把同一個 vsix 包成一個 npm 套件（dist/codex-sdlc-{version}.tgz），給私有 npm registry
# （例如 Nexus npm hosted）配 Private Extension Manager 用。pack 只產生、不 publish —— 發佈是對外的動作，留給維護者：
#   npm publish dist/codex-sdlc-{version}.tgz
# 套件的 package.json 是另外產生的，不改 vscode-extension/package.json（它的 private:true 正是防誤發的那道鎖）。
#
# Exit: 0 = 打包完成；2 = 驗證未過或參數錯誤。

[CmdletBinding()]
param(
    [string]$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path,
    [string]$OutDir = 'dist',
    [switch]$SkipTests,
    [switch]$SkipExtension,              # 不打包 VS Code extension（沒有 Node.js 的機器、或這一版不帶編輯器那一層）
    [switch]$VsixInZip,                  # vsix 也放進 zip 的 editor/（install -WithEditor 才拿得到）；預設只放在 zip 旁邊
    [string]$NpmRegistry,                # 另外產生 vsix 的 npm 發佈包，publishConfig.registry 指向這裡（例如 Nexus npm hosted）
    [switch]$Json
)

$ErrorActionPreference = 'Stop'

# ---- 標準 I/O：被程式呼叫時一律 UTF-8 ----
# Codex 送進來的 payload 是 UTF-8、也用 UTF-8 解讀 hook 的輸出；Windows 上 [Console] 的編碼卻跟著 console 的
# code page 走（zh-TW 是 cp950；並行的 hook 共用同一個 console，偶爾連輸出端也是）。Codex 0.154.0 實測的後果：
# 一份 743 字、meta 完整的中文 handoff 被解成 1772 字、JSON 解析失敗、抓不到 mode —— **每一次 spawn 都被擋**；
# 阻斷理由的中文到模型手上是亂碼。只在被重導向時才換：人在終端機跑的時候照 console 的 code page 顯示。
# 同一段在每一支會被程式呼叫的腳本裡各有一份（清單由 test-hook-payload.ps1 守住）。
$Utf8NoBom = [Text.UTF8Encoding]::new($false)
if ([Console]::IsOutputRedirected) { $w = [IO.StreamWriter]::new([Console]::OpenStandardOutput(), $Utf8NoBom); $w.AutoFlush = $true; [Console]::SetOut($w) }
if ([Console]::IsErrorRedirected)  { $w = [IO.StreamWriter]::new([Console]::OpenStandardError(),  $Utf8NoBom); $w.AutoFlush = $true; [Console]::SetError($w) }
function Read-StdinUtf8 {
    if ([Console]::IsInputRedirected) { return [IO.StreamReader]::new([Console]::OpenStandardInput(), $Utf8NoBom).ReadToEnd() }
    return [Console]::In.ReadToEnd()
}

$ToolRoots  = @('.codex', '.agents')
$ToolFiles  = @('AGENTS.md')
$VersionRel = '.codex/bdd-workflow/bdd-workflow-version.json'
$ManifestRel = '.codex/bdd-workflow/manifest.json'
$ExtensionDir = 'vscode-extension'
$TuneBegin  = '# SDLC-TUNING:BEGIN'
$TuneEnd    = '# SDLC-TUNING:END'

function Fail([string]$m) { [Console]::Error.WriteLine("[pack] $m"); exit 2 }
function Say([string]$m)  { if (-not $Json) { Write-Output $m } }

# 子行程（agent-lint、fixture 測試、npm、node）被重導向時寫的是 UTF-8，PowerShell 卻拿 console 的 code page 解碼
# —— 在 cp950 的終端機上，中文的測試名稱與錯誤訊息全是亂碼，紅燈了也看不懂紅在哪。所以解碼期間暫時換成 UTF-8。
function Invoke-Utf8([scriptblock]$block) {
    $prev = $null
    try { $prev = [Console]::OutputEncoding; [Console]::OutputEncoding = $Utf8NoBom } catch { }
    try { & $block } finally { if ($prev) { try { [Console]::OutputEncoding = $prev } catch { } } }
}

$Root = (Resolve-Path $Root).Path
$verFile = Join-Path $Root $VersionRel
if (-not (Test-Path $verFile)) { Fail "找不到 $VersionRel" }
$ver = Get-Content $verFile -Raw -Encoding UTF8 | ConvertFrom-Json
$version = [string]$ver.'contract-version'
if ($version -notmatch '^\d+\.\d+\.\d+$') { Fail "contract-version 不是 semver：$version" }

# npm 發佈包的參數先驗：錯了不該讓維護者等完 lint、測試、vsix 才知道。
# registry 是必填而不是發佈時再給 —— 套件名是沒有 scope 的 codex-sdlc，publishConfig 沒寫死的話，
# 一句 npm publish 就會把內附整份 payload 的 vsix 發到公開的 npmjs.org，而且收不回來。
if ($NpmRegistry) {
    if ($SkipExtension) { Fail '-NpmRegistry 要包的是 vsix，跟 -SkipExtension 不能一起用。' }
    if (-not (Test-Path (Join-Path $Root "$ExtensionDir/package.json"))) { Fail "-NpmRegistry 要包的是 vsix，但這個 repo 沒有 $ExtensionDir/。" }
    if ($NpmRegistry -notmatch '^https?://[^\s/]+') { Fail "-NpmRegistry 要是 registry 的網址（例如 https://nexus.example/repository/npm-hosted/），收到：$NpmRegistry" }
    if (-not $NpmRegistry.EndsWith('/')) { $NpmRegistry += '/' }
}

# 來源網址跟著發佈物走 —— install 會把它寫進每個消費端的 sdlc.config.json。
# 沒設不阻斷（第一版還沒推上去很正常），但一定要喊：沒有它，那些專案永遠不會
# 有人告訴他們有新版，而症狀是零 —— 畫面上一切正常。
$srcUrl = [string]$ver.source
if (-not $srcUrl) {
    [Console]::Error.WriteLine("[pack] 版本檔沒有設 `source` —— 這一版裝出去的專案不會收到更新通知（check-update 會直接說查不到）。推上 repo 之後把網址填進 $VersionRel 的 `source`。")
} elseif ($srcUrl -match '(?i)OWNER|EXAMPLE|<') {
    [Console]::Error.WriteLine("[pack] 版本檔的 `source` 看起來還是預留位置（$srcUrl）—— 換成真的網址，否則裝出去的專案會拿到一個指不到任何地方的來源。")
} else {
    # 寫法要是 check-update 認得的（跟 set 驗的是同一條：schema 的 pattern，檢查 14 把它綁在 sdlc.ps1 的常數上）。
    # 認不得的來源一樣零症狀 —— 每個裝出去的專案都拿到一個永遠查不到的網址；而這裡改一行就好，所以擋。
    $schemaFile = Join-Path $Root '.codex/bdd-workflow/sdlc.config.schema.json'
    $srcPat = if (Test-Path $schemaFile) { [string](Get-Content $schemaFile -Raw -Encoding UTF8 | ConvertFrom-Json).properties.update.properties.source.pattern } else { '' }
    if ($srcPat -and $srcUrl -notmatch $srcPat) {
        Fail "版本檔的 `source` 寫法認不得（$srcUrl）—— github.com／gitlab.com 直接寫網址，自架的寫成 gitea:https://…、gitlab:https://… 或 github:https://…（GitHub Enterprise）。"
    }
}

# guidelines/README.md 的雜湊清單要跟出貨的那份對得上：update 只換「跟歷來某一版原廠一字不差」的 README，
# 這一版的 current 沒填對，下一版就認不出這一版裝出去的 README 是原廠的 —— 它會永遠停在這一版，而且沒有症狀。
$readmeFile = Join-Path $Root 'guidelines/README.md'
$stockFile  = Join-Path $Root '.codex/bdd-workflow/guidelines-readme-stock.json'
# 只核對指標頁那一系（內文指向 guidelines-guide.md）：在已安裝的專案裡跑 pack 時，README 是團隊自己的，不該擋。
$rmText = if (Test-Path $readmeFile) { [IO.File]::ReadAllText($readmeFile, [Text.UTF8Encoding]::new($false)).TrimStart([char]0xFEFF) -replace "`r`n", "`n" } else { '' }
if ($rmText -match 'guidelines-guide\.md' -and (Test-Path $stockFile)) {
    $sha = [Security.Cryptography.SHA256]::Create()
    $rmSha = -join ($sha.ComputeHash([Text.UTF8Encoding]::new($false).GetBytes($rmText)) | ForEach-Object { $_.ToString('x2') })
    $sha.Dispose()
    $stock = Get-Content $stockFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($rmSha -ne [string]$stock.current) {
        Fail "guidelines/README.md 改過，但 guidelines-readme-stock.json 的 current 沒跟上 —— 把舊的 current 移進 previous，current 填 $rmSha。"
    }
}

# ---- 出貨前驗證 ----
Push-Location $Root
try {
    # -CodexHome ''：檢查 15 不看維護者自己 ~/.codex/config.toml 的 project_doc_max_bytes —— 出貨的 AGENTS.md 要在預設上限下讀得完。
    Invoke-Utf8 { & pwsh -NoProfile -ExecutionPolicy Bypass -File '.codex/scripts/agent-lint.ps1' -CodexHome '' | ForEach-Object { Say "  $_" } }
    if ($LASTEXITCODE -ne 0) { Fail 'agent-lint 紅燈 —— 不出貨。設定不一致的症狀會落在別人的專案裡。' }
    if (-not $SkipTests) {
        Invoke-Utf8 { & pwsh -NoProfile -ExecutionPolicy Bypass -File '.codex/scripts/tests/run-tests.ps1' | ForEach-Object { Say "  $_" } }
        if ($LASTEXITCODE -ne 0) { Fail 'fixture 測試紅燈 —— 不出貨。' }
    }
} finally { Pop-Location }

# ---- VS Code extension：先確認建得起來 ----
# 真正的建置往後挪到 staging 之後（見「VS Code extension（payload 已就緒）」）——
# 從這一版起 vsix 要把**這一次打包出來的 payload** 一起收進去，所以它得等 staging 算完。
# 這裡只先擋掉「連 node 都沒有」：那種失敗不該讓使用者先等完整套 staging。
$vsix = $null
$extBuild = $null
$extRoot = Join-Path $Root $ExtensionDir
$buildExtension = (Test-Path (Join-Path $extRoot 'package.json')) -and -not $SkipExtension
if ($buildExtension) {
    foreach ($tool in @('node', 'npm')) {
        if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) {
            Fail "要打包 VS Code extension 需要 $tool（Node.js）。這一版不帶編輯器那一層的話，加 -SkipExtension。"
        }
    }
} elseif ($SkipExtension) {
    Say 'VS Code extension：-SkipExtension，這一版不產生 vsix、也不會內附 payload。'
}

# ---- 收集檔案 ----
$files = @()
foreach ($d in $ToolRoots) {
    $p = Join-Path $Root $d
    if (Test-Path $p) {
        $files += @(Get-ChildItem $p -Recurse -File | ForEach-Object {
            ($_.FullName.Substring($Root.Length) -replace '\\', '/').TrimStart('/')
        })
    }
}
foreach ($f in $ToolFiles) { if (Test-Path (Join-Path $Root $f)) { $files += $f } }
$files = @($files | Where-Object { $_ -ne $ManifestRel } | Sort-Object -Unique)
if (-not $files) { Fail '沒有收集到任何檔案。' }

# ---- staging（絕不動工作區）----
$stage = Join-Path ([IO.Path]::GetTempPath()) ("sdlc-pack-" + [guid]::NewGuid().ToString('N').Substring(0, 8))
New-Item -ItemType Directory -Path $stage -Force | Out-Null

try {
    foreach ($rel in $files) {
        $dst = Join-Path $stage $rel
        $dir = Split-Path $dst -Parent
        if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        Copy-Item (Join-Path $Root $rel) $dst -Force
    }

    # guidelines/ 骨架跟著出貨，但**不進 manifest**。
    # manifest 是「這些檔是工具的、升級時我負責」的清單，而 guidelines/ 是使用者的 ——
    # 列進去就等於宣稱工具擁有它，下一次升級會開始比對、報告、甚至覆蓋團隊自己的規範。
    # install 只在目標沒有 guidelines/ 時才放這份骨架。
    $skelCount = 0
    $gsrc = Join-Path $Root 'guidelines'
    if (Test-Path $gsrc) {
        Copy-Item $gsrc (Join-Path $stage 'guidelines') -Recurse -Force
        $skelCount = @(Get-ChildItem (Join-Path $stage 'guidelines') -Recurse -File).Count
    }

    # 發佈物一律原廠狀態：清掉 SDLC-TUNING 區塊。
    $stripped = @()
    foreach ($t in @(Get-ChildItem (Join-Path $stage '.codex/agents') -Filter *.toml -File -ErrorAction SilentlyContinue)) {
        $text = [IO.File]::ReadAllText($t.FullName)
        $pattern = "(?s)" + [regex]::Escape($TuneBegin) + ".*?" + [regex]::Escape($TuneEnd) + "\r?\n?"
        if ($text -match $pattern) {
            [IO.File]::WriteAllText($t.FullName, ([regex]::Replace($text, $pattern, '')), $Utf8NoBom)
            $stripped += $t.Name
        }
    }
    if ($stripped.Count -gt 0) { Say "清掉 SDLC-TUNING 區塊：$($stripped -join '、')（發佈物一律原廠狀態）" }

    # ---- manifest ----
    $sha = [Security.Cryptography.SHA256]::Create()
    $manifest = [ordered]@{}
    try {
        foreach ($rel in $files) {
            $bytes = [IO.File]::ReadAllBytes((Join-Path $stage $rel))
            $manifest[$rel] = -join ($sha.ComputeHash($bytes) | ForEach-Object { $_.ToString('x2') })
        }
    } finally { $sha.Dispose() }

    $mPath = Join-Path $stage $ManifestRel
    $mDir = Split-Path $mPath -Parent
    if (-not (Test-Path $mDir)) { New-Item -ItemType Directory -Path $mDir -Force | Out-Null }
    [IO.File]::WriteAllText($mPath, ((([ordered]@{
        'contract-version'      = $version
        'min-compatible-version' = [string]$ver.'min-compatible-version'
        'packed-at'             = (Get-Date).ToString('o')
        'file_count'            = $files.Count
        'files'                 = $manifest
    }) | ConvertTo-Json -Depth 6) + "`n"), $Utf8NoBom)

    # ---- VS Code extension（payload 已就緒）----
    #
    # vsix 內附一份 payload：裝了 extension 的人在一個**還沒裝工作流**的資料夾裡就能直接安裝，
    # 不必先去找 zip、解壓、記得 -Target。「兩份 payload 會靜默分岔」是真的風險，所以這裡把它
    # 壓成一次建置的事實 —— 內附的那一份**就是**上面 staging 算出來的那一份（同一次 pack、同一份
    # manifest、SDLC-TUNING 已經清過），複製完再從產出的 vsix 裡讀回版本驗一次。
    #
    # payload 只在打包期間存在於工作區（finally 一定刪掉），而且不進版控（.gitignore）——
    # repo 裡長期躺著第二份 .codex/ 才是真正會分岔的那個形狀。
    # editor/ 不進 payload：vsix 裡不該再有一個 vsix（而且它是每台機器一份的東西，見上面的理由）。
    if ($buildExtension) {
        $payloadDir = Join-Path $extRoot 'payload'
        $extBuild = Join-Path ([IO.Path]::GetTempPath()) ("sdlc-vsix-" + [guid]::NewGuid().ToString('N').Substring(0, 8))
        New-Item -ItemType Directory -Path $extBuild -Force | Out-Null
        if (Test-Path $payloadDir) { Remove-Item $payloadDir -Recurse -Force }
        New-Item -ItemType Directory -Path $payloadDir -Force | Out-Null
        Copy-Item (Join-Path $stage '*') $payloadDir -Recurse -Force
        Say "VS Code extension：內附 payload $version（$($files.Count) 個工具檔）"

        Push-Location $extRoot
        try {
            Say 'VS Code extension：npm ci'
            Invoke-Utf8 { & npm ci --no-audit --no-fund 2>&1 | ForEach-Object { Say "  $_" } }
            if ($LASTEXITCODE -ne 0) { Fail 'extension 的 npm ci 失敗 —— 不出貨。' }
            Invoke-Utf8 { & npm run build 2>&1 | ForEach-Object { Say "  $_" } }
            if ($LASTEXITCODE -ne 0) { Fail 'extension 編譯失敗 —— 不出貨。' }
            if (-not $SkipTests) {
                # test:all = 單元＋整合。整合那一半才是真的拿這一版的 sdlc.ps1 對 -Json 合約 —— 出貨前不能省。
                Invoke-Utf8 { & npm run test:all 2>&1 | Where-Object { $_ -match '^(not ok|# (tests|pass|fail))' } | ForEach-Object { Say "  $_" } }
                if ($LASTEXITCODE -ne 0) { Fail 'extension 測試紅燈 —— 不出貨。它讀的是 sdlc.ps1 的 -Json，紅在這裡通常代表兩邊的合約分岔了。' }
            }
            $vsix = Join-Path $extBuild "codex-sdlc-$version.vsix"
            Invoke-Utf8 { & npx --no-install vsce package --skip-license --allow-missing-repository --out $vsix 2>&1 | ForEach-Object { Say "  $_" } }
            if ($LASTEXITCODE -ne 0 -or -not (Test-Path $vsix)) { Fail 'vsce package 失敗 —— 不出貨。' }
        } finally { Pop-Location }

        # 版本號由 agent-lint 檢查 11 擋（package.json 必須等於 contract-version，上面已經跑過）；
        # 這裡再從**產出的 vsix 本身**讀一次 —— 建置腳本若改寫了版本號，出貨的是 vsix，不是 package.json。
        # 內附的 payload 也一樣：vsix 裡那份版本檔才是使用者真的會裝出去的東西。
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $vpkg = $null; $vpayload = $null
        $zipRead = [IO.Compression.ZipFile]::OpenRead($vsix)
        try {
            foreach ($want in @('extension/package.json', "extension/payload/$VersionRel")) {
                $entry = $zipRead.Entries | Where-Object { $_.FullName -eq $want } | Select-Object -First 1
                if (-not $entry) { Fail "vsix 裡沒有 $want —— 產物是壞的，不出貨。" }
                $reader = [IO.StreamReader]::new($entry.Open(), $Utf8NoBom)
                try { $parsed = $reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose() }
                if ($want -eq 'extension/package.json') { $vpkg = $parsed } else { $vpayload = $parsed }
            }
        } finally { $zipRead.Dispose() }
        if ([string]$vpkg.version -ne $version) {
            Fail "vsix 的版本是 $($vpkg.version)，contract-version 是 $version —— 對不上就不出貨（doctor 的相容性判斷會建立在錯的數字上）。"
        }
        if ([string]$vpayload.'contract-version' -ne $version) {
            Fail "vsix 內附的 payload 是 $($vpayload.'contract-version')，這一版是 $version —— 對不上就不出貨（它會在別人的空資料夾裡裝出錯的一版，而且是靜默的）。"
        }
        if ($null -eq $vpkg.codexSdlc -or $null -eq $vpkg.codexSdlc.jsonSchema) {
            Fail 'vsix 的 package.json 沒有宣告 codexSdlc.jsonSchema —— doctor 判斷不了它讀不讀得懂這一版的 -Json，不出貨。'
        }
        Say "VS Code extension：codex-sdlc-$version.vsix（-Json schema $($vpkg.codexSdlc.jsonSchema)，內附 payload $version）"

        # -VsixInZip：vsix 也放進 zip，但**不進 manifest**（$files 在上面就算完了，這裡放進 stage 的檔不會被列進去）。
        # install 的複製迴圈只走工具那半，看不到 editor/；只有 -WithEditor 才會拿它去裝。
        if ($VsixInZip) {
            New-Item -ItemType Directory -Path (Join-Path $stage 'editor') -Force | Out-Null
            Copy-Item $vsix (Join-Path $stage "editor/codex-sdlc-$version.vsix") -Force
        }
    }

    # ---- zip ----
    $outAbs = if ([IO.Path]::IsPathRooted($OutDir)) { $OutDir } else { Join-Path $Root $OutDir }
    if (-not (Test-Path $outAbs)) { New-Item -ItemType Directory -Path $outAbs -Force | Out-Null }
    $zip = Join-Path $outAbs "codex-sdlc-$version.zip"
    if (Test-Path $zip) { Remove-Item $zip -Force }
    Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip -CompressionLevel Optimal
    $vsixOut = $null
    if ($vsix) {
        $vsixOut = Join-Path $outAbs "codex-sdlc-$version.vsix"
        Copy-Item $vsix $vsixOut -Force
    }

    # ---- npm 發佈包（-NpmRegistry）----
    # Private Extension Manager 的格式：一般的 npm 套件，帶 publisher／engines.vscode，files 裡第一個 .vsix 就是它要裝的。
    # 欄位一律從**產出的 vsix 本身**的 package.json 帶 —— 版本、publisher 跟真的會被裝起來的那份一致，不會手填出岔。
    # README 一起放：manager 的詳細頁讀的是 npm 套件裡的 README，不是 vsix 裡的。
    $npmTgz = $null
    if ($NpmRegistry) {
        $npmStage = Join-Path $extBuild 'npm'
        New-Item -ItemType Directory -Path $npmStage -Force | Out-Null
        $vsixName = "codex-sdlc-$version.vsix"
        Copy-Item $vsix (Join-Path $npmStage $vsixName) -Force
        $npmFiles = @($vsixName)
        $readme = Join-Path $extRoot 'README.md'
        if (Test-Path $readme) { Copy-Item $readme (Join-Path $npmStage 'README.md') -Force; $npmFiles += 'README.md' }
        $npmPkg = [ordered]@{
            name          = [string]$vpkg.name
            displayName   = [string]$vpkg.displayName
            description   = [string]$vpkg.description
            version       = $version
            publisher     = [string]$vpkg.publisher
            engines       = [ordered]@{ vscode = [string]$vpkg.engines.vscode }
            files         = $npmFiles
            publishConfig = [ordered]@{ registry = $NpmRegistry }
        }
        if ($vpkg.extensionKind) { $npmPkg.extensionKind = @($vpkg.extensionKind) }   # remote 工作區裝在哪一邊，manager 靠它判斷
        [IO.File]::WriteAllText((Join-Path $npmStage 'package.json'), (($npmPkg | ConvertTo-Json -Depth 4) + "`n"), $Utf8NoBom)

        $npmTgz = Join-Path $outAbs "$($npmPkg.name)-$version.tgz"
        if (Test-Path $npmTgz) { Remove-Item $npmTgz -Force }
        Push-Location $npmStage
        try {
            Invoke-Utf8 { & npm pack --pack-destination $outAbs 2>&1 | ForEach-Object { Say "  $_" } }
            if ($LASTEXITCODE -ne 0 -or -not (Test-Path $npmTgz)) { Fail "npm pack 失敗，沒產出 $(Split-Path $npmTgz -Leaf)。" }
        } finally { Pop-Location }
    }

    if ($Json) {
        [pscustomobject]@{ version = $version; zip = $zip; file_count = $files.Count; vsix = $vsixOut; vsix_in_zip = [bool]($vsix -and $VsixInZip); npm = $npmTgz } | ConvertTo-Json -Compress
    } else {
        Say ''
        Say "打包完成：$zip"
        Say "版本 $version，$($files.Count) 個工具檔（manifest 已寫入 $ManifestRel）$(if ($skelCount) { "，另附 $skelCount 個 guidelines/ 骨架檔（不在 manifest 內 —— 那是使用者的）" })$(if ($vsix -and $VsixInZip) { "，以及 editor/codex-sdlc-$version.vsix（不在 manifest 內 —— 那是每台機器一份的編輯器外掛）" })"
        if ($vsixOut -and -not $VsixInZip) { Say "VS Code extension：$vsixOut（不在 zip 裡；發佈時另外上傳成一個附件）" }
        Say ''
        Say '使用者的安裝方式（解壓到別處，不要直接蓋在專案上）：'
        Say '  pwsh <解壓目錄>/.codex/scripts/sdlc.ps1 install -Target <他的專案>'
        if ($vsix -and $VsixInZip) { Say '  （要順便裝 VS Code extension 就加 -WithEditor）' }
        elseif ($vsixOut) { Say "  VS Code extension 另外裝：code --install-extension codex-sdlc-$version.vsix（裝好後，其他專案在活動列按「安裝到這個工作區」就好，不必再找 zip）" }
        if ($npmTgz) {
            Say ''
            Say "npm 發佈包：$npmTgz（publishConfig.registry = $NpmRegistry）"
            Say "發到私有 registry（pack 不代發）：npm login --registry=$NpmRegistry，然後 npm publish `"$npmTgz`""
        }
    }
} finally {
    Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
    if ($extBuild) { Remove-Item $extBuild -Recurse -Force -ErrorAction SilentlyContinue }
    # payload 是打包期間才存在於工作區的東西 —— 紅燈退出也要收乾淨，留著的話下一次 pack 會把
    # 上一版的 payload 再打包一次，而症狀是「裝出來的流程比發佈物舊」，完全靜默。
    Remove-Item (Join-Path $extRoot 'payload') -Recurse -Force -ErrorAction SilentlyContinue
}
exit 0
