---
name: api-contract-design
version: 1.0.0
description: 外部 API 契約設計。用已定的 Gherkin、業務規則與例子寫 OpenAPI 3.1 草案，供 ATDD／TDD 與契約測試。
---

# API 契約設計

在設計階段產出供 ATDD／TDD 對齊和後續契約測試用的草案。

## 使用時機

- Gherkin 定稿、domain glossary、example map 已就緒，功能有對外 API 介面。
- 無對外 API（純 UI／純函式庫／純批次）時**不要產出契約** —— 在回傳裡說一句「無對外介面，不需契約」即可。

## 輸入

- Gherkin final、domain summary、glossary、business rules、examples、candidate model。
- API style / auth 假設、既有 API 慣例或 coding-standards。
- （若有）DB introspection 報告、既有 endpoint 慣例。

## 指引

1. 預設 REST JSON over HTTPS，除非使用者指定其他風格。
2. 以業務資源與命令設計 path；命名對齊 domain language。
3. **不暴露** DB 資料表/欄位名稱，除非是官方業務術語（並與 DLP 交叉檢查）。
4. 每個 operation 定義 `operationId`、summary、description、parameters、request body、responses、examples。
5. 所有 request/response/DTO/error body 定義於 `components.schemas`。
6. 已知驗證時定義 `components.securitySchemes` 與 operation/root `security`。
7. 使用一致的 error schema。
8. 每個 endpoint 至少對映 1 條 business rule 與 1 個 example（追溯）。
9. 當 API style / auth / pagination / sorting / filtering / id 格式未指定時記錄 assumption。

## 狀態碼預設

- `200` 讀取/更新/動作成功且有回應 body；`201` 建立成功；`204` 動作成功無 body。
- `400` 語法/驗證錯誤；`401` 未認證；`403` 未授權；`404` 不存在。
- `409` 業務/狀態衝突；`422` 語意業務驗證錯誤（若 API style 偏好）；`500` 僅限非預期伺服器錯誤。

## 回傳與落檔

- **單獨呼叫**：用下列回傳範本。`## design/api-contract.yaml` 是草案回傳中的標題。
- **`sa-analyst` 的 `mode: contract`**：照角色定義寫入 `bdd-docs/{feature-id}/contract/`，並用角色的回傳合約。本 skill 提供 API 草案寫法，角色定義負責落檔和回報。

````markdown
STATUS: needs-input | draft

## design/api-contract.yaml
```yaml
openapi: 3.1.0
info:
  title: ...
  version: 0.1.0
servers:
  - url: https://api.example.com
paths: {}
components:
  schemas: {}
```

## API Design Notes
| Operation ID | Method | Path | Rule IDs | Example IDs | Notes |
| --- | --- | --- | --- | --- | --- |

## Assumptions
- ...

## Open Questions
- ...

## Next Skill
建議下一步：交回 orchestrator 走 ③ 定案；契約有破壞性變更時，`reviewer`（`mode: spec`）必審
````

## Quality Gate

- `STATUS: needs-input`：endpoint 行為、actor 權限、核心 request 資料或主要成功/失敗結果缺失。
- `STATUS: draft`：API 可在明確 assumptions 下被審核，且每個 endpoint 可追溯至 rule + example。
