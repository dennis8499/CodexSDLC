# sdlc.ps1
# 這套工作流的安裝、升級與 per-agent 調校。
#
# 三個約束決定了整支腳本的形狀，每一個都來自這個 repo 已經付過的代價：
#
# 1. **使用者的設定不能放在工具那半。** 升級動作是「覆蓋 .codex/、.agents/、AGENTS.md」，
#    設定放那裡會在升級時靜默消失（同 guidelines/ 的理由）。所以 model／effort 的真相是
#    專案根的 sdlc.config.json，toml 裡的 SDLC-TUNING 區塊只是它的**產物**。
#
# 2. **effort 的預設必須是「不寫這個 key」。** 1d8e411 把四個 agent 全釘 high，
#    結果大型 legacy repo 的分析逾時（理由留在 agent-lint.ps1 檢查 2 的檔頭）。
#    所以設定值 `inherit` 代表產生出來的區塊裡**一行都沒有**，而它是每個 agent 的預設。
#
# 3. **「使用者改過 AGENTS.md」是預期狀態，不是例外**（README 就叫他把內容合進去）。
#    所以升級不能無條件覆蓋 —— 要靠 baseline manifest 分辨「沒動過／你改過／新增／這一版刪了」。
#    分不出來時**不得假設沒動過**：猜錯就是靜默蓋掉使用者的修改。
#
# 4. **改設定只有一個入口：`set`。** 它先依 .codex/bdd-workflow/sdlc.config.schema.json 驗完全部的值才寫
#    （有一組不對，一個字都不動），`-Apply` 讓「寫」與「套用」是同一個動作。VS Code 的設定面板也只經過它。
#    設定檔整份改寫，所以**不支援註解** —— 有註解時 set 先停下來問、update 先備份。
#
# 更新通知刻意**不在這裡**：它折進 handoff-lint.ps1 的尾端，只讀快取、不碰網路、只喊一行。
# 流程裡不得冒出更新確認 —— AGENTS.md 的「必經的確認只有兩個」是硬不變量。
#
# **-Json 是給程式讀的合約**（VS Code extension 讀它）：`{ schema, command, exit, data, warnings, output }`。
# `data` 是結構化欄位，`output`／`warnings` 是給人看的句子。**呼叫端只准讀 data** —— 從中文句子裡撈狀態，
# 改一句措辭就會讓讀的人靜默地顯示錯的東西。欄位改名或改義就要把 $JsonSchema 加一。
#
# Exit: 0 = 成功／無事可做；2 = 有問題（doctor／apply 檢出，或使用者取消）。

[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [ValidateSet('install', 'update', 'check-update', 'apply', 'set', 'tune', 'doctor', 'whatsnew', 'fetch', 'models', 'learn', 'managed-hooks', 'trust-hooks', 'git-hooks')]
    [string]$Command = 'doctor',

    [string]$Source,                       # 發佈物根目錄；預設 = 本腳本所在的工作流根
    [string]$Target = '.',                 # 消費端專案根
    [string]$ConfigFile = 'sdlc.config.json',

    [ValidateSet('fast', 'balanced', 'deep')]
    [string]$Preset,                       # install 用（不給就全部 inherit）；set 用：換成這個預設組合
    [switch]$Adopt,                        # install 用：接管既有的手動安裝，把現況記成基準線
    [switch]$WithEditor,                   # install 用：順便把發佈物附的 VS Code extension 裝進這台機器的編輯器
    [switch]$Apply,                        # set 用：寫完順便 apply 一次（不管改了幾個值）
    [switch]$Preview,                      # set／update 用：只驗、只列出會改什麼，一個字都不寫
    [switch]$ApplyProposal,                # tune 用：把**存下來的那份**提議寫回設定檔（不重算）
    [string[]]$Only,                       # tune -ApplyProposal 用：只套這幾個 agent（逗號分隔也可以）
    [switch]$IfDue,                        # check-update 用：照 update.check 的頻率決定要不要真的連網
    [string]$SourceUrl,                    # fetch 用：發佈物來源（寫法見 $ReleaseSourcePattern；不給就找 sdlc.config.json 的 update.source，再找 -Source 版本檔的 source）
    [string]$CacheDir,                     # fetch 用：下載回來的發佈物放哪（預設 LocalApplicationData/codex-sdlc/payloads）
    [string]$Bundled,                      # fetch 用：本機已經有的那一份發佈物（資料夾或 .zip；預設 = -Source）；遠端拿不到時就用它
    [switch]$NoRemote,                     # fetch 用：只認本機那一份，一條連線都不開
    [string]$CodexPath,                    # doctor -CheckHookTrust 用：codex 執行檔（預設找 PATH）
    [switch]$CheckHookTrust,               # doctor 用：另外叫起 codex 問 hooks 的信任狀態（預設不問，見 Get-HookTrust）
    [switch]$TrustHooks,                   # install／update 用：裝完順便替你在 Codex 信任這套工作流的 hooks（= 同意 trust-hooks 寫 ~/.codex/config.toml）
    [string]$OutDir,                       # managed-hooks 用：部署包寫到哪個資料夾
    [string]$ManagedDir = 'C:\enterprise\hooks',   # managed-hooks 用：requirements.toml 的 windows_managed_dir
    [string]$UnixManagedDir = '/enterprise/hooks', # managed-hooks 用：requirements.toml 的 managed_dir（macOS／Linux）
    [switch]$Remove,                       # git-hooks 用：拿掉這套裝的 pre-commit 與 no-codex-hooks 標記
    [string]$EditorHome,                   # 找已安裝 extension 的家目錄（預設 = 使用者家目錄；測試用）
    [switch]$Yes,                          # 非互動確認
    [switch]$Json,
    # set 用：要改的值，寫成 key=value（例如 agents.reviewer.effort=high review.maxRounds=4）
    [Parameter(ValueFromRemainingArguments)]
    [string[]]$Assignments
)

$ErrorActionPreference = 'Stop'

# ---- 標準 I/O：被程式呼叫時一律 UTF-8 ----
# Codex 送進來的 payload 是 UTF-8、也用 UTF-8 解讀 hook 的輸出；Windows 上 [Console] 的編碼卻跟著 console 的
# code page 走（zh-TW 是 cp950；並行的 hook 共用同一個 console，偶爾連輸出端也是）。Codex 0.154.0 實測的後果：
# 一份 743 字、meta 完整的中文 handoff 被解成 1772 字、JSON 解析失敗、抓不到 mode —— **每一次 spawn 都被擋**；
# 阻斷理由的中文到模型手上是亂碼。只在被重導向時才換：人在終端機跑的時候照 console 的 code page 顯示。
# 同一段在每一支會被程式呼叫的腳本裡各有一份（清單由 test-hook-payload.ps1 守住）。
$Utf8NoBom = [Text.UTF8Encoding]::new($false)
if ([Console]::IsOutputRedirected) { $w = [IO.StreamWriter]::new([Console]::OpenStandardOutput(), $Utf8NoBom); $w.AutoFlush = $true; [Console]::SetOut($w) }
if ([Console]::IsErrorRedirected)  { $w = [IO.StreamWriter]::new([Console]::OpenStandardError(),  $Utf8NoBom); $w.AutoFlush = $true; [Console]::SetError($w) }
function Read-StdinUtf8 {
    if ([Console]::IsInputRedirected) { return [IO.StreamReader]::new([Console]::OpenStandardInput(), $Utf8NoBom).ReadToEnd() }
    return [Console]::In.ReadToEnd()
}

# ---- 常數 ----
# 工具那半。guidelines/ 與 bdd-docs/ 刻意不在裡面 —— 它們是使用者的。
$ToolRoots   = @('.codex', '.agents')
$ToolFiles   = @('AGENTS.md')
$VersionRel  = '.codex/bdd-workflow/bdd-workflow-version.json'
$ProfilesRel = '.codex/bdd-workflow/tuning-profiles.json'
$ManifestRel = '.codex/bdd-workflow/manifest.json'          # 發佈物自帶，不列入自己
$HooksRel    = '.codex/hooks.json'
$StateDir    = 'bdd-docs/.sdlc'
$BaselineRel = "$StateDir/installed-manifest.json"
$CacheRel    = "$StateDir/update-cache.json"
$ProposalRel = "$StateDir/tuning-proposal.json"
$HeartbeatRel = 'bdd-docs/.cache/hooks'                     # 四支 hook 的 Write-HookHeartbeat 寫的地方
$NoHooksMarkerRel = 'bdd-docs/.cache/no-codex-hooks'        # git-hooks 寫：這台的 Codex hooks 跑不起來（AGENTS.md 叫 orchestrator 自己跑 handoff-lint）
$GuideReadmeRel = 'guidelines/README.md'
$GuideStockRel  = '.codex/bdd-workflow/guidelines-readme-stock.json'   # 歷來原廠 README 的雜湊（見 Get-GuidelinesReadmeState）

$TuneBegin   = '# SDLC-TUNING:BEGIN'
$TuneEnd     = '# SDLC-TUNING:END'

# ---- 合法值 ----
# 唯一真相是 $ConfigSchemaRel（set 與 VS Code 都讀它）。這裡的常數是這支腳本在 schema 不在時也要能跑的那一份，
# 由 agent-lint 檢查 14 跟 schema 綁在一起 —— 改一邊沒改另一邊，lint 紅。
$ConfigSchemaRel = '.codex/bdd-workflow/sdlc.config.schema.json'
$RulesSchemaRel  = '.codex/bdd-workflow/rules.schema.json'
$ConfigSchemaRef = './.codex/bdd-workflow/sdlc.config.schema.json'   # 寫進 sdlc.config.json 的 $schema（相對於專案根）
# effort 是觀測值：Codex 0.154.0 內建模型清單列的 reasoning effort（Codex 本身不檢查這個值，寫錯要到呼叫 API 才出事）。
# minimal 不在任何一個模型的清單裡，所以拿掉了。Codex 升版時照 docs/vscode-extension-plan.md 的方法重查。
# 0.162.1 重查過（spawn_agent 工具說明列的模型 effort）：同一組。
$KnownEfforts = @('low', 'medium', 'high', 'xhigh', 'max', 'ultra')
# 強制層（hooks.json 的形狀、commandWindows、payload）實測過的最舊一版。比它舊 → doctor 算問題；
# 比它新不提示（使用者無從行動，修法是維護者重跑實測）。重跑實測之後跟著改這一行（發版清單第 4 條）。
# v4.13.0 的 commandWindows（單一 pwsh）在 0.154.0 與 0.162.1 各端到端跑過一次（版本檔 v413-speedup），所以仍是 0.154.0。
$VerifiedCodexVersion = '0.154.0'
$UpdateChecks = @('daily', 'never')
# 發佈物來源（update.source／版本檔的 source）認得的寫法：github.com、gitlab.com 直接寫網址；自架的在前面標明是哪一家
# —— gitea:https://…、gitlab:https://…、github:https://…（GitHub Enterprise）。網域本身看不出是 Gitea 還是 GitLab，
# 用猜的要多打幾次 API、猜錯還是要人改，寫明比較便宜。schema 的 pattern ＝ '^$|' ＋ 這一條（agent-lint 檢查 14 綁住）。
$ReleaseSourcePattern = '^(?:https?://(?:www\.)?github\.com/[^/\s]+/[^/\s]+?|https?://gitlab\.com/[^/\s]+(?:/[^/\s]+)+?|(?:github|gitlab|gitea):https?://[^/\s]+(?:/[^/\s]+){2,}?)(?:\.git)?/?$'
$ReleaseSourceHint = 'github.com／gitlab.com 直接寫網址，自架的寫成 gitea:https://…、gitlab:https://… 或 github:https://…（GitHub Enterprise）'
# 修正輪上限的預設值。範圍（1–5）由 handoff-lint 與 agent-lint 檢查 13 判，doctor 讀 lint 的結論。
$DefaultReviewRounds = 3

$JsonSchema  = 1
$ExtensionId = 'codex-sdlc.codex-sdlc'
$MinUpgradeExtension = '4.16.0'          # extension 從這一版起有「升級」（codexSdlc.upgrade）；更舊的點「有新版」只會跑 whatsnew
# 編輯器的 CLI 名稱與各自的 extension 目錄。VS Code／Insiders／Cursor／Windsurf／VSCodium 都吃同一個 .vsix，
# 但執行檔名與目錄各一個 —— 只找 `code` 的話，另外四種的使用者會收到一句「找不到」而他們明明裝了編輯器。
$Editors = @(
    [pscustomobject]@{ product = 'VS Code';          cli = 'code';          dir = '.vscode' }
    [pscustomobject]@{ product = 'VS Code Insiders'; cli = 'code-insiders'; dir = '.vscode-insiders' }
    [pscustomobject]@{ product = 'Cursor';           cli = 'cursor';        dir = '.cursor' }
    [pscustomobject]@{ product = 'Windsurf';         cli = 'windsurf';      dir = '.windsurf' }
    [pscustomobject]@{ product = 'VSCodium';         cli = 'codium';        dir = '.vscode-oss' }
)

# 「有沒有給 -Bundled」要在這裡記下來：函式裡的 $PSBoundParameters 是那個函式自己的，看不到腳本的。
# 差別是真的：`-Bundled ''` 代表「這台機器沒有內附的發佈物」，完全不給才是「用 -Source 那一份」。
$BundledGiven = $PSBoundParameters.ContainsKey('Bundled')

if (-not $Source) { $Source = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path }
if (-not $EditorHome) { $EditorHome = [Environment]::GetFolderPath('UserProfile') }

# 工作區裡有哪幾個 git repo（git-hooks 與 doctor 用；判法跟 delivery-check 同一份）。只複製了這支腳本時沒有它 —— 用到的地方會跳過。
$WorkspaceLib = Join-Path $PSScriptRoot 'lib/workspace-repos.ps1'
if (Test-Path -LiteralPath $WorkspaceLib) { . $WorkspaceLib }

# 路徑不存在時給一句人看得懂的話，而不是讓 Resolve-Path 丟出堆疊 ——
# 「擋下的理由跟使用者要做的事無關，而且他也修不了」是這套流程踩過兩次的失敗形狀。
foreach ($pair in @(@{ n = '-Source'; v = $Source }, @{ n = '-Target'; v = $Target })) {
    if (-not (Test-Path $pair.v)) {
        [Console]::Error.WriteLine("[sdlc] $($pair.n) 指向的路徑不存在：$($pair.v)")
        if ($Json) {
            [Console]::Out.WriteLine(([ordered]@{ schema = $JsonSchema; command = $Command; exit = 2; data = [ordered]@{ error = 'path-not-found'; param = $pair.n }; warnings = @("$($pair.n) 指向的路徑不存在：$($pair.v)"); output = @() } | ConvertTo-Json -Depth 4 -Compress))
        }
        exit 2
    }
}

$script:Notes = @()
$script:Warnings = @()
$script:Data = [ordered]@{}
# 直接寫 stdout，**不能用 Write-Output**：這些訊息是從有回傳值的函式裡發出的，
# 走輸出串流會跟 return 的 exit code 混在同一個陣列裡 —— 症狀是整支腳本一個字都不印，
# 而且 exit code 變成一個字串陣列。
function Say([string]$m)  { $script:Notes += $m; if (-not $Json) { [Console]::Out.WriteLine($m) } }
function Warn([string]$m) { $script:Warnings += $m; [Console]::Error.WriteLine("[sdlc] $m") }

# ---- 共用工具 ----
function Get-Sha256Text([string]$text) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { -join ($sha.ComputeHash($Utf8NoBom.GetBytes($text)) | ForEach-Object { $_.ToString('x2') }) }
    finally { $sha.Dispose() }
}

function Get-Sha256File([string]$path) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { -join ($sha.ComputeHash([IO.File]::ReadAllBytes($path)) | ForEach-Object { $_.ToString('x2') }) }
    finally { $sha.Dispose() }
}

# 比對用的雜湊：agent toml 一律**把 SDLC-TUNING 區塊拿掉之後**再算。
#
# 那個區塊是 `apply` 寫的，不是使用者寫的。拿原始位元組比對的話，install 之後跑一次 apply
# 就會讓每個 agent toml 在下一次 update 被判成「使用者改過」—— 三個檔、每次升級都報一次，
# 而那份報告的價值完全來自「列出來的都真的要看」。噪音會直接訓練使用者忽略它。
#
# 只正規化 .codex/agents/*.toml：其餘檔案照原樣算，不做任何文字解碼。
function Get-ComparableSha([string]$root, [string]$rel) {
    $full = Join-Path $root $rel
    if ($rel -notmatch '^\.codex/agents/.+\.toml$') { return Get-Sha256File $full }
    $text = [IO.File]::ReadAllText($full)
    $pattern = "(?s)" + [regex]::Escape($TuneBegin) + ".*?" + [regex]::Escape($TuneEnd) + "\r?\n?"
    return Get-Sha256Text ([regex]::Replace($text, $pattern, ''))
}

function ConvertTo-Rel([string]$root, [string]$full) {
    $r = (Resolve-Path $root).Path.TrimEnd('\', '/')
    $f = $full
    if ($f.StartsWith($r, [StringComparison]::OrdinalIgnoreCase)) { $f = $f.Substring($r.Length) }
    return ($f -replace '\\', '/').TrimStart('/')
}

# 工具那半的檔案清單（相對路徑，正斜線，排序）。manifest 自己不列入自己。
function Get-ToolFileList([string]$root) {
    $out = @()
    foreach ($d in $ToolRoots) {
        $p = Join-Path $root $d
        if (-not (Test-Path $p)) { continue }
        $out += @(Get-ChildItem $p -Recurse -File | ForEach-Object { ConvertTo-Rel $root $_.FullName })
    }
    foreach ($f in $ToolFiles) {
        if (Test-Path (Join-Path $root $f)) { $out += $f }
    }
    return @($out | Where-Object { $_ -ne $ManifestRel } | Sort-Object -Unique)
}

function Read-JsonFile([string]$path) {
    if (-not (Test-Path $path)) { return $null }
    try { return (Get-Content $path -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { return $null }
}

# ConvertFrom-Json 會把 ISO 時間字串變成 [DateTime]，而 [string]$dt 是**依文化**的格式（「2026/9/13 上午 06:56」）。
# -Json 的讀者要的是 ISO。
function ConvertTo-IsoText($v) {
    if ($null -eq $v -or $v -eq '') { return $null }
    if ($v -is [DateTime]) { return $v.ToString('o') }
    return [string]$v
}

# 字串外的 // 或 /* —— JSON 註解。PowerShell 7 讀得進去，寫回去時就沒了，而且不會有任何提示。
# sdlc.config.json 宣告不支援註解；改寫它之前先用這個看一眼，有的話先備份、說一聲。
function Test-JsonHasComments([string]$text) {
    $inString = $false; $escaped = $false
    for ($i = 0; $i -lt $text.Length - 1; $i++) {
        $c = $text[$i]
        if ($inString) {
            if ($escaped) { $escaped = $false }
            elseif ($c -eq [char]'\') { $escaped = $true }
            elseif ($c -eq [char]'"') { $inString = $false }
            continue
        }
        if ($c -eq [char]'"') { $inString = $true; continue }
        if ($c -eq [char]'/' -and ($text[$i + 1] -eq [char]'/' -or $text[$i + 1] -eq [char]'*')) { return $true }
    }
    return $false
}

# $schema 放第一個 key：人打開檔案時第一眼看到它從哪裡來，編輯器也只看這一個。
function ConvertTo-ConfigWithSchemaRef($cfg) {
    $o = [ordered]@{ '$schema' = $ConfigSchemaRef }
    foreach ($p in $cfg.PSObject.Properties) { if ($p.Name -ne '$schema') { $o[$p.Name] = $p.Value } }
    return [pscustomobject]$o
}

function Write-JsonFile([string]$path, $obj) {
    $dir = Split-Path $path -Parent
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    [IO.File]::WriteAllText($path, (($obj | ConvertTo-Json -Depth 8) + "`n"), $Utf8NoBom)
}

function Get-ContractVersion([string]$root) {
    $v = Read-JsonFile (Join-Path $root $VersionRel)
    if (-not $v) { return $null }
    return [pscustomobject]@{
        contract = $v.'contract-version'
        minCompat = $v.'min-compatible-version'
        raw = $v
    }
}

# semver 比較。回 -1／0／1。
function Compare-Semver([string]$a, [string]$b) {
    $pa = @(($a -split '\.') | ForEach-Object { [int]($_ -replace '\D', '') })
    $pb = @(($b -split '\.') | ForEach-Object { [int]($_ -replace '\D', '') })
    for ($i = 0; $i -lt 3; $i++) {
        $x = if ($i -lt $pa.Count) { $pa[$i] } else { 0 }
        $y = if ($i -lt $pb.Count) { $pb[$i] } else { 0 }
        if ($x -ne $y) { return $x.CompareTo($y) }
    }
    return 0
}

function Confirm-Step([string]$question) {
    if ($Yes) { return $true }
    if ($Json -or [Console]::IsInputRedirected) {
        Warn "$question —— 非互動環境，請加 -Yes 明確同意。已中止。"
        return $false
    }
    $a = Read-Host "$question [y/N]"
    return ($a -match '^(y|yes)$')
}

# 怎麼再叫起一支跟現在一樣的 pwsh。一般安裝時 [Environment]::ProcessPath 就是 pwsh(.exe)；
# 以 .NET global tool 安裝時（dotnet tool install -g powershell），它是 dotnet(.exe)，pwsh 本體是 $PSHOME/pwsh.dll。
# 直接拿 ProcessPath 當 pwsh 叫，跑的就是 `dotnet -NoProfile …` —— 一行都不會執行：doctor 的 agent-lint 與 rules.json 驗證、
# tune 的 repo-index 訊號全部「沒有跑完」，而且只有那種安裝的機器會這樣（維護者的機器就是）。
# 參數只給 test-sdlc.ps1 用：那個情境在一般安裝的機器上重現不出來，只能直接餵值驗這個判斷。
function Get-PwshLaunch([string]$processPath = [Environment]::ProcessPath, [string]$pwshHome = $PSHOME) {
    $dll = Join-Path $pwshHome 'pwsh.dll'
    $viaDotnet = ([IO.Path]::GetFileNameWithoutExtension($processPath) -ieq 'dotnet') -and (Test-Path -LiteralPath $dll -PathType Leaf)
    return [pscustomobject]@{ exe = $processPath; prefix = @(if ($viaDotnet) { $dll }) }
}

# 跑另一支 pwsh 腳本並收回輸出，一律 UTF-8。
# 不用 `& pwsh ... 2>&1`：PowerShell 會拿 console 的 code page 解碼子行程的輸出，
# 而子行程被重導向時寫的是 UTF-8（見「標準 I/O」段）—— 兩邊對不上，中文就是亂碼，JSON 就解析失敗。
# 用執行中的這一支 pwsh（Get-PwshLaunch），不去 PATH 找：從 VS Code 叫起來的時候 PATH 裡不一定有它。
function Invoke-PwshScript([string]$file, [string[]]$arguments = @(), [string]$cwd = (Get-Location).Path) {
    $launch = Get-PwshLaunch
    $psi = [Diagnostics.ProcessStartInfo]::new($launch.exe)
    foreach ($a in @($launch.prefix) + @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $file) + $arguments) { $psi.ArgumentList.Add($a) }
    $psi.WorkingDirectory       = $cwd
    $psi.UseShellExecute        = $false
    $psi.RedirectStandardInput  = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.StandardOutputEncoding = $Utf8NoBom
    $psi.StandardErrorEncoding  = $Utf8NoBom
    $p = [Diagnostics.Process]::Start($psi)
    $p.StandardInput.Close()
    $o = $p.StandardOutput.ReadToEndAsync(); $e = $p.StandardError.ReadToEndAsync()
    $p.WaitForExit()
    return [pscustomobject]@{ exit = $p.ExitCode; stdout = $o.GetAwaiter().GetResult(); stderr = $e.GetAwaiter().GetResult() }
}

# ---- 調校：設定 → toml 區塊 ----
#
# 這個正規化字串是 sdlc.ps1 與 agent-lint.ps1 之間的合約。**agent-lint 有一份逐字相同的副本**
# （它必須能獨立驗，不能為了算一個雜湊去 spawn 這支腳本）。改這裡就要改那裡 ——
# test-sdlc.ps1 的「設定改了但沒 apply → agent-lint 必須紅燈」那一條就是在守這個重複。
function Get-TuningStanza($agentCfg) {
    $model  = if ($agentCfg -and $agentCfg.model)  { [string]$agentCfg.model }  else { 'inherit' }
    $effort = if ($agentCfg -and $agentCfg.effort) { [string]$agentCfg.effort } else { 'inherit' }
    return "model=$model;effort=$effort"
}

function Get-TuningSha($agentCfg) {
    return (Get-Sha256Text (Get-TuningStanza $agentCfg)).Substring(0, 8)
}

function Get-AgentConfig($cfg, [string]$name) {
    if (-not $cfg -or -not $cfg.agents) { return $null }
    return $cfg.agents.PSObject.Properties |
           Where-Object { $_.Name -eq $name } |
           ForEach-Object { $_.Value } |
           Select-Object -First 1
}

# 產生區塊本體。inherit → 一行都沒有（見檔頭約束 2）。
function New-TuningBlock($agentCfg, [string]$sha, [string]$nl) {
    $lines = @("$TuneBegin sha=$sha —— 由 sdlc.ps1 apply 產生，不要手改")
    $model  = if ($agentCfg -and $agentCfg.model)  { [string]$agentCfg.model }  else { 'inherit' }
    $effort = if ($agentCfg -and $agentCfg.effort) { [string]$agentCfg.effort } else { 'inherit' }
    if ($model  -ne 'inherit') { $lines += "model = `"$model`"" }
    if ($effort -ne 'inherit') { $lines += "model_reasoning_effort = `"$effort`"" }
    $lines += $TuneEnd
    return ($lines -join $nl)
}

function Invoke-TuningApply([string]$root, $cfg) {
    $changed = @(); $warnings = @()
    $agentDir = Join-Path $root '.codex/agents'
    if (-not (Test-Path $agentDir)) { return [pscustomobject]@{ changed = @(); warnings = @('.codex/agents 不存在') } }
    $tomls = @(Get-ChildItem $agentDir -Filter *.toml -File | Sort-Object Name)

    # 寫得出去，但絕不安靜：在這台的 Codex 上會出事的值每一個都講。擋在 set —— apply 也跑在 update 裡，不在這裡擋。
    # 全部 inherit 就不問 codex（最常見的情況，不付那半秒）。
    $catalog = $null; $session = $null
    $checkedWith = if ($cfg -and $cfg.PSObject.Properties['models-checked-with']) { [string]$cfg.'models-checked-with' } else { $null }
    $pinned = @($tomls | ForEach-Object { Get-AgentConfig $cfg $_.BaseName } |
                Where-Object { $_ -and (($_.model -and [string]$_.model -ne 'inherit') -or ($_.effort -and [string]$_.effort -ne 'inherit')) })
    if ($pinned.Count -gt 0) { $catalog = Get-ModelCatalog $root; $session = Get-SessionModel $root $catalog }

    foreach ($f in $tomls) {
        $name = $f.BaseName
        $acfg = Get-AgentConfig $cfg $name
        $text = [IO.File]::ReadAllText($f.FullName)
        $nl   = if ($text -match "`r`n") { "`r`n" } else { "`n" }
        $sha  = Get-TuningSha $acfg
        $block = New-TuningBlock $acfg $sha $nl

        if ($catalog) {
            $effort = if ($acfg -and $acfg.effort) { [string]$acfg.effort } else { 'inherit' }
            $mc = Test-ModelChoice $catalog $session $name $(if ($acfg) { [string]$acfg.model } else { $null }) $effort $checkedWith
            if ($mc.level -in @('problem', 'warn')) { $warnings += Format-ModelFinding $mc }
            # 問不到 Codex 的清單：至少擋得住沒有任何模型認得的字（例如 4.8 以前合法的 minimal）。
            elseif ($mc.status -eq 'unverified' -and $effort -ne 'inherit' -and $effort -notin $KnownEfforts) {
                $warnings += "$name：effort=`"$effort`" 不在已知值（$($KnownEfforts -join '／')）之列，仍會寫出去"
            }
        }

        $pattern = "(?s)" + [regex]::Escape($TuneBegin) + ".*?" + [regex]::Escape($TuneEnd) + "\r?\n?"
        if ($text -match $pattern) {
            $new = [regex]::Replace($text, $pattern, ($block + $nl), 1)
        } else {
            # 插在 developer_instructions 之前 —— 那是唯一確定存在（agent-lint 檢查 2 必填）
            # 且一定在所有純量 key 之後的錨點。
            $anchor = [regex]::Match($text, "(?m)^developer_instructions\s*=")
            if (-not $anchor.Success) {
                $warnings += "$($f.Name)：找不到 developer_instructions，跳過（agent-lint 檢查 2 會另外報這個檔）"
                continue
            }
            $new = $text.Insert($anchor.Index, $block + $nl)
        }
        if ($new -ne $text) {
            [IO.File]::WriteAllText($f.FullName, $new, $Utf8NoBom)
            $changed += $f.Name
        }
    }
    return [pscustomobject]@{ changed = $changed; warnings = $warnings }
}

# ---- 設定檔 ----
function Get-DefaultConfig([string]$root, [string]$version, [string]$preset) {
    $agentNames = @('orchestrator')
    $agentDir = Join-Path $root '.codex/agents'
    if (Test-Path $agentDir) {
        $agentNames += @(Get-ChildItem $agentDir -Filter *.toml -File | ForEach-Object { $_.BaseName } | Sort-Object)
    }

    $srcVersionRaw = Read-JsonFile (Join-Path $root $VersionRel)

    $presetMap = $null
    if ($preset) {
        $profiles = Read-JsonFile (Join-Path $root $ProfilesRel)
        if ($profiles -and $profiles.presets) {
            $presetMap = $profiles.presets.PSObject.Properties |
                         Where-Object { $_.Name -eq $preset } |
                         ForEach-Object { $_.Value } | Select-Object -First 1
        }
        if (-not $presetMap) { Warn "找不到 preset `"$preset`"，改用全部 inherit。" }
    }

    $agents = [ordered]@{}
    foreach ($n in ($agentNames | Sort-Object -Unique)) {
        $m = 'inherit'; $e = 'inherit'
        if ($presetMap) {
            $hit = $presetMap.PSObject.Properties | Where-Object { $_.Name -eq $n } | ForEach-Object { $_.Value } | Select-Object -First 1
            if ($hit) {
                if ($hit.model)  { $m = [string]$hit.model }
                if ($hit.effort) { $e = [string]$hit.effort }
            }
        }
        $agents[$n] = [ordered]@{ model = $m; effort = $e }
    }

    return [ordered]@{
        # 編輯器靠它找到 schema：補全、波浪線、滑鼠移上去的說明。沒裝 VS Code extension 也有。
        '$schema'          = $ConfigSchemaRef
        '_note'            = 'sdlc.config.json 是你的，升級永遠不覆蓋。改值最省事的方法：pwsh .codex/scripts/sdlc.ps1 set agents.reviewer.effort=high -Apply（先驗再寫，寫錯一個字都不動）。effort/model 的 "inherit" = 產生出來的 toml 裡不寫那一行，交由 Codex CLI 決定（手改 agents.* 之後要跑 apply）。orchestrator 沒有 agent 定義檔，這裡只是記錄建議值，強制不了。review.maxRounds = ⑤ 審核的修正輪上限（1–5，預設 3），handoff-lint 每次現讀，不必 apply。這個檔不支援註解，說明請寫在這裡。'
        'workflow-version' = $version
        # 來源網址由**發佈物**帶進來（版本檔的 `source`），不是寫死在這支腳本裡。
        # 寫死的話，維護者換 repo 或第一次發佈時忘了改，每一個安裝出去的專案都會拿到
        # 一個指不到任何地方的網址 —— 而症狀是「沒有人告訴你有新版」，完全靜默。
        # 空字串是合法的：check-update 會直接說查不到，其餘一切照常。
        # channel 不再寫：從來沒有任何一方讀它（schema 標成已棄用，舊檔留著不報錯）。
        'update'           = [ordered]@{
            source  = $(if ($srcVersionRaw -and $srcVersionRaw.source) { [string]$srcVersionRaw.source } else { '' })
            check   = 'daily'
        }
        # ⑤ 的修正輪上限。由 handoff-lint 每次現讀（不寫進 hooks.json：hook 指令一改，Codex 就要你重新信任它）。
        'review'           = [ordered]@{ maxRounds = $DefaultReviewRounds }
        'agents'           = $agents
    }
}

# 升級時只補新 agent 的 key，既有的值一個字不動。
function Merge-Config($cfg, [string]$srcRoot, [string]$newVersion) {
    $added = @()
    $agentDir = Join-Path $srcRoot '.codex/agents'
    if (Test-Path $agentDir) {
        foreach ($n in @(Get-ChildItem $agentDir -Filter *.toml -File | ForEach-Object { $_.BaseName } | Sort-Object)) {
            if (-not (Get-AgentConfig $cfg $n)) {
                $cfg.agents | Add-Member -NotePropertyName $n -NotePropertyValue ([pscustomobject]@{ model = 'inherit'; effort = 'inherit' })
                $added += $n
            }
        }
    }
    $cfg.'workflow-version' = $newVersion
    return $added
}

# ---- guidelines/：唯讀檢查，一個字都不寫 ----
#
# 升級永遠不動 guidelines/，但工具那半會變，而它跟 guidelines/ 之間有一份沒寫下來的合約：
# 「檔名即路由鍵」。新版多讀一個檔名而使用者沒有那個檔 → 那一節規範完全不存在，且靜默。
#
# 每一條 finding 帶一個 code（absent／missing／orphan／gate-disabled／rules-invalid）給 -Json 的讀者用。
function Test-Guidelines([string]$target, [string]$source) {
    $findings = @()
    $gdir = Join-Path $target 'guidelines'
    if (-not (Test-Path $gdir)) {
        return @([pscustomobject]@{ level = 'info'; code = 'absent'; text = 'guidelines/ 不存在 —— gate 靜默通過，agent 也不會去找。需要團隊規範時再建。' })
    }

    # 新版讀哪些檔名：只取每個 agent 的「專案規範」那一節裡的 `X.md`。不掃全文 —— 全文裡的 spec.md／SKILL.md 會混進來。
    #
    # 那一節在哪裡結束，看的是**標題層級**：碰到同級或更高的下一個標題就停。
    # 舊版寫死「停在下一個 `## `」—— sa-analyst 的那一節是 `###`，於是一路讀進下一節
    # 「精度是事實」，把那裡的 `spec.md` 當成規範檔名，每一次 install／update／doctor 都報「你缺 spec.md」，
    # 而 doctor 因此永遠是紅的。一個永遠紅的健檢，就是一個沒有人會再看的健檢。
    $wanted = @()
    $adir = Join-Path $source '.codex/agents'
    $docs = @()
    if (Test-Path $adir) { $docs += @(Get-ChildItem $adir -Filter *.toml -File | ForEach-Object { [IO.File]::ReadAllText($_.FullName) }) }
    foreach ($d in $docs) {
        foreach ($h in [regex]::Matches($d, '(?m)^(#{2,6})[ \t]*專案規範.*$')) {
            $level = $h.Groups[1].Value.Length
            $rest  = $d.Substring($h.Index + $h.Length)
            $next  = [regex]::Match($rest, "(?m)^#{1,$level}[ \t]")
            $sec   = if ($next.Success) { $rest.Substring(0, $next.Index) } else { $rest }
            $wanted += @([regex]::Matches($sec, '`([a-z0-9\-]+\.md)`') | ForEach-Object { $_.Groups[1].Value })
        }
    }
    $wanted = @($wanted | Sort-Object -Unique)

    # 選用檔：只在改動涉及那個領域時才讀，沒有那個領域的專案（純後端之於 frontend.md）根本用不到。
    # 缺它照 missing 報，doctor 會對每一個後端專案永遠紅 —— 而「不要建空檔」那句又堵死了唯一的關燈方法。
    # 所以缺選用檔只是 info：讓升級上來的人知道有這份範例可拿，不算問題。
    $optional = @('frontend.md')

    if ($wanted.Count -gt 0) {
        $have = @(Get-ChildItem $gdir -Filter *.md -File | ForEach-Object { $_.Name })
        $absentOpt = @($wanted | Where-Object { $_ -in $optional -and $_ -notin $have })
        if ($absentOpt.Count -gt 0) {
            $findings += [pscustomobject]@{
                level = 'info'; code = 'optional-absent'
                text  = "選用規範檔 $($absentOpt -join '、') 不在 —— 只在改動涉及那個領域時才讀，沒有就照專案慣例做。需要團隊規範時，從發行包的 guidelines/ 複製範例改寫。"
            }
        }
        $missing = @($wanted | Where-Object { $_ -notin $have -and $_ -notin $optional })
        if ($missing.Count -gt 0) {
            $findings += [pscustomobject]@{
                level = 'warn'; code = 'missing'
                text  = "新版的 agent 會讀 guidelines/ 底下這幾個檔名：$($wanted -join '、')；你缺 $($missing -join '、')。缺的那幾節規範不會生效，而且完全靜默。**不要建空檔** —— 空檔會讓 agent-lint 檢查 8 過關而內容是空的。"
            }
        }
        $orphan = @($have | Where-Object { $_ -ne 'README.md' -and $_ -notin $wanted })
        if ($orphan.Count -gt 0) {
            $findings += [pscustomobject]@{
                level = 'warn'; code = 'orphan'
                text  = "這幾個規範檔新版沒有任何 agent 會讀到：$($orphan -join '、')。內容併進有讀者的檔，否則團隊以為有人在守而沒有人在守。"
            }
        }
    }

    # README：舊版原廠的只有 doctor 看得到（install／update 已經換掉了）；改過的舊版骨架只提一次它的說明搬去哪 ——
    # 認法是還留著舊說明的標題。已經寫成團隊自己的 README 不會有那一句，不吵。
    $rmState = Get-GuidelinesReadmeState $target $source
    if ($rmState -eq 'stock') {
        $findings += [pscustomobject]@{ level = 'info'; code = 'readme-old'; text = 'guidelines/README.md 是舊版的原廠說明（你沒改過）—— 下次 update 會換成新版。工作流的說明在 .codex/bdd-workflow/guidelines-guide.md。' }
    } elseif ($rmState -eq 'custom' -and ([IO.File]::ReadAllText((Join-Path $target $GuideReadmeRel)) -match '檔名就是路由鍵')) {
        $findings += [pscustomobject]@{ level = 'info'; code = 'readme-custom'; text = 'guidelines/README.md 是你改過的舊版骨架說明，沒有覆蓋。工作流的說明已搬到 .codex/bdd-workflow/guidelines-guide.md（每次 update 會跟著更新）—— 你那份裡的工作流說明會停在舊版，可以刪掉，只留你們團隊自己的。' }
    }

    if (Test-Path (Join-Path $gdir '.gate-disabled')) {
        $findings += [pscustomobject]@{
            level = 'warn'; code = 'gate-disabled'
            text  = 'guidelines/.gate-disabled 還在 —— 規範的機械層是關的，而且它會活過每一次升級（升級不動 guidelines/ 裡的它）。不需要就刪掉它。'
        }
    }

    $rules = Join-Path $gdir 'rules.json'
    $gate  = Join-Path $source '.codex/scripts/guideline-gate.ps1'
    if ((Test-Path $rules) -and (Test-Path $gate)) {
        $r = Invoke-PwshScript $gate @('-Validate', '-RulesFile', (Resolve-Path $rules).Path)
        if ($r.exit -ne 0) {
            $findings += [pscustomobject]@{ level = 'warn'; code = 'rules-invalid'; text = "guidelines/rules.json 在新版的 guideline-gate 下驗不過：$(($r.stderr + $r.stdout).Trim() -replace '\s*\r?\n\s*', ' ')" }
        }
    }
    return $findings
}

# ---- guidelines/README.md：guidelines/ 裡唯一會被換掉的檔 ----
#
# 4.19 以前，工作流的使用說明（檔名即路由鍵、rules.json 格式、從審核歸納規範）寫在 guidelines/README.md ——
# 使用者的目錄裡。install 只在 guidelines/ 不存在時放骨架，所以說明改了，已安裝的專案永遠看不到。
# 4.20 起說明搬進 .codex/bdd-workflow/guidelines-guide.md（跟著 update 走），README 縮成一頁指標。
#
# 已安裝的那份要不要換：跟歷來任何一版原廠 README 一字不差（換行統一成 LF、去掉 BOM）= 使用者沒動過，
# 換掉不損失任何東西；否則一個字都不動。不靠基準線 —— guidelines/ 從來不在基準線裡。
#
# 回傳 absent／current（已是這一版）／stock（舊版原廠，可換）／custom（改過）／unknown（沒有雜湊清單可比）。
function Get-NormalizedTextSha([string]$path) {
    $text = [IO.File]::ReadAllText($path, $Utf8NoBom).TrimStart([char]0xFEFF) -replace "`r`n", "`n"
    return Get-Sha256Text $text
}

function Get-GuidelinesReadmeState([string]$target, [string]$stockRoot) {
    $readme = Join-Path $target $GuideReadmeRel
    if (-not (Test-Path $readme -PathType Leaf)) { return 'absent' }
    $stock = Read-JsonFile (Join-Path $stockRoot $GuideStockRel)
    if (-not $stock) { return 'unknown' }
    $h = Get-NormalizedTextSha $readme
    if ($h -eq [string]$stock.current) { return 'current' }
    if ($h -in @($stock.previous)) { return 'stock' }
    return 'custom'
}

# install（guidelines/ 已存在）與 update 共用。回傳 replaced／will-replace（$dryRun：只判斷、不寫）／原狀態。
function Update-GuidelinesReadme([string]$target, [string]$source, [bool]$dryRun) {
    $src = Join-Path $source $GuideReadmeRel
    if (-not (Test-Path $src -PathType Leaf)) { return 'no-source' }
    $state = Get-GuidelinesReadmeState $target $source
    if ($state -ne 'stock') { return $state }
    if ($dryRun) { return 'will-replace' }
    Copy-Item $src (Join-Path $target $GuideReadmeRel) -Force
    return 'replaced'
}

function Get-FindingData($findings) {
    return @($findings | ForEach-Object { [ordered]@{ level = $_.level; code = $_.code; text = $_.text } })
}

# ---- agent-lint：一律用 -Json 收回來，人看的句子由這裡排 ----
function Invoke-Lint([string]$root) {
    $lint = Join-Path $root '.codex/scripts/agent-lint.ps1'
    if (-not (Test-Path $lint)) { return [ordered]@{ ran = $false; passed = $true; violations = @() } }
    $r = Invoke-PwshScript $lint @('-Json') $root
    $j = $null
    try { $j = $r.stdout.Trim() | ConvertFrom-Json } catch { }
    if (-not $j) {
        # lint 自己炸了（例如沒有任何 agent toml）：不是「通過」，把它說的話原樣交出去。
        $msg = ($r.stderr + $r.stdout).Trim()
        Say "  [agent-lint] 沒有跑完：$msg"
        return [ordered]@{ ran = $true; passed = $false; error = $msg; violations = @() }
    }
    $violations = @($j.violations | ForEach-Object { [ordered]@{ rule = [string]$_.rule; detail = [string]$_.detail; fix = [string]$_.fix } })
    if ($j.passed) {
        Say "  [agent-lint] OK —— $($j.subagent_count) 個子代理 ＋ orchestrator，共用核心一致、路由對得上、沒有斷掉或過期的引用。"
    } else {
        Say "  [agent-lint] $($violations.Count) 項違規："
        foreach ($v in $violations) { Say "  - $($v.rule): $($v.detail)"; Say "    fix: $($v.fix)" }
    }
    return [ordered]@{ ran = $true; passed = [bool]$j.passed; violations = $violations }
}

# ---- Codex 的 hook 信任狀態 ----
#
# Codex（0.154.0 實測）要**兩層信任**才會跑 `.codex/hooks.json`：專案本身被信任，而且每一條 hook 被信任。
# 信任記在**使用者的** `~/.codex/config.toml`（以 hooks.json 的絕對路徑為 key、hook 定義的雜湊為值），
# 所以：新裝的專案一定還沒信任；hooks.json 的某一條被改過（例如升級）那一條就變成「待重審」；專案搬了目錄就全部重來。
# 沒信任的 hook **一條都不會跑，而且沒有任何提示** —— 機械強制層整層不在，畫面上一切正常。
#
# 信任狀態只有 Codex 自己知道（雜湊怎麼算是它的實作），所以這裡**問它**（`codex app-server` 的 `hooks/list`），不自己算。
# 啟動 app-server 時它會去連 chatgpt.com 與 github.com（實測），所以子行程的 proxy 一律指向一個一定連不上的位址 ——
# doctor 從構造上就碰不到網路，不靠 Codex 哪一版剛好沒有連。
#
# -IncludeEditor：PATH 上沒有 codex 時，再找 OpenAI 的 VS Code 擴充（openai.chatgpt）內附的那一份 ——
# 只用 VS Code 的 Codex chat、從沒裝過 CLI 的人，PATH 上就是沒有 codex，而信任要靠它寫。
# 只給信任相關的兩條路用（trust-hooks、doctor -CheckHookTrust）：環境檢查與 models 照舊只看 PATH／-CodexPath。
# 內附的位置（extension 目錄底下的 bin/）是推的、沒有在裝了 OpenAI 擴充的機器上看過（docs/maintainers.md 有記）。
function Resolve-Codex([switch]$IncludeEditor) {
    if ($CodexPath) { return $(if (Test-Path $CodexPath) { (Resolve-Path $CodexPath).Path } else { $null }) }
    $c = Get-Command codex -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($c) { return $c.Source }
    if ($IncludeEditor) { return Find-EditorBundledCodex }
    return $null
}

function Find-EditorBundledCodex {
    $names = if ($IsWindows -or $env:OS -eq 'Windows_NT') { @('codex.exe') } else { @('codex') }
    $dirs = @(foreach ($e in $Editors) {
        $root = Join-Path $EditorHome "$($e.dir)/extensions"
        if (Test-Path -LiteralPath $root -PathType Container) {
            Get-ChildItem -LiteralPath $root -Directory -Filter 'openai.chatgpt-*' -ErrorAction SilentlyContinue
        }
    })
    foreach ($d in @($dirs | Sort-Object LastWriteTimeUtc -Descending)) {
        $bin = Join-Path $d.FullName 'bin'
        if (-not (Test-Path -LiteralPath $bin -PathType Container)) { continue }
        $hit = Get-ChildItem -LiteralPath $bin -Recurse -File -Depth 2 -ErrorAction SilentlyContinue |
               Where-Object { $_.Name -in $names } | Select-Object -First 1
        if ($hit) { return $hit.FullName }
    }
    return $null
}

# 一個 app-server 行程上連續發幾個請求（trust-hooks 要「查 → 寫 → 再查」，每一步都起一個新的 codex 太慢）。
# id 從 2 起跳：initialize 是 1，doctor 的 hooks/list 一向是 2（測試的假 codex 認這個）。
# 讀到一半逾時就整個 session 作廢 —— 那一個 ReadLineAsync 還掛著，同一條 stream 不能再讀。
function Start-CodexAppServer([string]$codex, [string]$cwd) {
    $psi = [Diagnostics.ProcessStartInfo]::new($codex)
    $psi.ArgumentList.Add('app-server')
    $psi.WorkingDirectory       = $cwd
    $psi.UseShellExecute        = $false
    $psi.RedirectStandardInput  = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.StandardInputEncoding  = $Utf8NoBom
    $psi.StandardOutputEncoding = $Utf8NoBom
    $psi.StandardErrorEncoding  = $Utf8NoBom
    foreach ($k in @('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'http_proxy', 'https_proxy', 'all_proxy')) { $psi.Environment[$k] = 'http://127.0.0.1:9' }
    foreach ($k in @('NO_PROXY', 'no_proxy')) { [void]$psi.Environment.Remove($k) }
    try {
        $p = [Diagnostics.Process]::Start($psi)
        $null = $p.StandardError.ReadToEndAsync()          # 不讀的話它的 log 寫滿管線就卡住
        $init = [ordered]@{ id = 1; method = 'initialize'; params = [ordered]@{ clientInfo = [ordered]@{ name = 'codex-sdlc'; title = $null; version = '1' }; capabilities = $null } }
        $p.StandardInput.WriteLine(($init | ConvertTo-Json -Depth 5 -Compress))
        $p.StandardInput.WriteLine('{"method":"initialized","params":{}}')
        $p.StandardInput.Flush()
        return [pscustomobject]@{ process = $p; next = 2; broken = $false }
    } catch { return $null }
}

function Invoke-AppServerRequest($session, [string]$method, $params, [int]$timeoutMs = 15000) {
    if (-not $session -or $session.broken) { return $null }
    $id = $session.next; $session.next++
    $p = $session.process
    try {
        $p.StandardInput.WriteLine(([ordered]@{ id = $id; method = $method; params = $params } | ConvertTo-Json -Depth 8 -Compress))
        $p.StandardInput.Flush()
        $deadline = [DateTime]::UtcNow.AddMilliseconds($timeoutMs)
        while ($true) {
            $left = ($deadline - [DateTime]::UtcNow).TotalMilliseconds
            if ($left -le 0) { $session.broken = $true; return $null }
            $t = $p.StandardOutput.ReadLineAsync()
            if (-not $t.Wait([int][Math]::Ceiling($left))) { $session.broken = $true; return $null }
            $line = $t.Result
            if ($null -eq $line) { $session.broken = $true; return $null }
            $msg = $null
            try { $msg = $line | ConvertFrom-Json } catch { continue }
            if ($msg -and $msg.PSObject.Properties['id'] -and $msg.id -eq $id) { return $msg }
        }
    } catch {
        $session.broken = $true
        return $null
    }
}

function Stop-CodexAppServer($session) {
    if (-not $session) { return }
    $p = $session.process
    try { if (-not $p.HasExited) { $p.Kill($true) } } catch { }
    $p.Dispose()
}

function Invoke-CodexHooksList([string]$codex, [string]$cwd, [int]$timeoutMs = 15000) {
    $s = Start-CodexAppServer $codex $cwd
    try { return Invoke-AppServerRequest $s 'hooks/list' ([ordered]@{ cwds = @($cwd) }) $timeoutMs }
    finally { Stop-CodexAppServer $s }
}

# ---- 組織政策：只允許管理員部署的 hooks ----
# requirements.toml 的 allow_managed_hooks_only = true 時，Codex 一律略過專案的 hooks.json —— 不會出現「Hooks need review」，
# 也就沒有東西可以按信任。修法不在使用者手上：管理員把 sdlc.ps1 managed-hooks 產生的那一份登記成 managed hooks。
# 只讀得到系統那一份（%ProgramData%\OpenAI\Codex\requirements.toml、/etc/codex/requirements.toml）；雲端與 MDM 下發的看不到。
$HookScriptNames = @('handoff-lint', 'dlp-gate', 'guideline-gate', 'build-check')
function Get-ManagedHooksPolicy {
    $path = if ($IsWindows -or $env:OS -eq 'Windows_NT') { if ($env:ProgramData) { Join-Path $env:ProgramData 'OpenAI\Codex\requirements.toml' } } else { '/etc/codex/requirements.toml' }
    $p = [ordered]@{ path = $path; readable = $false; managedOnly = $false; ours = @() }
    if (-not $path -or -not (Test-Path -LiteralPath $path -PathType Leaf)) { return $p }
    try { $text = [IO.File]::ReadAllText($path) } catch { return $p }
    $p.readable = $true
    $p.managedOnly = $text -match '(?m)^\s*allow_managed_hooks_only\s*=\s*true\b'
    $p.ours = @([regex]::Matches($text, '(?i)(handoff-lint|dlp-gate|guideline-gate|build-check)\.ps1[''"]?\s+-Managed') | ForEach-Object { $_.Groups[1].Value.ToLowerInvariant() } | Sort-Object -Unique)
    return $p
}

function Get-HookTrust([string]$target) {
    $policy = Get-ManagedHooksPolicy
    $hooksFile = Join-Path $target $HooksRel
    if (-not (Test-Path $hooksFile)) { return [ordered]@{ status = 'no-hooks'; codex = $null; policy = $policy } }
    # **預設不問。** 問它要另外叫起一個 `codex app-server` 子行程（最久 15 秒），而它回答的問題
    # 不是 doctor 修得了的 —— 修法永遠是同一句「去 codex 裡信任」。要查就明講 -CheckHookTrust，
    # doctor 的收尾會告訴你這個參數在哪。
    # **檔在不在照查** —— hooks.json 不見是工具檔缺了，不是信任問題，而那一條有得修（補回工具檔）。
    if (-not $CheckHookTrust) { return [ordered]@{ status = 'skipped'; codex = $null; policy = $policy } }
    $codex = Resolve-Codex -IncludeEditor
    if (-not $codex) { return [ordered]@{ status = 'unknown'; reason = 'codex-not-found'; codex = $null; policy = $policy } }

    $root = (Resolve-Path $target).Path
    $msg = Invoke-CodexHooksList $codex $root
    if (-not $msg -or -not $msg.result) {
        return [ordered]@{ status = 'unknown'; reason = $(if ($msg -and $msg.error) { 'query-failed' } else { 'no-response' }); codex = $codex; policy = $policy }
    }

    $mine = @(Get-ProjectHookEntries $msg $hooksFile)
    $counts = [ordered]@{
        total     = $mine.Count
        trusted   = @($mine | Where-Object { $_.trustStatus -in @('trusted', 'managed') -and $_.enabled -ne $false }).Count
        untrusted = @($mine | Where-Object trustStatus -eq 'untrusted').Count
        modified  = @($mine | Where-Object trustStatus -eq 'modified').Count
        disabled  = @($mine | Where-Object { $_.enabled -eq $false }).Count
    }
    # 管理員部署的那一份（sdlc.ps1 managed-hooks）：Codex 標成 managed，政策直接信任，不必按。
    $hookRe = '(?i)(handoff-lint|dlp-gate|guideline-gate|build-check)\.ps1'
    $managed = @($msg.result.data | ForEach-Object { @($_.hooks) } |
                 Where-Object { $_ -and ($_.isManaged -eq $true -or $_.trustStatus -eq 'managed') -and [string]$_.command -match $hookRe })
    if ($managed.Count) {
        $names = @($managed | ForEach-Object { [regex]::Match([string]$_.command, $hookRe).Groups[1].Value.ToLowerInvariant() } | Sort-Object -Unique)
        $dm = [regex]::Match([string]$managed[0].command, "(?i)['`"]?([^'`"]+?)[\\/]$($hookRe.Substring(4))")
        $dir = if ($dm.Success) { $dm.Groups[1].Value.Trim() } else { $null }
        $verFile = if ($dir) { Join-Path $dir 'VERSION' } else { $null }
        $ver = if ($verFile -and (Test-Path -LiteralPath $verFile -PathType Leaf)) { ([IO.File]::ReadAllText($verFile)).Trim() } else { $null }
        return [ordered]@{ status = 'managed'; codex = $codex; counts = $counts; policy = $policy
                           managed = [ordered]@{ dir = $dir; version = $ver; present = $names; missing = @($HookScriptNames | Where-Object { $_ -notin $names }) } }
    }
    # hooks.json 在、Codex 卻一條都沒列出來 = 專案本身沒被信任（專案層的 config 與 hooks 整個停用）——
    # 或組織政策只允許 managed hooks：看得到政策檔就直接講是政策，不叫人去按一個不存在的按鈕。
    $status = if ($mine.Count -eq 0) { if ($policy.managedOnly) { 'managed-only' } else { 'project-untrusted' } }
              elseif ($counts.trusted -eq $counts.total) { 'trusted' }
              else { 'untrusted' }
    return [ordered]@{ status = $status; codex = $codex; counts = $counts; policy = $policy }
}

function Show-ManagedOnlyPolicy($policy) {
    $have = if ($policy.ours.Count) { "它只登記了 $($policy.ours -join '、')。" } else { '它沒有登記這套工作流的 hooks。' }
    Warn "組織政策只允許管理員部署的 hooks（$($policy.path) 的 allow_managed_hooks_only）—— 專案的 hooks.json 一律被略過，不會出現「Hooks need review」，也沒有東西可以按。$have 請管理員部署：pwsh .codex/scripts/sdlc.ps1 managed-hooks -OutDir <資料夾> 產生腳本與 requirements 片段。在那之前寫檔與委派沒有人當下擋；⑥ 的 delivery-check 會在交付前補跑殘留掃描與規範的 block 規則。"
    # 管理員不部署時，不靠他就做得到的那一層（git 不歸這個政策管）。
    # 裝好了就不再講（doctor 的 Show-GitHooks 會報一行）。
    $gh = Get-GitHooksStatus $Target
    $ok = @($gh.repos | Where-Object { $_.status -in @('installed', 'outdated') })
    if ($gh.marker -and $ok.Count -and $ok.Count -eq @($gh.repos).Count) { return }
    Warn "管理員不部署的話，不靠他也做得到的一層：pwsh .codex/scripts/sdlc.ps1 git-hooks —— commit 前補跑殘留掃描、規範的 block 規則與 build（git 不歸這個政策管），委派前改由 orchestrator 自己跑 handoff-lint。"
}

function Show-HookTrust($trust) {
    switch ($trust.status) {
        'trusted' {
            Say "Codex hooks：$($trust.counts.total) 條都已信任 —— 機械強制層會跑。"
            return 0
        }
        'untrusted' {
            $c = $trust.counts
            $parts = @()
            if ($c.untrusted) { $parts += "$($c.untrusted) 條未信任" }
            if ($c.modified)  { $parts += "$($c.modified) 條改過、待重新審核" }
            if ($c.disabled)  { $parts += "$($c.disabled) 條被停用" }
            Warn "Codex 還沒信任這個專案的 hooks（$($parts -join '、')）—— 沒信任的那幾條（handoff-lint／dlp-gate／guideline-gate／build-check）一次都不會跑，而且不會有任何提示。$TrustHint"
            return 1
        }
        'project-untrusted' {
            Warn "Codex 還沒信任這個專案 —— 專案層的 .codex/config.toml 與 hooks 整個停用，機械強制層一條都不會跑。$TrustHint 資料夾已經信任、卻從來沒出現過「Hooks need review」的話，多半是組織政策只允許管理員部署的 hooks（雲端下發的政策這裡看不到）—— 見 sdlc.ps1 managed-hooks。"
            return 1
        }
        'managed-only' { Show-ManagedOnlyPolicy $trust.policy; return 1 }
        'managed' {
            $m = $trust.managed
            $v = Get-ContractVersion $Target
            if ($m.missing.Count) {
                Warn "Codex hooks 由管理員部署（managed，$($m.dir)），但少了 $($m.missing -join '、') —— 那幾道沒有人擋。請管理員照 sdlc.ps1 managed-hooks 產生的 requirements 片段補上。"
                return 1
            }
            if ($m.version -and $v -and (Compare-Semver ($m.version -replace '^(\d+\.\d+).*', '$1.0') ([string]$v.contract -replace '^(\d+\.\d+).*', '$1.0')) -ne 0) {
                Warn "Codex hooks 由管理員部署（managed，$($m.dir)），版本是 $($m.version)，這個專案是 $($v.contract) —— hook 與工作流的規則可能對不上。請管理員用這個專案那一版的 sdlc.ps1 managed-hooks 重新部署。"
                return 1
            }
            Say "Codex hooks：由管理員部署（managed，$($m.dir)$(if ($m.version) { "，$($m.version)" })），政策直接信任，不必按 —— 機械強制層會跑。"
            return 0
        }
        # 預設沒查。不算問題，但**一定要說一句** —— 不說的話，「doctor 全綠」會被讀成
        # 「強制層在跑」，而那正是這套工作流最貴的一個誤會（沒信任的 hook 一條都不跑，也不提示）。
        'skipped' {
            # 政策檔讀得到就照講 —— 不必叫起 codex，而「去按信任」在這種環境是錯的修法。
            if ($trust.policy.managedOnly -and $trust.policy.ours.Count -lt $HookScriptNames.Count) { Show-ManagedOnlyPolicy $trust.policy; return 1 }
            if ($trust.policy.managedOnly) { Say "組織政策只允許管理員部署的 hooks（$($trust.policy.path)），而它登記了這套工作流的四支 —— 不必按信任。要確認 Codex 真的載入了：doctor -CheckHookTrust。"; return 0 }
            Say 'Codex hooks 的信任狀態：這次沒查（要查：doctor -CheckHookTrust，它會另外叫起一次 codex）。沒信任的 hook 一條都不會跑，而且不會提示 —— 要直接信任：sdlc.ps1 trust-hooks。'
            return 0
        }
        'unknown' {
            $why = if ($trust.reason -eq 'codex-not-found') { '找不到 codex 執行檔' } else { '問 codex 沒有得到回應' }
            Say "無法確認 Codex 是否信任了這個專案的 hooks（$why）。信任狀態只有 Codex 自己知道；沒信任的話強制層不會跑。$TrustHint"
            return 0
        }
        # 檔不在 = 機械強制層整層不存在，而且沒有任何跡象。這裡不自己產生一份：內容屬於發佈物
        # （在這支腳本裡再放一份就是第二份真相，而 agent-lint 檢查 12 驗的是 hooks.json 本身），
        # 而且新寫出來的檔還要使用者去 Codex 重新信任 —— 靜默產生只會讓人以為已經在擋了。
        'no-hooks' {
            Warn "$HooksRel 不在 —— 機械強制層整層不存在：handoff-lint／dlp-gate／guideline-gate／build-check 一支都不會跑，寫檔與委派完全沒有人擋，而且 Codex 不會提示。把發佈物解壓到別處，跑 update -Target <這個專案> 把工具檔補回來（或重跑一次 install）。"
            return 1
        }
        default { return 0 }
    }
}

# ---- 替使用者信任 hooks：trust-hooks（4.28.0）----
#
# 「Hooks need review」只出現在終端機的 Codex。只用 VS Code 的 Codex chat 的人永遠看不到它，而沒信任的 hook
# 一條都不跑、也不提示 —— 那些人的強制層從裝好那一刻起就不在。所以這裡用 Codex 自己的 app-server 寫信任
# （0.162.1 實測，隔離的 CODEX_HOME）：
#   1. hooks/list 列不出這個專案的 hooks = 專案本身沒信任 → config/value/write `projects."<專案>".trust_level = "trusted"`
#   2. hooks/list 的每一條帶 key 與 currentHash → config/batchWrite `hooks.state."<key>".trusted_hash = currentHash`
#   3. 再 hooks/list 一次：每一條都回 trusted 才算數（寫成功不等於 Codex 認）
# 雜湊不自己算（拿 Codex 回的 currentHash），config.toml 也不自己改（app-server 寫它自己的）—— 跟在終端機按
# Trust all 寫的是同一個地方、同一個值。
#
# 這等於替使用者做了一次審核，所以**只信任這套工作流自己的那幾條**：Codex 列出來的 command 逐字是 hooks.json
# 出貨的兩種寫法之一、指向 .codex/scripts 底下那四支腳本。其他的（使用者自己加的、指令被改過的）一條都不碰，
# 留給人在 Codex 裡審。腳本**內容**本來就不在 Codex 的信任範圍裡（改 .ps1 不會讓信任失效，版本檔 v48-enforcement），
# 所以「指令指向我們的腳本」就是 Codex 的審核在這裡能保證的全部。
# hooks.json 的指令一改寫法，這條就認不得 —— test-sdlc.ps1 拿真的 hooks.json 跑一次 trust-hooks 守著。
$OwnHookCommandRe = '^(?:pwsh -NoProfile -ExecutionPolicy Bypass -File \.codex/scripts/(?<n>handoff-lint|dlp-gate|guideline-gate|build-check)\.ps1|\$env:PSExecutionPolicyPreference=''Bypass''; & \./\.codex/scripts/(?<n>handoff-lint|dlp-gate|guideline-gate|build-check)\.ps1; exit \$LASTEXITCODE)$'
$TrustHint = '要信任：跑 pwsh .codex/scripts/sdlc.ps1 trust-hooks（VS Code 的 Codex chat 不會出現審核畫面，用這個）；或在終端機的專案目錄開 codex，出現「Hooks need review」時選 Trust all and continue。'

function Get-OwnHookScript([string]$command) {
    $m = [regex]::Match($command, $OwnHookCommandRe)
    return $(if ($m.Success) { $m.Groups['n'].Value } else { $null })
}

# config 的 keyPath 一段：雙引號、反斜線與引號跳脫（實測 Codex 照 TOML basic string 解，寫出來是單引號的 literal key）。
function ConvertTo-ConfigKeySegment([string]$s) { return '"' + $s.Replace('\', '\\').Replace('"', '\"') + '"' }

function Get-ProjectHookEntries($listMsg, [string]$hooksFile) {
    $want = ((Resolve-Path -LiteralPath $hooksFile).Path -replace '\\', '/').ToLowerInvariant()
    return @($listMsg.result.data | ForEach-Object { @($_.hooks) } |
             Where-Object { $_ -and ([string]$_.sourcePath -replace '\\', '/').ToLowerInvariant() -eq $want })
}

# hooks.json 自己寫了什麼（還沒信任專案時 Codex 一條都不列，確認畫面只能看檔）。
# 兩種寫法（command／commandWindows）都要是我們的才算 —— 只看其中一種，另一個平台跑的就是沒人看過的指令。
function Get-LocalHookEntries([string]$hooksFile) {
    $doc = Read-JsonFile $hooksFile
    if (-not $doc -or -not $doc.PSObject.Properties['hooks'] -or -not $doc.hooks) { return @() }
    return @(foreach ($ev in $doc.hooks.PSObject.Properties) {
        foreach ($g in @($ev.Value)) {
            foreach ($h in @($g.hooks)) {
                if (-not $h) { continue }
                $cmds = @(foreach ($k in @('command', 'commandWindows')) { if ($h.PSObject.Properties[$k] -and $h.$k) { [string]$h.$k } })
                $names = @($cmds | ForEach-Object { Get-OwnHookScript $_ } | Sort-Object -Unique)
                $own = if ($cmds.Count -and $names.Count -eq 1 -and @($cmds | Where-Object { -not (Get-OwnHookScript $_) }).Count -eq 0) { $names[0] } else { $null }
                [pscustomobject]@{ event = $ev.Name; script = $own; command = $(if ($cmds.Count) { $cmds[-1] } else { '' }) }
            }
        }
    })
}

function ConvertTo-HookReport($entries) {
    return @($entries | ForEach-Object {
        [ordered]@{ event = [string]$_.eventName; script = (Get-OwnHookScript ([string]$_.command)); trustStatus = [string]$_.trustStatus; enabled = ($_.enabled -ne $false) }
    })
}

# 回 data：result 是 trusted｜already-trusted｜nothing-to-trust｜cancelled｜no-hooks｜managed-only｜codex-not-found｜
# no-response｜write-failed｜project-untrusted（寫了專案信任，Codex 還是不載入）｜partial（寫了，再問還有沒信任的）。
# $consented：install／update 帶 -TrustHooks、或 trust-hooks 帶 -Yes —— 同意已經給了，不再問。
function Invoke-HookTrustWrite([string]$target, [bool]$consented) {
    $out = [ordered]@{ result = $null; codex = $null; projectTrusted = $false; written = 0; hooks = @(); foreign = @(); disabled = 0 }
    $hooksFile = Join-Path $target $HooksRel
    if (-not (Test-Path -LiteralPath $hooksFile -PathType Leaf)) {
        $out.result = 'no-hooks'
        Warn "$HooksRel 不在 —— 沒有 hooks 可以信任。先用發佈物把工具檔補回來（update -Target <這個專案>）。"
        return $out
    }
    $local = @(Get-LocalHookEntries $hooksFile)
    $localOwn = @($local | Where-Object script)
    $localForeign = @($local | Where-Object { -not $_.script })
    if (-not $localOwn.Count) {
        $out.result = 'nothing-to-trust'
        Say "$HooksRel 裡沒有這套工作流的 hook，沒有要信任的。"
        return $out
    }
    $policy = Get-ManagedHooksPolicy
    if ($policy.managedOnly) { $out.result = 'managed-only'; Show-ManagedOnlyPolicy $policy; return $out }
    $codex = Resolve-Codex -IncludeEditor
    $out.codex = $codex
    if (-not $codex) {
        $out.result = 'codex-not-found'
        Warn '找不到 codex 執行檔（PATH 上沒有，OpenAI 的 VS Code 擴充裡也沒找到）—— 信任要由 Codex 自己寫，沒有它寫不了。加 -CodexPath <codex 的完整路徑> 再跑一次，或在終端機開 codex，出現「Hooks need review」時選 Trust all and continue。'
        return $out
    }

    $root = (Resolve-Path -LiteralPath $target).Path
    $s = Start-CodexAppServer $codex $root
    try {
        $list = Invoke-AppServerRequest $s 'hooks/list' ([ordered]@{ cwds = @($root) })
        if (-not $list -or -not $list.PSObject.Properties['result'] -or -not $list.result) {
            $out.result = 'no-response'
            Warn "問 Codex（$codex app-server）沒有得到回應，什麼都沒寫。在終端機開 codex，出現「Hooks need review」時選 Trust all and continue。"
            return $out
        }
        $mine = @(Get-ProjectHookEntries $list $hooksFile)
        $needProject = $mine.Count -eq 0
        $pending = @($mine | Where-Object { (Get-OwnHookScript ([string]$_.command)) -and $_.trustStatus -in @('untrusted', 'modified') })
        if (-not $needProject -and -not $pending.Count) {
            $out.result = 'already-trusted'
            $out.hooks = @(ConvertTo-HookReport @($mine | Where-Object { Get-OwnHookScript ([string]$_.command) }))
            $out.foreign = @(ConvertTo-HookReport @($mine | Where-Object { -not (Get-OwnHookScript ([string]$_.command)) }))
            Say "Codex hooks：這套工作流的 $(@($out.hooks).Count) 條都已經信任了，沒有要寫的。"
            Show-TrustLeftovers $out
            return $out
        }

        # 寫之前先講清楚會寫什麼 —— 這一步取代的是 Codex 的審核畫面。
        Say '要替你在 Codex 信任：'
        if ($needProject) { Say "  資料夾 $root（Codex 從此載入它的 .codex/config.toml 與 hooks.json）" }
        $show = if ($needProject) { $localOwn } else { @($pending | ForEach-Object { [pscustomobject]@{ event = $_.eventName; script = (Get-OwnHookScript ([string]$_.command)) } }) }
        foreach ($h in $show) { Say "  hook  $($h.event) → .codex/scripts/$($h.script).ps1" }
        if ($localForeign.Count) { Say "不會碰（不是這套工作流的，留給你在 Codex 裡審）：$(@($localForeign | ForEach-Object { "$($_.event) $($_.command)" }) -join '；')" }
        Say '寫進 Codex 的使用者設定（~/.codex/config.toml，由 codex app-server 自己寫，跟在 Codex 裡按 Trust all 是同一件事）。'
        if (-not $consented -and -not (Confirm-Step '要替你信任嗎？')) {
            $out.result = 'cancelled'
            Say '已取消，什麼都沒寫。'
            return $out
        }

        if ($needProject) {
            $w = Invoke-AppServerRequest $s 'config/value/write' ([ordered]@{ keyPath = "projects.$(ConvertTo-ConfigKeySegment $root).trust_level"; mergeStrategy = 'upsert'; value = 'trusted' })
            if (-not $w -or -not $w.PSObject.Properties['result'] -or -not $w.result) {
                $out.result = 'write-failed'
                Warn "Codex 沒有接受「信任這個資料夾」的寫入$(if ($w -and $w.PSObject.Properties['error']) { "（$($w.error.message)）" })，什麼都沒寫。在終端機開 codex，信任這個資料夾並在「Hooks need review」選 Trust all and continue。"
                return $out
            }
            $out.projectTrusted = $true
            $list = Invoke-AppServerRequest $s 'hooks/list' ([ordered]@{ cwds = @($root) })
            $mine = if ($list -and $list.PSObject.Properties['result'] -and $list.result) { @(Get-ProjectHookEntries $list $hooksFile) } else { @() }
            if (-not $mine.Count) {
                $out.result = 'project-untrusted'
                Warn "寫了「信任 $root」，但 Codex 還是沒有載入這個專案的 hooks —— 多半是它認的專案根不是這一層（例如這裡在另一個 git repo 裡面），或組織政策只允許管理員部署的 hooks。在終端機的這個目錄開 codex，照它的提示信任。"
                return $out
            }
            $pending = @($mine | Where-Object { (Get-OwnHookScript ([string]$_.command)) -and $_.trustStatus -in @('untrusted', 'modified') })
        }

        if ($pending.Count) {
            $edits = @($pending | ForEach-Object { [ordered]@{ keyPath = "hooks.state.$(ConvertTo-ConfigKeySegment ([string]$_.key)).trusted_hash"; mergeStrategy = 'upsert'; value = [string]$_.currentHash } })
            $w = Invoke-AppServerRequest $s 'config/batchWrite' ([ordered]@{ edits = $edits; reloadUserConfig = $true })
            if (-not $w -or -not $w.PSObject.Properties['result'] -or -not $w.result) {
                $out.result = 'write-failed'
                Warn "Codex 沒有接受 hooks 信任的寫入$(if ($w -and $w.PSObject.Properties['error']) { "（$($w.error.message)）" })。在終端機開 codex，出現「Hooks need review」時選 Trust all and continue。"
                return $out
            }
            $out.written = $edits.Count
        }

        # 寫成功不等於 Codex 認：再問一次，以它的回答為準。
        $list = Invoke-AppServerRequest $s 'hooks/list' ([ordered]@{ cwds = @($root) })
        $mine = if ($list -and $list.PSObject.Properties['result'] -and $list.result) { @(Get-ProjectHookEntries $list $hooksFile) } else { @() }
        $ours = @($mine | Where-Object { Get-OwnHookScript ([string]$_.command) })
        $out.hooks = @(ConvertTo-HookReport $ours)
        $out.foreign = @(ConvertTo-HookReport @($mine | Where-Object { -not (Get-OwnHookScript ([string]$_.command)) }))
        $bad = @($ours | Where-Object { $_.trustStatus -ne 'trusted' })
        if (-not $ours.Count -or $bad.Count) {
            $out.result = 'partial'
            Warn "寫了，但再問 Codex 時這套工作流的 hooks 還有 $(if ($ours.Count) { "$($bad.Count) 條不是 trusted（$(@($bad | ForEach-Object { "$($_.eventName) $($_.trustStatus)" }) -join '、')）" } else { '一條都沒列出來' }) —— 那幾道不會跑。在終端機開 codex，出現「Hooks need review」時選 Trust all and continue；之後用 doctor -CheckHookTrust 確認。"
            return $out
        }
        $out.result = 'trusted'
        Say "Codex hooks：替你信任了 $($ours.Count) 條（$(@($ours | ForEach-Object { Get-OwnHookScript ([string]$_.command) } | Sort-Object -Unique) -join '、')）$(if ($out.projectTrusted) { '，也信任了這個資料夾' }) —— 機械強制層會跑。已經開著的 Codex 對話要開一個新的（或重新載入 VS Code 視窗）才會載入。"
        Show-TrustLeftovers $out
        return $out
    } finally {
        Stop-CodexAppServer $s
    }
}

# 信任了也不會跑的兩種：別人的 hook（沒替它信任）、被停用的（enabled = false，多半是有人在 Codex 裡關掉的，不替他打開）。
function Show-TrustLeftovers($out) {
    $out.disabled = @($out.hooks | Where-Object { -not $_.enabled }).Count
    if ($out.disabled) { Warn "這套工作流有 $($out.disabled) 條 hook 在 Codex 裡被停用了 —— 信任了也不會跑。沒有替你打開（多半是有人刻意關的）；要開就在 Codex 的 hooks 設定裡打開。" }
    $pend = @($out.foreign | Where-Object { $_.trustStatus -ne 'trusted' })
    if ($pend.Count) { Say "另外有 $($pend.Count) 條不是這套工作流的 hook 還沒信任 —— 沒有替你信任，要讓它們跑就在 Codex 裡審核。" }
}

function Invoke-TrustHooks {
    $r = Invoke-HookTrustWrite $Target ([bool]$Yes)
    foreach ($k in $r.Keys) { $script:Data[$k] = $r[$k] }
    return $(if ($r.result -in @('trusted', 'already-trusted', 'nothing-to-trust')) { 0 } else { 2 })
}

# ---- hooks 有沒有真的在跑：心跳 vs. agent 的產出 ----
#
# 信任狀態只有 Codex 知道，問它要另外叫起一個 codex（最久 15 秒），所以 doctor 預設不問。但「沒在跑」看得到痕跡：
# agent 每寫一次檔，PostToolUse 的三支 gate 就會各寫一次心跳（Write-HookHeartbeat）。agent 的產出比最新的心跳還新 →
# 那幾次寫檔沒有任何一支 hook 跑 —— 沒信任、hooks.json 改過待重審、叫不起 pwsh，症狀都是這一個，而且都沒有提示。
# 不叫子行程、只讀檔的修改時間，所以 VS Code 的背景健檢也付得起。
#
# 只拿 agent 才會寫的檔當證據（地圖、分析、現況、審核、DB 證據、契約）：spec.md 會被人在編輯器裡改，
# 拿它當證據，人改一次就喊一次「hooks 沒在跑」。data-model.md（v4.27.0）同理不算：③ 使用者可以直接改那份表格。起點是最後一次裝／升級（基準線）或 hooks.json 被換掉的時間 ——
# 更早的產出是舊版（還沒有心跳）寫的，不算數；而 hooks.json 一換，Codex 就要重新信任，正是要盯的那一刻。
# 剛寫的兩分鐘內不下結論：hook 是寫完才跑，背景健檢可能搶在心跳之前讀。
$HeartbeatGraceSec = 120

function Get-HookHeartbeat([string]$target) {
    $root = (Resolve-Path $target).Path
    $none = [ordered]@{ status = 'no-hooks'; lastRun = $null; lastOutput = $null; since = $null }
    $hooksFile = Join-Path $root $HooksRel
    if (-not (Test-Path $hooksFile)) { return $none }

    $since = [IO.File]::GetLastWriteTimeUtc($hooksFile)
    $baseFile = Join-Path $root $BaselineRel
    if (Test-Path $baseFile) { $b = [IO.File]::GetLastWriteTimeUtc($baseFile); if ($b -gt $since) { $since = $b } }

    $beat = @(Get-ChildItem (Join-Path $root $HeartbeatRel) -Filter '*.last' -File -ErrorAction SilentlyContinue |
              Sort-Object LastWriteTimeUtc | Select-Object -Last 1)
    $lastRun = if ($beat.Count) { $beat[0].LastWriteTimeUtc } else { $null }

    $docs = Join-Path $root 'bdd-docs'
    $evidence = @()
    if (Test-Path (Join-Path $docs 'project-map.md')) { $evidence += Get-Item (Join-Path $docs 'project-map.md') }
    foreach ($f in @(Get-ChildItem $docs -Directory -ErrorAction SilentlyContinue | Where-Object { -not $_.Name.StartsWith('.') })) {
        $evidence += @(Get-ChildItem $f.FullName -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -in @('analysis.md', 'current-state.md', 'review.md') })
        foreach ($sub in @('evidence', 'contract')) {
            $evidence += @(Get-ChildItem (Join-Path $f.FullName $sub) -File -Recurse -ErrorAction SilentlyContinue)
        }
    }
    $newest = @($evidence | Where-Object { $_.LastWriteTimeUtc -gt $since } | Sort-Object LastWriteTimeUtc | Select-Object -Last 1)

    $out = [ordered]@{
        status     = 'no-activity'
        lastRun    = $(if ($lastRun) { $lastRun.ToString('o') } else { $null })
        lastOutput = $null
        since      = $since.ToString('o')
    }
    if (-not $newest.Count) { return $out }
    $w = $newest[0]
    $out.lastOutput = [ordered]@{ path = (ConvertTo-Rel $root $w.FullName); at = $w.LastWriteTimeUtc.ToString('o') }
    # 2 秒的餘裕：檔案系統的時間精度，加上 Bash 寫檔時「寫完」與「hook 開始」幾乎同時。
    if ($lastRun -and $lastRun -ge $w.LastWriteTimeUtc.AddSeconds(-2)) { $out.status = 'running' }
    elseif (([DateTime]::UtcNow - $w.LastWriteTimeUtc).TotalSeconds -lt $HeartbeatGraceSec) { $out.status = 'pending' }
    else { $out.status = 'silent' }
    return $out
}

function Show-HookHeartbeat($hb) {
    $fmt = { param($iso) ([DateTime]::Parse($iso, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::RoundtripKind)).ToLocalTime().ToString('yyyy-MM-dd HH:mm') }
    switch ($hb.status) {
        'running' {
            Say "hooks 有在跑：最近一次 $(& $fmt $hb.lastRun)，agent 之後寫的產出都有 hook 跟著跑。"
            return 0
        }
        'pending' {
            Say "hooks 有沒有在跑：$($hb.lastOutput.path) 剛被寫過，hook 可能還在跑 —— 過兩分鐘再跑一次 doctor 才判得準。"
            return 0
        }
        'no-activity' {
            Say 'hooks 有沒有在跑：裝好（或 hooks.json 換過）之後 agent 還沒寫過產出，判不出來 —— 在 Codex 裡跑過一個需求之後，doctor 就看得出來。'
            return 0
        }
        'silent' {
            $last = if ($hb.lastRun) { "最後一次是 $(& $fmt $hb.lastRun)" } else { '一次都沒有' }
            Warn "hooks 好像沒在跑：$($hb.lastOutput.path) 在 $(& $fmt $hb.lastOutput.at) 被 agent 寫過，但之後沒有任何一支 hook 跑（$last）—— 那段時間寫檔與委派沒有人擋。最常見的原因是 Codex 還沒信任 hooks（或 hooks.json 換過、待重新審核）：跑 sdlc.ps1 trust-hooks 替你信任（或在終端機開 codex，出現「Hooks need review」時選 Trust all and continue）。其次是 Codex 叫不起 pwsh。要確認信任狀態：doctor -CheckHookTrust。那個檔如果是你自己手動改的，可以忽略這一條。"
            return 1
        }
        default { return 0 }
    }
}

# ---- 模型清單：model／effort 能用哪些，問這台實際會跑的那個 Codex ----
#
# sdlc.config.json 是全隊共用的，Codex 卻是各台各裝各的，而每一版內建的模型清單都不一樣（0.154.0 → 0.162.1：
# 拿掉 gpt-5.2、gpt-5.4，多了 gpt-6-sol、gpt-6.1-sol、gpt-6-luna），每個模型能用的 effort 也不同（gpt-5.5 只到 xhigh）。
# 在這裡手抄一份清單，答案一定會跟某一台對不上 —— 所以問它：`codex debug models`（0.154.0 起就有，離線 0.3–0.5 秒）。
# 結果按 codex 的路徑＋版本快取在這台機器上，24 小時內不重問（VS Code 的背景 doctor 一直在跑）。
# 子行程的 proxy 指向連不上的位址（同 Invoke-CodexHooksList）：有登入的人用它自己快取的那份清單，沒有就用內建的。
#
# 對不上時 Codex 怎麼做（0.154.0 與 0.162.1 用假模型實測，版本檔 v415-models）：
#   子代理的 effort 不在它的模型支援之列 → **spawn 直接失敗**（頂層對話則是靜默降到模型的上限）
#   這版 Codex 不認得的模型               → 照樣 spawn，用 fallback 的模型資料，沒有任何提示
#   agent 的 model 是 inherit              → 跟主對話同一個模型；主對話沒設模型 = 清單裡 visibility=list、priority 最小的那個
# 找不到 codex（只用 IDE 的 Codex 擴充）或它太舊、沒有 debug models → 退回 schema 的靜態清單，並且明講「沒有對 Codex 驗證」。
$ModelCatalogTtlHours = 24
$ModelCatalogMinCodex = '0.154.0'     # debug models 從這一版起才有

# 這台機器上、不屬於任何專案的狀態（模型清單的快取）。handoff-lint 讀同一個位置 —— 那邊有一份相同的兩行。
function Get-SdlcStateDir {
    if ($env:CODEX_SDLC_STATE_DIR) { return $env:CODEX_SDLC_STATE_DIR }
    return Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'codex-sdlc'
}

# 叫 codex 的子行程一律從構造上碰不到網路。值是 $null 的從環境拿掉（見 Invoke-Probe）。
function Get-NoNetEnv {
    $e = [hashtable]::new([StringComparer]::Ordinal)
    foreach ($k in @('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'http_proxy', 'https_proxy', 'all_proxy')) { $e[$k] = 'http://127.0.0.1:9' }
    foreach ($k in @('NO_PROXY', 'no_proxy')) { $e[$k] = $null }
    return $e
}

# codex --version。同一次執行只問一次（doctor 的環境段與模型清單都要它）。
$script:CodexVersionMemo = @{}
function Get-CodexVersion([string]$codex, [string]$cwd) {
    if (-not $script:CodexVersionMemo.ContainsKey($codex)) {
        $r = Invoke-Probe $codex @('--version') $cwd (Get-NoNetEnv) 10000
        $m = [regex]::Match([string]$r.stdout, '\d+\.\d+\.\d+')
        $script:CodexVersionMemo[$codex] = [pscustomobject]@{ version = $(if ($m.Success) { $m.Value } else { $null }); timedOut = $r.timedOut; exit = $r.exit }
    }
    return $script:CodexVersionMemo[$codex]
}

# 回 @{ available; reason; codex = @{ path; version }; source（live／cache）; default; models = @(@{ slug; visible; priority; defaultEffort; efforts }) }
function Get-ModelCatalog([string]$cwd) {
    $codex = Resolve-Codex
    $out = [pscustomobject]@{ available = $false; reason = $null; codex = [pscustomobject]@{ path = $codex; version = $null }; source = $null; default = $null; models = @() }
    if (-not $codex) { $out.reason = 'codex-not-found'; return $out }
    $ver = (Get-CodexVersion $codex $cwd).version
    $out.codex.version = $ver
    if (-not $ver) { $out.reason = 'no-version'; return $out }

    $cacheFile = Join-Path (Get-SdlcStateDir) 'codex-models.json'
    $doc = Read-JsonFile $cacheFile
    $fresh = $false
    if ($doc -and $doc.codex -and [string]$doc.codex.path -eq $codex -and [string]$doc.codex.version -eq $ver) {
        try { $fresh = ([DateTime]::UtcNow - ([DateTime]$doc.'read-at').ToUniversalTime()).TotalHours -lt $ModelCatalogTtlHours } catch { }
    }
    $out.source = 'cache'
    if (-not $fresh) {
        $r = Invoke-Probe $codex @('debug', 'models') $cwd (Get-NoNetEnv) 20000
        # 失敗分開講（只記結束碼，不留 codex 的輸出）：只有版本真的比門檻舊，才是「太舊」。
        $out | Add-Member -NotePropertyName exit -NotePropertyValue $r.exit
        if ($r.timedOut) { $out.reason = 'timeout'; return $out }
        if ($r.exit -ne 0) { $out.reason = $(if ((Compare-Semver $ver $ModelCatalogMinCodex) -lt 0) { 'too-old' } else { 'exit-nonzero' }); return $out }
        $raw = $null
        try { $raw = $r.stdout | ConvertFrom-Json -ErrorAction Stop } catch { $out.reason = 'invalid-json'; return $out }
        if (-not $raw -or -not $raw.PSObject.Properties['models']) { $out.reason = 'no-models'; return $out }
        $models = @(foreach ($m in @($raw.models)) {
            if (-not $m.slug) { continue }
            [ordered]@{
                slug          = [string]$m.slug
                visible       = ([string]$m.visibility -eq 'list')
                priority      = $(if ($null -ne $m.priority) { [int]$m.priority } else { [int]::MaxValue })
                defaultEffort = $(if ($m.default_reasoning_level) { [string]$m.default_reasoning_level } else { $null })
                efforts       = @(@($m.supported_reasoning_levels) | ForEach-Object { if ($_ -is [string]) { $_ } elseif ($_.effort) { [string]$_.effort } } | Where-Object { $_ })
            }
        })
        $byPriority = @($models | Where-Object { $_.visible } | Sort-Object { $_.priority })
        $doc = [ordered]@{
            codex     = [ordered]@{ path = $codex; version = $ver }
            'read-at' = [DateTime]::UtcNow.ToString('o')
            default   = $(if ($byPriority.Count) { $byPriority[0].slug } else { $null })
            models    = $models
        }
        try { Write-JsonFile $cacheFile $doc } catch { }
        $doc = $doc | ConvertTo-Json -Depth 6 | ConvertFrom-Json    # 跟從快取讀回來的是同一個形狀
        $out.source = 'live'
    }
    $out.available = $true
    $out.default = $(if ($doc.default) { [string]$doc.default } else { $null })
    $out.models = @($doc.models | Where-Object { $_ } | ForEach-Object {
        [pscustomobject]@{ slug = [string]$_.slug; visible = [bool]$_.visible; priority = [long]$_.priority; defaultEffort = $_.defaultEffort; efforts = @($_.efforts | ForEach-Object { [string]$_ }) }
    })
    return $out
}

function Find-CatalogModel($catalog, [string]$slug) {
    if (-not $catalog.available -or -not $slug) { return $null }
    return @($catalog.models | Where-Object { $_.slug -ceq $slug })[0]
}

# 所有模型的 effort 聯集，照清單裡出現的順序（low → … → ultra）—— 「往下找最接近的」靠這個順序。
function Get-CatalogEffortOrder($catalog) {
    $seen = [Collections.Generic.List[string]]::new()
    foreach ($m in @($catalog.models)) { foreach ($e in @($m.efforts)) { if (-not $seen.Contains($e)) { $seen.Add($e) } } }
    return , $seen.ToArray()
}

# config.toml 頂層（第一個 [section] 之前）的 model；有 profile 就先看那個 profile 的。
function Get-TomlModel([string]$file) {
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { return $null }
    $text = [IO.File]::ReadAllText($file)
    $top = [regex]::Split($text, '(?m)^\s*\[')[0]
    $str = '\s*=\s*(?:"([^"]+)"|''([^'']+)'')'
    $p = [regex]::Match($top, "(?m)^\s*profile$str")
    if ($p.Success) {
        $name = "$($p.Groups[1].Value)$($p.Groups[2].Value)"
        $sec = [regex]::Match($text, "(?ms)^\s*\[profiles\.$([regex]::Escape($name))\][^\r\n]*\r?\n(.*?)(?=^\s*\[|\z)")
        if ($sec.Success) {
            $pm = [regex]::Match($sec.Groups[1].Value, "(?m)^\s*model$str")
            if ($pm.Success) { return "$($pm.Groups[1].Value)$($pm.Groups[2].Value)" }
        }
    }
    $m = [regex]::Match($top, "(?m)^\s*model$str")
    return $(if ($m.Success) { "$($m.Groups[1].Value)$($m.Groups[2].Value)" } else { $null })
}

# model = inherit 的 agent 跟主對話用同一個模型（實測）。主對話的模型：專案 .codex/config.toml ＞ 使用者的 config.toml
# （CODEX_HOME，預設 ~/.codex）＞ Codex 預設。啟動時加 -m、或在 IDE 裡換了模型的，這裡看不到 ——
# 所以 spawn 當下 handoff-lint 會拿 payload 裡的模型（主對話當下用的那個）再判一次。
function Get-SessionModel([string]$root, $catalog) {
    $proj = Get-TomlModel (Join-Path $root '.codex/config.toml')
    if ($proj) { return [pscustomobject]@{ model = $proj; source = '.codex/config.toml' } }
    $codexHome = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path ([Environment]::GetFolderPath('UserProfile')) '.codex' }
    $user = Get-TomlModel (Join-Path $codexHome 'config.toml')
    if ($user) { return [pscustomobject]@{ model = $user; source = '~/.codex/config.toml' } }
    if ($catalog.available -and $catalog.default) { return [pscustomobject]@{ model = $catalog.default; source = 'Codex 預設' } }
    return [pscustomobject]@{ model = $null; source = $null }
}

# 一個 agent 的 model／effort 在這台的 Codex 上會怎樣。level：
#   problem：這台跑起來就出事 —— effort 不在模型支援之列（子代理 spawn 失敗）、這版 Codex 不認得的模型、沒有任何模型認得的 effort
#   warn   ：這台沒事，換一台或換個主對話模型就出事 —— model 是 inherit、而 effort 只有部分模型支援
#   orchestrator 的值只是記錄（主對話用什麼由啟動 codex 的人決定），而頂層對話會把 effort 靜默降到上限 —— 它的一律只算 warn。
function Test-ModelChoice($catalog, $session, [string]$agent, [string]$model, [string]$effort, [string]$checkedWith) {
    $model  = if ($model)  { $model }  else { 'inherit' }
    $effort = if ($effort) { $effort } else { 'inherit' }
    $r = [pscustomobject]@{ agent = $agent; model = $model; effort = $effort; effectiveModel = $null; status = 'ok'; level = 'ok'; message = $null; suggestion = $null; allowed = @() }
    if ($model -eq 'inherit' -and $effort -eq 'inherit') { return $r }
    if (-not $catalog.available) { $r.status = 'unverified'; $r.level = 'unverified'; return $r }
    $ver = $catalog.codex.version
    $order = Get-CatalogEffortOrder $catalog

    if ($model -ne 'inherit') {
        $m = Find-CatalogModel $catalog $model
        if (-not $m) {
            $r.status = 'unknown-model'; $r.level = $(if ($agent -eq 'orchestrator') { 'warn' } else { 'problem' })
            $ci = @($catalog.models | Where-Object { $_.slug -eq $model })[0]     # 只差大小寫
            $near = if ($ci) { $ci.slug } else { Get-ClosestText $model @($catalog.models | ForEach-Object { $_.slug }) }
            $why = if ($ci) { '模型名稱分大小寫。' }
                   elseif ($checkedWith -and (Compare-Semver $checkedWith $ver) -gt 0) { "這組值是在 Codex $checkedWith 上選的，這台是 $ver —— 升級這台的 Codex（照當初裝它的方式）。" }
                   else { "打錯了，或是新版 Codex 已經拿掉它。這台有：$(@($catalog.models | Where-Object { $_.visible } | Sort-Object { $_.priority } | ForEach-Object { $_.slug }) -join '、')。" }
            $r.message = "這台的 Codex $ver 不認得 $model —— 會用 fallback 的模型資料照跑（表現變差，或被 API 拒絕）。$why"
            if ($near) { $r.suggestion = "agents.$agent.model=$near" }
            return $r
        }
        $r.effectiveModel = $m.slug
    } else {
        $r.effectiveModel = $session.model
    }
    if ($effort -eq 'inherit') { return $r }

    if ($effort -cnotin $order) {
        $r.status = 'unknown-effort'; $r.level = $(if ($agent -eq 'orchestrator') { 'warn' } else { 'problem' })
        $r.message = "effort=$effort 不是這台 Codex $ver 任何一個模型認得的值（$($order -join '／')）"
        $near = Get-ClosestText $effort $order
        if ($near) { $r.suggestion = "agents.$agent.effort=$near" }
        return $r
    }
    $em = Find-CatalogModel $catalog $r.effectiveModel
    if ($em) {
        $r.allowed = @($em.efforts)
        if ($effort -cnotin $em.efforts) {
            # 往下找最接近的：要的比它的上限高，就給上限。
            $idx = [array]::IndexOf($order, $effort)
            $down = @($em.efforts | Where-Object { [array]::IndexOf($order, $_) -le $idx } | Sort-Object { [array]::IndexOf($order, $_) })
            $best = if ($down.Count) { $down[-1] } else { @($em.efforts)[0] }
            $why = if ($model -eq 'inherit') { "。$agent 的 model 是 inherit，跟主對話用同一個模型（來自 $($session.source)）" } else { '' }
            $r.status = 'effort-unsupported'
            $r.suggestion = "agents.$agent.effort=$best"
            if ($agent -eq 'orchestrator') {
                $r.level = 'warn'
                $r.message = "$($em.slug) 只支援 $($em.efforts -join '／') —— Codex 會把 effort=$effort 靜默降成 $best$why"
            } else {
                $r.level = 'problem'
                $r.message = "$($em.slug) 只支援 $($em.efforts -join '／') —— $agent 會起不來，Codex 會拒絕這次 spawn$why"
            }
            return $r
        }
    }
    # model 是 inherit：這台沒事，不代表別台、或主對話換了模型也沒事。
    if ($model -eq 'inherit' -and $agent -ne 'orchestrator') {
        $bad = @($catalog.models | Where-Object { $_.visible -and $effort -cnotin $_.efforts } | ForEach-Object { $_.slug })
        if ($bad.Count) {
            $r.status = 'depends-on-model'; $r.level = 'warn'
            $pin = if ($r.effectiveModel -and (Find-CatalogModel $catalog $r.effectiveModel)) { "（agents.$agent.model=$($r.effectiveModel)）" } else { '' }
            $r.message = "effort=$effort 不是每個模型都支援 —— 主對話用 $($bad -join '、') 的人，$agent 會起不來。要穩就把 model 一起釘住$pin"
        }
    }
    return $r
}

function Get-ModelFindings($catalog, $session, $cfg, [string]$root) {
    $checkedWith = if ($cfg -and $cfg.PSObject.Properties['models-checked-with']) { [string]$cfg.'models-checked-with' } else { $null }
    return @(foreach ($n in (Get-KnownAgentNames $root $cfg)) {
        $a = Get-AgentConfig $cfg $n
        Test-ModelChoice $catalog $session $n $(if ($a) { [string]$a.model } else { $null }) $(if ($a) { [string]$a.effort } else { $null }) $checkedWith
    })
}

function Get-ModelsData($catalog, $session, $findings, $cfg) {
    return [ordered]@{
        catalog = [ordered]@{
            available    = [bool]$catalog.available
            reason       = $catalog.reason
            codexPath    = $catalog.codex.path
            codexVersion = $catalog.codex.version
            source       = $catalog.source
            default      = $catalog.default
            models       = @($catalog.models | ForEach-Object { [ordered]@{ slug = $_.slug; visible = $_.visible; defaultEffort = $_.defaultEffort; efforts = @($_.efforts) } })
        }
        session     = [ordered]@{ model = $session.model; source = $session.source }
        checkedWith = $(if ($cfg -and $cfg.PSObject.Properties['models-checked-with']) { [string]$cfg.'models-checked-with' } else { $null })
        agents      = @($findings | ForEach-Object {
            [ordered]@{ agent = $_.agent; model = $_.model; effort = $_.effort; effectiveModel = $_.effectiveModel; status = $_.status; level = $_.level; message = $_.message; suggestion = $_.suggestion; allowed = @($_.allowed) }
        })
    }
}

function Get-CatalogReasonText($catalog) {
    switch ($catalog.reason) {
        'codex-not-found' { return '找不到 codex 執行檔（只用 IDE 的 Codex 擴充時是正常的；要驗就加 -CodexPath <codex 的完整路徑>）' }
        'no-version'      { return "codex --version 沒有給出版本（$($catalog.codex.path)）" }
        'timeout'         { return "codex debug models 逾時（$($catalog.codex.path)）" }
        'too-old'         { return "這版 codex（$($catalog.codex.version)）沒有 debug models，要 $ModelCatalogMinCodex 以上：$($catalog.codex.path)" }
        'exit-nonzero'    { return "codex debug models 失敗，結束碼 $($catalog.exit)（$($catalog.codex.path)，版本 $($catalog.codex.version)）" }
        'invalid-json'    { return "codex debug models 的輸出不是 JSON（$($catalog.codex.path)，版本 $($catalog.codex.version)）" }
        'no-models'       { return "codex debug models 的 JSON 裡沒有 models（$($catalog.codex.path)，版本 $($catalog.codex.version)）" }
        default           { return "問不到模型清單（$($catalog.reason)）：$($catalog.codex.path)" }
    }
}

# 一個 agent 的結論 → 一行給人看的句子（有建議就附上改法）。
function Format-ModelFinding($f) {
    $fix = if ($f.suggestion) { "。改：pwsh .codex/scripts/sdlc.ps1 set $($f.suggestion) -Apply" } else { '' }
    return "$($f.agent)：$(([string]$f.message).TrimEnd('。'))$fix"
}

# ---- 環境：跑這套流程要的工具在不在（只偵測、不安裝）----
#
# 每一項都說得出「缺了它，哪一步會壞」，說不出來的不進來 —— 什麼都查的健檢會變成永遠紅、沒人看的健檢
# （入場條件與取捨見 docs/dependency-preflight-plan.md）。
#   missing／mismatch／below-verified → 算問題（doctor 紅）。
#   unknown（查不到）／not-applicable（這個專案用不到）→ 只說明。理由同 -CheckHookTrust 的 unknown：查不到不等於有問題，但一定要講。
# 刻意不查：JDK 版本、TargetFramework 對 SDK 的主版號（④ 的第一次 build 就會給出清楚的錯誤，implementer 的規則接得住）；
# Codex 比實測版本新（見 $VerifiedCodexVersion）；
# pwsh 在不在 PATH —— doctor 自己就跑在 pwsh 7 裡，而 pwsh 7 啟動時會把自己的目錄放到 PATH 最前面（實測），
# 從這裡看出去它永遠在，查了也抓不到東西。Codex 啟動時的 PATH 裡有沒有它，只有 Codex 那一側看得到。
# 只說去哪裡裝、要哪一版，不印安裝指令：正確的修法不一定是再裝一份（git 裝了但不在 PATH 就是例子）。

function New-EnvItem($id, $name, $status, $breaks, $found = $null, $required = $null, $source = $null, $hint = $null) {
    return [ordered]@{ id = $id; name = $name; status = $status; found = $found; required = $required; source = $source; breaks = $breaks; hint = $hint }
}

function Find-Tool([string]$name) {
    $c = Get-Command $name -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    return $(if ($c) { $c.Source } else { $null })
}

# 叫一支外部程式、限時、收回輸出。$envOverrides 的值是 $null 就從子行程的環境拿掉那一個變數。
# stdin 一開始就關掉：等輸入的程式拿到 EOF 就會結束，不會卡到逾時。
function Invoke-Probe([string]$exe, [string[]]$arguments, [string]$cwd, [hashtable]$envOverrides = @{}, [int]$timeoutMs = 10000) {
    $psi = [Diagnostics.ProcessStartInfo]::new($exe)
    foreach ($a in $arguments) { $psi.ArgumentList.Add($a) }
    $psi.WorkingDirectory       = $cwd
    $psi.UseShellExecute        = $false
    $psi.RedirectStandardInput  = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    # codex 一律寫 UTF-8。不指定就用 [Console] 的 code page 解 —— 從 VS Code 叫起來時沒有 console 視窗，那是系統的
    # OEM code page（zh-TW 是 950）：codex debug models 說明文字裡的 — “ ” 會吃掉後面的引號，JSON 壞掉、清單是空的。
    $psi.StandardOutputEncoding = $Utf8NoBom
    $psi.StandardErrorEncoding  = $Utf8NoBom
    foreach ($k in $envOverrides.Keys) {
        if ($null -eq $envOverrides[$k]) { [void]$psi.Environment.Remove($k) } else { $psi.Environment[$k] = [string]$envOverrides[$k] }
    }
    $p = $null
    try {
        $p = [Diagnostics.Process]::Start($psi)
        $p.StandardInput.Close()
        $o = $p.StandardOutput.ReadToEndAsync(); $e = $p.StandardError.ReadToEndAsync()
        if (-not $p.WaitForExit($timeoutMs)) {
            try { $p.Kill($true) } catch { }
            return [pscustomobject]@{ exit = $null; stdout = ''; stderr = ''; timedOut = $true }
        }
        return [pscustomobject]@{ exit = $p.ExitCode; stdout = $o.GetAwaiter().GetResult(); stderr = $e.GetAwaiter().GetResult(); timedOut = $false }
    } catch {
        return [pscustomobject]@{ exit = $null; stdout = ''; stderr = $_.Exception.Message; timedOut = $false }
    } finally {
        if ($p) { $p.Dispose() }
    }
}

# 「腳本＋設定檔」都在才算 wrapper —— 同 repo-index.ps1 與 build-check.ps1 的 wrapper 段，三邊由測試用同一組 fixture 釘住。
function Test-ProjectWrapper([string]$root, [string[]]$scripts, [string]$props) {
    (@($scripts | Where-Object { Test-Path -LiteralPath (Join-Path $root $_) -PathType Leaf }).Count -gt 0) -and
        (Test-Path -LiteralPath (Join-Path $root $props) -PathType Leaf)
}

# git 裝了但不在 PATH 的常見位置。找到就直接說要把哪個目錄加進 PATH —— 再裝一份是錯的修法。
function Find-GitOffPath {
    $c = @()
    foreach ($r in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) { if ($r) { $c += Join-Path $r 'Git\cmd\git.exe' } }
    if ($env:LOCALAPPDATA) {
        $c += Join-Path $env:LOCALAPPDATA 'Programs\Git\cmd\git.exe'
        $c += @(Get-ChildItem (Join-Path $env:LOCALAPPDATA 'GitHubDesktop') -Directory -Filter 'app-*' -ErrorAction SilentlyContinue |
                Sort-Object Name -Descending | ForEach-Object { Join-Path $_.FullName 'resources\app\git\cmd\git.exe' })
    }
    if ($env:ProgramFiles) {
        $vs = Join-Path $env:ProgramFiles 'Microsoft Visual Studio\*\*\Common7\IDE\CommonExtensions\Microsoft\TeamFoundation\Team Explorer\Git\cmd\git.exe'
        $c += @(Resolve-Path $vs -ErrorAction SilentlyContinue | ForEach-Object { $_.Path })
    }
    return ($c | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -First 1)
}

# 專案用哪幾種 build 工具。規則同 build-check 的退化偵測（深度 3 內的專案檔），但一層一層走、跳過相依與產物的目錄 ——
# VS Code 的背景 doctor 每次都會跑這一段，在帶 node_modules 的 repo 裡整棵樹往下列三層太慢。
#
# package.json 也算（Node／TypeScript）：第一個找到的那一份所在目錄記在 $script:NodeProjectDir，給下面的 Node 項目用。
function Get-ProjectKinds([string]$root) {
    $skip = @('node_modules', 'bin', 'obj', 'packages', '.git', '.vs', 'TestResults', 'dist', 'build', 'target',
              '.next', '.nuxt', '.svelte-kit', '.angular', '.output', '.turbo', 'coverage')
    $seen = @{}
    $script:NodeProjectDir = $null
    $level = @(Get-Item -LiteralPath $root)
    for ($depth = 0; $depth -le 3 -and $level.Count -gt 0; $depth++) {
        $next = @()
        foreach ($d in $level) {
            foreach ($f in @(Get-ChildItem -LiteralPath $d.FullName -File -ErrorAction SilentlyContinue)) {
                if ($f.Extension -in @('.sln', '.csproj')) { $seen.dotnet = $true }
                elseif ($f.Name -eq 'pom.xml') { $seen.maven = $true }
                elseif ($f.Name -in @('build.gradle', 'build.gradle.kts')) { $seen.gradle = $true }
                elseif ($f.Name -eq 'package.json' -and -not $script:NodeProjectDir) { $seen.node = $true; $script:NodeProjectDir = $d.FullName }
            }
            $next += @(Get-ChildItem -LiteralPath $d.FullName -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -notin $skip })
        }
        $level = $next
    }
    $kinds = @()
    if ($seen.dotnet) { $kinds += 'dotnet' }
    if ($seen.maven) { $kinds += 'maven' } elseif ($seen.gradle) { $kinds += 'gradle' }
    if ($seen.node) { $kinds += 'node' }
    return $kinds
}

function Get-EnvironmentReport([string]$target) {
    $root = (Resolve-Path -LiteralPath $target).Path
    $items = @()

    $gitBreaks = '⑤ 檢查既有 scenario 有沒有被刪（git diff）、② 驗證系統地圖都靠它'
    $g = Find-Tool 'git'
    if ($g) { $items += New-EnvItem 'git' 'git' 'ok' $gitBreaks -found $g }
    else {
        $off = Find-GitOffPath
        $hint = if ($off) { "這台有 $off —— 把 $(Split-Path $off -Parent) 加進 PATH（啟動 Codex 的那個環境）" }
                else { '沒裝的話：https://git-scm.com/downloads。裝了但不在 PATH（例如只有 GitHub Desktop 或 Visual Studio 內附的那一份），把它的 cmd 目錄加進 PATH' }
        $items += New-EnvItem 'git' 'git' 'missing' $gitBreaks -hint $hint
    }

    # Codex：問它自己的版本。子行程的 proxy 指向連不上的位址 —— doctor 從構造上碰不到網路（同 Invoke-CodexHooksList）。
    $codexBreaks = "機械強制層（hooks.json 的形狀與 payload）是在 Codex $VerifiedCodexVersion 上實測的"
    $cx = Resolve-Codex
    if (-not $cx) {
        $items += New-EnvItem 'codex' 'Codex' 'unknown' $codexBreaks -required $VerifiedCodexVersion -source '實測版本' -hint '找不到 codex 執行檔（只用 VS Code 的 Codex 擴充時是正常的）—— 要查就加 -CodexPath <codex 的完整路徑>'
    } else {
        $cv = Get-CodexVersion $cx $root
        if (-not $cv.version) {
            $why = if ($cv.timedOut) { '逾時' } else { "exit $($cv.exit)" }
            $items += New-EnvItem 'codex' 'Codex' 'unknown' $codexBreaks -found $cx -required $VerifiedCodexVersion -source '實測版本' -hint "codex --version 沒有給出版本（$why）"
        } elseif ((Compare-Semver $cv.version $VerifiedCodexVersion) -lt 0) {
            $items += New-EnvItem 'codex' 'Codex' 'below-verified' $codexBreaks -found $cv.version -required $VerifiedCodexVersion -source '實測版本' -hint '更舊的 Codex 上，hook 可能每次都跑、一條都沒擋。照你當初裝 Codex 的方式升級（npm、VS Code 的 Codex 擴充…）'
        } else {
            $items += New-EnvItem 'codex' 'Codex' 'ok' $codexBreaks -found $cv.version -required $VerifiedCodexVersion -source '實測版本'
        }
    }

    $kinds = @(Get-ProjectKinds $root)

    # .NET：global.json 的 rollForward 交給 dotnet 自己套 —— 在專案根跑 `dotnet --version`，相容規則不在這裡重寫一遍。
    if ($kinds -contains 'dotnet') {
        $dnBreaks = '④ 的每一個 dotnet 指令（build／test）'
        $want = $null
        $gj = Read-JsonFile (Join-Path $root 'global.json')
        if ($gj -and $gj.sdk -and $gj.sdk.version) { $want = [string]$gj.sdk.version }
        $src = $(if ($want) { 'global.json' } else { $null })
        $dn = Find-Tool 'dotnet'
        if (-not $dn) {
            $items += New-EnvItem 'dotnet-sdk' '.NET SDK' 'missing' $dnBreaks -required $want -source $src -hint '裝 .NET SDK：https://dotnet.microsoft.com/download'
        } else {
            # DOTNET_NOLOGO：第一次執行的歡迎訊息不要混進版本號。
            $r = Invoke-Probe $dn @('--version') $root @{ DOTNET_NOLOGO = '1' } 20000
            $out = "$($r.stdout)`n$($r.stderr)"
            if ($r.exit -eq 0) {
                $ver = [regex]::Match([string]$r.stdout, '\d+\.\d+\.\d+\S*').Value
                $items += New-EnvItem 'dotnet-sdk' '.NET SDK' 'ok' $dnBreaks -found $ver -required $want -source $src
            } elseif ($null -eq $r.exit) {
                $why = if ($r.timedOut) { '逾時' } else { $r.stderr }
                $items += New-EnvItem 'dotnet-sdk' '.NET SDK' 'unknown' $dnBreaks -found $dn -hint "dotnet --version 沒有回應（$why）"
            } elseif ($want -or $out -match 'Requested SDK version:\s*(\S+)') {
                if (-not $want) { $want = $Matches[1] }
                $items += New-EnvItem 'dotnet-sdk' '.NET SDK' 'mismatch' $dnBreaks -required $want -source 'global.json' -hint "裝 global.json 要的 SDK $want：https://dotnet.microsoft.com/download"
            } else {
                $items += New-EnvItem 'dotnet-sdk' '.NET SDK' 'missing' $dnBreaks -found $dn -hint 'dotnet 在，但找不到可用的 SDK（只有 runtime）—— 裝 .NET SDK：https://dotnet.microsoft.com/download'
            }
        }
    }

    if ($kinds -contains 'maven' -or $kinds -contains 'gradle') {
        $jdkBreaks = '④ 的 build／test；專案自帶的 wrapper 也要它'
        $javaHome = if ($env:JAVA_HOME) { Join-Path $env:JAVA_HOME $(if ($IsWindows) { 'bin\java.exe' } else { 'bin/java' }) } else { $null }
        $jdk = if ($javaHome -and (Test-Path -LiteralPath $javaHome -PathType Leaf)) { $javaHome } else { Find-Tool 'java' }
        $items += $(if ($jdk) { New-EnvItem 'jdk' 'JDK' 'ok' $jdkBreaks -found $jdk }
                    else { New-EnvItem 'jdk' 'JDK' 'missing' $jdkBreaks -hint '裝專案要的 JDK（版本看 pom 的 maven.compiler.release 或 Gradle 的 toolchain），並設好 JAVA_HOME' })

        $t = if ($kinds -contains 'maven') {
            @{ id = 'maven'; name = 'Maven'; exe = 'mvn'; wrapper = './mvnw'; scripts = @('mvnw', 'mvnw.cmd'); props = '.mvn/wrapper/maven-wrapper.properties'; url = 'https://maven.apache.org/download.cgi' }
        } else {
            @{ id = 'gradle'; name = 'Gradle'; exe = 'gradle'; wrapper = './gradlew'; scripts = @('gradlew', 'gradlew.bat'); props = 'gradle/wrapper/gradle-wrapper.properties'; url = 'https://gradle.org/install/' }
        }
        $btBreaks = '④ 的 build／test 指令'
        $global = Find-Tool $t.exe
        if (Test-ProjectWrapper $root $t.scripts $t.props) { $items += New-EnvItem $t.id $t.name 'ok' $btBreaks -found "$($t.wrapper)（專案自帶的 wrapper）" }
        elseif ($global) { $items += New-EnvItem $t.id $t.name 'ok' $btBreaks -found $global }
        else { $items += New-EnvItem $t.id $t.name 'missing' $btBreaks -hint "裝 $($t.name)：$($t.url)（專案改用自帶的 wrapper 的話，就不必裝全域的）" }
    }

    # Node／TypeScript：node 本身＋專案用的套件管理器（lockfile／packageManager 決定，同 lib/node-project.ps1），
    # 以及依賴裝了沒 —— 沒有 node_modules 時 build-check 的型別檢查一律跳過、④ 跑不了測試，而這兩件事都不會有任何提示。
    # 依賴沒裝不算問題（unknown）：裝依賴是使用者的動作，doctor 紅著也不會讓它自己裝好。
    if ($kinds -contains 'node') {
        $nd = $script:NodeProjectDir
        $relNd = ([IO.Path]::GetRelativePath($root, $nd)) -replace '\\', '/'
        $nodeBreaks = '④ 前端的 build／test、build-check 的型別檢查'
        $node = Find-Tool 'node'
        $items += $(if ($node) { New-EnvItem 'node' 'Node.js' 'ok' $nodeBreaks -found $node }
                    else { New-EnvItem 'node' 'Node.js' 'missing' $nodeBreaks -hint '裝 Node.js：https://nodejs.org/（版本看 package.json 的 engines 或 .nvmrc）' })
        $pm = 'npm'; $pmSrc = $null
        foreach ($pair in @(@('pnpm-lock.yaml', 'pnpm'), @('yarn.lock', 'yarn'), @('bun.lock', 'bun'), @('bun.lockb', 'bun'), @('package-lock.json', 'npm'))) {
            foreach ($d in @($nd, $root) | Select-Object -Unique) {
                if (-not $pmSrc -and (Test-Path -LiteralPath (Join-Path $d $pair[0]) -PathType Leaf)) { $pm = $pair[1]; $pmSrc = $pair[0] }
            }
        }
        $pj = Read-JsonFile (Join-Path $nd 'package.json')
        if ($pj -and [string]$pj.packageManager -match '^(npm|pnpm|yarn|bun)@') { $pm = $Matches[1]; $pmSrc = 'package.json 的 packageManager' }
        $pmHint = if ($pm -in 'pnpm', 'yarn') { "裝 $pm：Node 內附的 corepack 跑一次 ``corepack enable`` 就有" } else { "裝 $pm（npm 跟著 Node 一起裝）" }
        $pmExe = Find-Tool $pm
        $items += $(if ($pmExe) { New-EnvItem 'node-package-manager' $pm 'ok' '④ 前端的 build／test 指令' -found $pmExe -source $pmSrc }
                    else { New-EnvItem 'node-package-manager' $pm 'missing' '④ 前端的 build／test 指令' -source $pmSrc -hint $pmHint })
        $installed = @(@($nd, $root) | Select-Object -Unique | Where-Object {
            (Test-Path -LiteralPath (Join-Path $_ 'node_modules') -PathType Container) -or (Test-Path -LiteralPath (Join-Path $_ '.pnp.cjs') -PathType Leaf) }).Count
        if (-not $installed) {
            $where = if ($relNd -eq '.') { '專案根' } else { $relNd }
            $items += New-EnvItem 'node-deps' '前端依賴' 'unknown' 'build-check 的型別檢查（沒裝就跳過）、④ 的測試' -hint "還沒裝（沒有 node_modules）—— 在 $where 跑一次 ``$pm install``"
        }
    }

    if ($kinds.Count -eq 0) {
        $items += New-EnvItem 'build-tool' 'build／test 工具' 'not-applicable' 'build-check 對這個專案是空轉，index.json 也不會有 build／test 指令' -hint '這套只認得 .NET（.sln／.csproj）、Java（pom.xml／build.gradle）與 Node（package.json）的專案檔；④ 的 implementer 會自己找指令'
    }
    return $items
}

# 一行一項。算問題的走 Warn（跟 doctor 其他問題一樣進 warnings），其餘只說明。回傳算問題的項數。
function Show-Environment($items) {
    $n = 0
    Say '環境：'
    foreach ($i in $items) {
        switch ($i.status) {
            'ok'             { Say "  $($i.name)：$($i.found)" }
            'unknown'        { Say "  $($i.name)：查不到 —— $($i.hint)" }
            'not-applicable' { Say "  $($i.name)：$($i.breaks)。$($i.hint)" }
            default {
                $what = switch ($i.status) {
                    'missing'        { "找不到 $($i.name)" }
                    'mismatch'       { "$($i.name) 的版本對不上（$($i.source) 要 $($i.required)）" }
                    'below-verified' { "$($i.name) $($i.found) 比實測過的 $($i.required) 舊" }
                    default          { "$($i.name)：$($i.status)" }
                }
                Warn "環境：$what —— $($i.breaks)。$($i.hint)"
                $n++
            }
        }
    }
    return $n
}

# ---- VS Code extension（每台機器一份，不屬於任何一個專案）----
#
# 它不在工具那半、也不在使用者那半：裝在編輯器自己的目錄，所有專案共用。所以——
#   不進 manifest、不進基準線（update 分不出、也不該分使用者有沒有「改過」一個 vsix）；
#   update **不替你重裝**（一個專案的升級不該動到另一個專案也在用的編輯器），版本對不上只說一行；
#   只有 install 帶了 -WithEditor 才裝，而且沒有「以後都自動裝」這個選項。
function Find-ReleaseVsix([string]$root, [string]$version) {
    $dir = Join-Path $root 'editor'
    if (-not (Test-Path $dir)) { return $null }
    $exact = Join-Path $dir "codex-sdlc-$version.vsix"
    if (Test-Path $exact) { return (Resolve-Path $exact).Path }
    $any = Get-ChildItem $dir -Filter 'codex-sdlc-*.vsix' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    return $(if ($any) { $any.FullName } else { $null })
}

function Find-EditorClis {
    return @($Editors | ForEach-Object {
        $c = Get-Command $_.cli -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($c) { [pscustomobject]@{ product = $_.product; cli = $_.cli; path = $c.Source } }
    })
}

# 讀編輯器自己的 extensions.json（沒有才退回掃目錄）—— 不需要 `code` 在 PATH 上，macOS 沒裝 shell 指令的人也查得到。
function Get-InstalledExtensions {
    $found = @()
    foreach ($e in $Editors) {
        $extDir = Join-Path (Join-Path $EditorHome $e.dir) 'extensions'
        if (-not (Test-Path $extDir)) { continue }
        $hit = $null
        $registry = Join-Path $extDir 'extensions.json'
        if (Test-Path $registry) {
            try {
                $entries = @(Get-Content $registry -Raw -Encoding UTF8 | ConvertFrom-Json)
                $entry = $entries | Where-Object { $_.identifier -and [string]$_.identifier.id -ieq $ExtensionId } | Select-Object -Last 1
                if ($entry) {
                    $loc = if ($entry.relativeLocation) { Join-Path $extDir $entry.relativeLocation } else { $null }
                    $hit = [pscustomobject]@{ version = [string]$entry.version; location = $loc }
                }
            } catch { }
        }
        if (-not $hit) {
            $obsolete = @()
            $obsFile = Join-Path $extDir '.obsolete'
            if (Test-Path $obsFile) { try { $obsolete = @((Get-Content $obsFile -Raw | ConvertFrom-Json).PSObject.Properties.Name) } catch { } }
            $dir = Get-ChildItem $extDir -Directory -Filter "$ExtensionId-*" -ErrorAction SilentlyContinue |
                   Where-Object { $_.Name -notin $obsolete } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if ($dir) { $hit = [pscustomobject]@{ version = ($dir.Name.Substring($ExtensionId.Length + 1) -replace '-.*$', ''); location = $dir.FullName } }
        }
        if (-not $hit) { continue }

        # 相容與否看它讀得懂的 -Json 形狀（package.json 的 codexSdlc.jsonSchema），不是看版本號像不像。
        $schema = $null
        if ($hit.location) {
            $pkg = Read-JsonFile (Join-Path $hit.location 'package.json')
            if ($pkg -and $pkg.codexSdlc -and $null -ne $pkg.codexSdlc.jsonSchema) { $schema = [int]$pkg.codexSdlc.jsonSchema }
        }
        $found += [pscustomobject]@{ product = $e.product; version = $hit.version; jsonSchema = $schema; compatible = ($schema -eq $JsonSchema) }
    }
    return $found
}

function Install-Editor([string]$vsix) {
    $result = [ordered]@{ vsix = $vsix; requested = [bool]$WithEditor; installed = $false; product = $null; cli = $null; error = $null }
    if (-not $vsix) {
        if ($WithEditor) {
            Warn '這份 zip 沒有附 VS Code extension（editor/ 底下沒有 .vsix）—— 工作流照常裝好了。extension 在發佈頁是另一個附件（codex-sdlc-<版本>.vsix），下載後 code --install-extension <那個檔>。'
            $result.error = 'no-vsix'
        }
        return $result
    }
    if (-not $WithEditor) {
        # 這台機器已經有一版讀得懂這個 -Json 的 extension（很可能**就是它**在叫這次安裝）—— 再喊一次「沒有裝」是錯的。
        if (@(Get-InstalledExtensions | Where-Object compatible).Count -gt 0) { return $result }
        # 這一行排在「裝好了」後面 —— 不明講「沒有裝」，使用者會以為發佈物附的東西都裝好了，然後在 VS Code 裡找不到任何介面。
        Say "VS Code extension **沒有裝**（這次沒加 -WithEditor）。要狀態列、Problems、一鍵 doctor／apply 的話，在刪掉這個解壓目錄之前跑：code --install-extension `"$vsix`"（Cursor／Windsurf／VSCodium 換成各自的指令）。它是每台機器一份、所有專案共用。"
        return $result
    }

    $clis = @(Find-EditorClis)
    if ($clis.Count -eq 0) {
        # 查不到就說怎麼手動裝 —— 不丟例外：擋下的理由跟他要做的事無關，而且他修不了。
        Warn "VS Code extension 沒有裝上：找不到編輯器的指令（code／code-insiders／cursor／windsurf／codium 都不在 PATH）—— 工作流照常裝好了。手動裝 extension：編輯器的 Extensions 面板 → … → Install from VSIX，選 $vsix"
        $result.error = 'cli-not-found'
        return $result
    }
    $pick = $clis[0]
    $result.cli = $pick.cli; $result.product = $pick.product
    $out = & $pick.path --install-extension $vsix --force 2>&1
    if ($LASTEXITCODE -ne 0) {
        Warn "extension 沒裝成（$($pick.cli) --install-extension 回 $LASTEXITCODE）：$((@($out) -join ' ').Trim()) —— 工作流照常裝好了。可以手動再試：$($pick.cli) --install-extension `"$vsix`" --force"
        $result.error = 'install-failed'
        return $result
    }
    $result.installed = $true
    Say "VS Code extension 裝進了 $($pick.product)。**它是每台機器一份、所有專案共用** —— 刪掉這個專案不會移除它，要移除：$($pick.cli) --uninstall-extension $ExtensionId"
    if ($clis.Count -gt 1) {
        Say "  另外找到 $(@($clis | Select-Object -Skip 1 | ForEach-Object { $_.product }) -join '、')；要裝進去就各自跑 <指令> --install-extension `"$vsix`""
    }
    return $result
}

# ---- 發佈物來源（fetch）----
#
# VS Code extension 要在一個**還沒裝工作流**的資料夾裡安裝時，手上沒有任何 payload：專案是空的。
# 「去哪裡拿一份發佈物」因此需要一個實作 —— 而它只能在這裡：extension 自己不碰網路
# （那條界線由它的 package.test.ts 守著，繞過去就等於繞過 update.check = never 的承諾）。
#
# 順序是**遠端優先、內附墊底**：查得到就用最新的，離線／私有 repo／來源沒設一律**靜默退回內附**。
# 裝不裝得成不該取決於有沒有網路 —— 這套 zip 從第一天就是離線可用的。
#
# 拿回來的東西一定驗過才交出去：版本檔在、而且 manifest 列的每一個檔的 sha256 都對得上。
# 一份壞掉的 payload 裝進專案，症狀會落在**使用者的**流程裡，而且是靜默的。
function Test-Payload([string]$dir) {
    $v = Get-ContractVersion $dir
    if (-not $v) { return [pscustomobject]@{ ok = $false; version = $null; reason = 'no-version-file'; bad = @() } }
    $m = Read-JsonFile (Join-Path $dir $ManifestRel)
    # 沒有 manifest 的 payload（手工解壓、從 repo 直接指過來）照收 —— 但說不出「沒被動過」，只說「有版本」。
    if (-not $m -or -not $m.files) { return [pscustomobject]@{ ok = $true; version = [string]$v.contract; reason = 'no-manifest'; bad = @() } }
    $bad = @()
    foreach ($p in $m.files.PSObject.Properties) {
        $f = Join-Path $dir $p.Name
        if (-not (Test-Path $f)) { $bad += $p.Name; continue }
        if ((Get-Sha256File $f) -ne [string]$p.Value) { $bad += $p.Name }
    }
    return [pscustomobject]@{
        ok      = ($bad.Count -eq 0)
        version = [string]$v.contract
        reason  = $(if ($bad.Count -gt 0) { 'sha-mismatch' } else { 'verified' })
        bad     = @($bad)
    }
}

# 一份 zip → 快取裡一個驗過的目錄。遠端下載回來的、使用者自己從發佈頁抓的，走的是同一條路：
# 解到暫存 → 驗 → 驗過才搬進 <cache>/<版本>。驗不過的東西一個位元組都不會出現在最終位置。
function Expand-PayloadZip([string]$zip, [string]$cache) {
    if (-not (Test-Path $cache)) { New-Item -ItemType Directory -Path $cache -Force | Out-Null }
    $tmpDir = Join-Path $cache ('.tmp-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
    try {
        Expand-Archive -Path $zip -DestinationPath $tmpDir -Force
        $chk = Test-Payload $tmpDir
        if (-not $chk.ok) {
            Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
            return [pscustomobject]@{ ok = $false; path = $null; version = $null; reason = $chk.reason }
        }
        $dest = Join-Path $cache $chk.version
        if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
        Move-Item $tmpDir $dest
        return [pscustomobject]@{ ok = $true; path = (Resolve-Path $dest).Path; version = $chk.version; reason = $chk.reason }
    } catch {
        Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
        return [pscustomobject]@{ ok = $false; path = $null; version = $null; reason = 'expand-failed' }
    }
}

# 發佈物來源 → 哪一家、API 在哪、發佈頁在哪。認不得就回 $null（寫法見 $ReleaseSourcePattern）。
# Gitea 可以裝在子路徑底下（https://corp/gitea/team/flow）：最後兩段是 owner／repo，前面是站台。
# GitLab 的群組可以巢狀（group/sub/flow），所以整段路徑都是專案；裝在子路徑底下的 GitLab 分不出來，不支援。
function Get-ReleaseRepo([string]$src) {
    $src = ([string]$src).Trim()
    if (-not $src -or $src -notmatch $ReleaseSourcePattern) { return $null }
    $provider = $null
    if ($src -match '^(github|gitlab|gitea):(.+)$') { $provider = $Matches[1].ToLowerInvariant(); $src = $Matches[2] }
    try { $u = [Uri]$src } catch { return $null }
    $segs = @(($u.AbsolutePath.Trim('/') -replace '\.git$', '') -split '/' | Where-Object { $_ })
    $isGitHubCom = $u.Host -match '(^|\.)github\.com$'
    if (-not $provider) { $provider = if ($isGitHubCom) { 'github' } else { 'gitlab' } }
    $origin = $u.GetLeftPart([UriPartial]::Authority)
    switch ($provider) {
        'github' {
            $owner = $segs[-2]; $repo = $segs[-1]
            $api = if ($isGitHubCom) { 'https://api.github.com' } else { "$origin/api/v3" }
            return [pscustomobject]@{ provider = 'github'; host = $u.Host; api = "$api/repos/$owner/$repo"; web = "$origin/$owner/$repo" }
        }
        'gitea' {
            $owner = $segs[-2]; $repo = $segs[-1]
            $base = if ($segs.Count -gt 2) { "$origin/" + ($segs[0..($segs.Count - 3)] -join '/') } else { $origin }
            return [pscustomobject]@{ provider = 'gitea'; host = $u.Host; api = "$base/api/v1/repos/$owner/$repo"; web = "$base/$owner/$repo" }
        }
        default {
            $proj = $segs -join '/'
            return [pscustomobject]@{ provider = 'gitlab'; host = $u.Host; api = "$origin/api/v4/projects/$([Uri]::EscapeDataString($proj))"; web = "$origin/$proj" }
        }
    }
}

# 私有的發佈頁（公司自架的 Gitea／GitLab 多半是）要 token。只從環境變數拿，而且**綁主機**：
# CODEX_SDLC_TOKEN_<主機名稱大寫、非英數換成 _>，例如 git.acme.local → CODEX_SDLC_TOKEN_GIT_ACME_LOCAL。
# 不讀 GITLAB_TOKEN 這類通用名字：update.source 寫在專案的 sdlc.config.json 裡（會進版控），一份被改過的來源就能把
# 你的 token 送到別人的主機 —— 而 VS Code extension 每天在背景替你查一次，沒有人在看。token 也不寫進任何設定檔。
function Get-ReleaseToken([string]$hostName) {
    $name = 'CODEX_SDLC_TOKEN_' + ($hostName.ToUpperInvariant() -replace '[^A-Z0-9]', '_')
    return [Environment]::GetEnvironmentVariable($name)
}

function Get-ReleaseHeaders($repo) {
    $h = @{ 'User-Agent' = 'codex-sdlc' }
    $t = Get-ReleaseToken $repo.host
    if ($t) {
        switch ($repo.provider) {
            'github' { $h['Authorization'] = "Bearer $t" }
            'gitea'  { $h['Authorization'] = "token $t" }
            'gitlab' { $h['PRIVATE-TOKEN'] = $t }
        }
    }
    return $h
}

# 對發佈來源發一個 GET；給了 $outFile 就存成檔，否則回 UTF-8 文字。轉址自己跟（最多 5 次），每一跳重新判斷要不要帶 token：
# 只有跟來源同一個站台（scheme、主機、port 都一樣；GitHub 另加它的 API 站台）才帶。交給 .NET 自動轉址的話它只拿掉
# Authorization，GitLab 的 PRIVATE-TOKEN 會原封不動送到轉過去的主機 —— 而附件常常轉到物件儲存（S3／MinIO）。
# 不用 Invoke-WebRequest -MaximumRedirection 0：pwsh 7.4 起它在 3xx 時丟錯，各版行為不一樣。
function Invoke-ReleaseGet($repo, [string]$uri, [string]$outFile = '', [string]$accept = '') {
    $origins = @(@($repo.api, $repo.web) | ForEach-Object { ([Uri]$_).GetLeftPart([UriPartial]::Authority) })
    $handler = [Net.Http.HttpClientHandler]::new()
    $handler.AllowAutoRedirect = $false
    $client = [Net.Http.HttpClient]::new($handler)
    $client.Timeout = New-TimeSpan -Seconds $(if ($outFile) { 120 } else { 8 })
    try {
        for ($hop = 0; $hop -le 5; $hop++) {
            $u = [Uri]$uri
            $h = if ($origins -contains $u.GetLeftPart([UriPartial]::Authority)) { Get-ReleaseHeaders $repo } else { @{ 'User-Agent' = 'codex-sdlc' } }
            if ($accept) { $h['Accept'] = $accept }
            $req = [Net.Http.HttpRequestMessage]::new([Net.Http.HttpMethod]::Get, $u)
            foreach ($k in $h.Keys) { $null = $req.Headers.TryAddWithoutValidation($k, [string]$h[$k]) }
            try { $resp = $client.SendAsync($req).GetAwaiter().GetResult() }
            catch {
                $e = $_.Exception
                if ($e -is [Management.Automation.MethodInvocationException] -and $e.InnerException) { $e = $e.InnerException }
                throw $e.Message
            }
            $code = [int]$resp.StatusCode
            if ($code -ge 300 -and $code -lt 400 -and $resp.Headers.Location) {
                $uri = [Uri]::new($u, $resp.Headers.Location).AbsoluteUri
                continue
            }
            if (-not $resp.IsSuccessStatusCode) { throw "HTTP $code" }
            $bytes = $resp.Content.ReadAsByteArrayAsync().GetAwaiter().GetResult()
            if ($outFile) { [IO.File]::WriteAllBytes($outFile, $bytes); return }
            return [Text.Encoding]::UTF8.GetString($bytes).TrimStart([char]0xFEFF)
        }
        throw '轉址超過 5 次'
    } finally { $client.Dispose() }
}

# 各家的「最新正式版」→ 同一個形狀：tag、說明、發佈頁網址、附件（名稱＋下載網址）。連不到就丟例外，由呼叫端決定怎麼說。
function Get-LatestRelease($repo) {
    if ($repo.provider -eq 'gitlab') {
        # 不用 /releases/permalink/latest（GitLab 15.4 起才有）：列最近幾筆（預設照發佈時間新到舊），跳過還沒到發佈日的。
        # 附件用 url（連結真正指的地方，例如套件庫的 API 網址，token 認得）而不是 direct_asset_url：
        # 後者是網頁路由的永久連結，私有專案拿 token 打它只會被轉到登入頁。
        $rel = @(Invoke-ReleaseGet $repo "$($repo.api)/releases?per_page=5" | ConvertFrom-Json) |
               Where-Object { $_ -and -not $_.upcoming_release } | Select-Object -First 1
        if (-not $rel) { return $null }
        return [pscustomobject]@{
            tag    = [string]$rel.tag_name
            body   = [string]$rel.description
            url    = $(if ($rel._links -and $rel._links.self) { [string]$rel._links.self } else { "$($repo.web)/-/releases/$($rel.tag_name)" })
            assets = @($rel.assets.links | Where-Object { $_ } | ForEach-Object {
                         [pscustomobject]@{ name = [string]$_.name; url = $(if ($_.url) { [string]$_.url } else { [string]$_.direct_asset_url }); api = $null } })
        }
    }
    # GitHub 與 Gitea 的 release 是同一個形狀。舊版 Gitea 沒有 /releases/latest：退回列表，取第一筆非草稿、非預覽版。
    $rel = $null
    try { $rel = Invoke-ReleaseGet $repo "$($repo.api)/releases/latest" | ConvertFrom-Json }
    catch {
        if ($repo.provider -ne 'gitea') { throw }
        $rel = @(Invoke-ReleaseGet $repo "$($repo.api)/releases?limit=10" | ConvertFrom-Json) |
               Where-Object { $_ -and -not $_.draft -and -not $_.prerelease } | Select-Object -First 1
    }
    if (-not $rel) { return $null }
    return [pscustomobject]@{
        tag    = [string]$rel.tag_name
        body   = [string]$rel.body
        url    = [string]$rel.html_url
        assets = @($rel.assets | Where-Object { $_ } | ForEach-Object {
                     [pscustomobject]@{ name = [string]$_.name; url = [string]$_.browser_download_url; api = [string]$_.url } })
    }
}

# 下載附件（token 帶不帶由 Invoke-ReleaseGet 逐跳判斷）。GitHub 私有 repo 的附件要走 API 的那個網址，
# 它再轉到一個不用 token 的下載網址。
function Save-ReleaseAsset($repo, $asset, [string]$dest) {
    if ($repo.provider -eq 'github' -and $asset.api -and (Get-ReleaseToken $repo.host)) {
        Invoke-ReleaseGet $repo $asset.api $dest 'application/octet-stream'
    } else {
        Invoke-ReleaseGet $repo $asset.url $dest
    }
}

function Resolve-ReleaseSource {
    if ($SourceUrl) { return $SourceUrl }
    $cfg = Read-JsonFile (Join-Path $Target $ConfigFile)
    if ($cfg -and $cfg.update -and $cfg.update.source) { return [string]$cfg.update.source }
    $v = Get-ContractVersion $Source
    if ($v -and $v.raw.PSObject.Properties['source'] -and $v.raw.source) { return [string]$v.raw.source }
    return ''
}

function Invoke-Fetch {
    $cache = if ($CacheDir) { $CacheDir } else { Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'codex-sdlc/payloads' }
    # -Bundled 明講成空字串 = 這台機器沒有內附的那一份（extension 在沒有 payload 的開發模式下就是這樣叫）。
    # 完全不給 = 用 -Source（在終端機直接跑 fetch 時，本機那一份就是腳本自己所在的發佈物）。
    $bundledDir = if ($BundledGiven) { $Bundled } else { $Source }

    $remote = [ordered]@{ checked = $false; reachable = $false; latest = $null; url = $null; reason = $null; provider = $null }
    $bundledInfo = [ordered]@{ version = $null; path = $null }
    $script:Data.chosen   = 'none'
    $script:Data.version  = $null
    $script:Data.path     = $null
    $script:Data.remote   = $remote
    $script:Data.bundled  = $bundledInfo
    $script:Data.cacheDir = $cache

    if ($bundledDir -and (Test-Path $bundledDir)) {
        if (Test-Path $bundledDir -PathType Leaf) {
            # 指過來的是一個 zip（使用者自己從發佈頁下載的那一份）：跟遠端下載回來的走同一條路。
            $x = Expand-PayloadZip $bundledDir $cache
            if ($x.ok) { $bundledInfo.version = $x.version; $bundledInfo.path = $x.path }
            else { Warn "指定的發佈物 zip 用不了（$($x.reason)）：$bundledDir" }
        } else {
            $b = Test-Payload $bundledDir
            if ($b.ok) {
                $bundledInfo.version = $b.version
                $bundledInfo.path    = (Resolve-Path $bundledDir).Path
            } elseif ($b.reason -eq 'sha-mismatch') {
                Warn "本機的發佈物有 $($b.bad.Count) 個檔跟 manifest 對不上（$(@($b.bad | Select-Object -First 3) -join '、')）—— 不拿它安裝。"
            }
        }
    }

    $src = if ($NoRemote) { '' } else { Resolve-ReleaseSource }
    $repo = if ($src) { Get-ReleaseRepo $src } else { $null }
    if ($NoRemote) {
        $remote.reason = 'skipped'
        Say '只用指定的那一份發佈物（-NoRemote）。'
    } elseif (-not $src) {
        $remote.reason = 'no-source'
        Say '沒有設發佈物來源（update.source 或版本檔的 source）—— 只用本機現有的那一份。'
    } elseif (-not $repo) {
        $remote.reason = 'unsupported-source'
        Warn "發佈物來源認不得（$src）—— $ReleaseSourceHint。這次只用本機現有的那一份。"
    } else {
        $remote.checked  = $true
        $remote.provider = $repo.provider
        $rel = $null
        try { $rel = Get-LatestRelease $repo }
        catch { $remote.reason = 'unreachable'; Say '連不到發佈頁（離線、來源不可達，或私有 repo 沒有設 token）—— 用本機現有的那一份。' }

        if ($rel) {
            $latest = ([string]$rel.tag) -replace '^v', ''
            $remote.latest = $latest
            $asset = @($rel.assets | Where-Object { $_.name -eq "codex-sdlc-$latest.zip" })[0]
            if (-not $asset) { $asset = @($rel.assets | Where-Object { $_.name -like 'codex-sdlc-*.zip' })[0] }
            # 本機那一份（extension 內附的）比發佈頁的還新：新版 extension 先裝了、發佈頁還沒掛上去時就是這樣。
            # 照「遠端優先」去下載的話，點「升級到 4.16.2」拿回來的是 4.16.1 —— 不下載，交給下面的本機那一份。
            if ($bundledInfo.version -and (Compare-Semver $bundledInfo.version $latest) -gt 0) {
                $remote.reachable = $true
                Say "發佈頁最新的是 $latest，本機那一份 $($bundledInfo.version) 比較新 —— 不下載，用本機的。"
            } elseif (-not $asset) {
                $remote.reason = 'no-asset'
                Warn "發佈頁的 $latest 沒有附 codex-sdlc-*.zip —— 用本機現有的那一份。"
            } else {
                $remote.reachable = $true
                $remote.url = [string]$asset.url
                $dest = Join-Path $cache $latest
                # 同一版已經在快取裡而且驗得過 → 一個位元組都不用再下載（第二台專案、離線的第二次都走這條）。
                $hit = if (Test-Path $dest) { Test-Payload $dest } else { $null }
                if ($hit -and $hit.ok) {
                    $script:Data.chosen  = 'cached'
                    $script:Data.version = $hit.version
                    $script:Data.path    = (Resolve-Path $dest).Path
                    Say "發佈物 $latest 已在快取：$dest"
                } else {
                    $tmpZip = Join-Path ([IO.Path]::GetTempPath()) ("sdlc-payload-" + [guid]::NewGuid().ToString('N').Substring(0, 8) + '.zip')
                    try {
                        Say "下載發佈物 $latest…"
                        Save-ReleaseAsset $repo $asset $tmpZip
                        $x = Expand-PayloadZip $tmpZip $cache
                        if (-not $x.ok) {
                            $remote.reason = $x.reason
                            Warn "下載回來的發佈物驗不過（$($x.reason)）—— 不拿它安裝，改用本機現有的那一份。"
                        } else {
                            $script:Data.chosen  = 'remote'
                            $script:Data.version = $x.version
                            $script:Data.path    = $x.path
                            Say "發佈物 $($x.version) 已下載到 $($x.path)"
                        }
                    } catch {
                        $remote.reason = 'download-failed'
                        Warn "下載發佈物失敗（$($_.Exception.Message)）—— 用本機現有的那一份。"
                    } finally {
                        Remove-Item $tmpZip -Force -ErrorAction SilentlyContinue
                    }
                }
                # zip 預設不帶 vsix（pack 的 -VsixInZip 才帶）—— 它在發佈頁是另一個附件。補進快取的 editor/，
                # update -Preview 的 Find-ReleaseVsix 才找得到，extension 也才會在升級後提示「安裝新版 extension」。
                # 拿不到只少了那個提示，工作流照常升級，所以失敗不擋。
                $vsixAsset = @($rel.assets | Where-Object { $_.name -eq "codex-sdlc-$latest.vsix" })[0]
                if ($script:Data.chosen -in 'cached', 'remote' -and $vsixAsset -and -not (Find-ReleaseVsix $script:Data.path $latest)) {
                    $vsixDir = Join-Path $script:Data.path 'editor'
                    $vsixDest = Join-Path $vsixDir "codex-sdlc-$latest.vsix"
                    try {
                        New-Item -ItemType Directory -Path $vsixDir -Force | Out-Null
                        Save-ReleaseAsset $repo $vsixAsset "$vsixDest.part"
                        Move-Item "$vsixDest.part" $vsixDest -Force
                    } catch {
                        Remove-Item "$vsixDest.part" -Force -ErrorAction SilentlyContinue
                        Say "（VS Code extension 的 vsix 沒下載到：$($_.Exception.Message) —— 工作流照常，extension 之後自己從發佈頁裝。）"
                    }
                }
            }
        }
    }

    if ($script:Data.chosen -eq 'none' -and $bundledInfo.path) {
        $script:Data.chosen  = 'bundled'
        $script:Data.version = $bundledInfo.version
        $script:Data.path    = $bundledInfo.path
        Say "用本機的發佈物 $($bundledInfo.version)：$($bundledInfo.path)"
    }
    if ($script:Data.chosen -eq 'none') {
        Warn '找不到任何可用的發佈物 —— 遠端拿不到，本機也沒有內附的那一份。'
        return 2
    }
    return 0
}

# ---- 子命令 ----

function Invoke-Install {
    $srcVer = Get-ContractVersion $Source
    if (-not $srcVer) {
        Warn "來源沒有 $VersionRel —— 這不是一份完整的發佈物。"
        $script:Data.error = 'not-a-release'
        return 2
    }

    $samePlace = (Resolve-Path $Source).Path -eq (Resolve-Path $Target).Path
    if ($samePlace -and -not $Adopt) {
        Warn "來源與目標是同一個目錄。把發佈物解壓到別處再指定 -Target，或用 -Adopt 接管這個既有安裝。"
        $script:Data.error = 'same-path'
        return 2
    }

    $cfgPath = Join-Path $Target $ConfigFile
    $writes = @(); $needsMerge = @()
    $script:Data.mode    = if ($Adopt) { 'adopt' } else { 'install' }
    $script:Data.target  = (Resolve-Path $Target).Path
    $script:Data.version = $srcVer.contract
    $script:Data.guidelinesSkeleton = $false
    $script:Data.guidelinesReadme   = $null

    if ($Adopt) {
        if (-not (Test-Path (Join-Path $Target '.codex'))) { Warn "-Adopt 需要目標已經有 .codex/。"; $script:Data.error = 'nothing-to-adopt'; return 2 }
        $tgtVer = Get-ContractVersion $Target
        $script:Data.version = if ($tgtVer) { $tgtVer.contract } else { $null }
        Say "接管既有安裝：$((Resolve-Path $Target).Path)（版本 $($tgtVer.contract)）"
        Say '把**現況**記成基準線 —— 從現在起 update 才分得出哪些檔是你改過的。'
    } else {
        Say "安裝 $($srcVer.contract) → $((Resolve-Path $Target).Path)"
        foreach ($rel in (Get-ToolFileList $Source)) {
            $s = Join-Path $Source $rel
            $t = Join-Path $Target $rel
            # AGENTS.md 已存在是**預期狀態**（README 就叫使用者把內容合進去），不得覆蓋。
            if ($rel -eq 'AGENTS.md' -and (Test-Path $t) -and (Get-Sha256File $t) -ne (Get-Sha256File $s)) {
                Copy-Item $s "$t.new" -Force
                $needsMerge += $rel
                continue
            }
            $d = Split-Path $t -Parent
            if ($d -and -not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
            Copy-Item $s $t -Force
            $writes += $rel
        }

        # guidelines/ 是使用者的：不存在才放骨架，已存在就不碰（含 submodule 掛載點）——
        # 唯一的例外是一字未改的舊版原廠 README（Update-GuidelinesReadme）。
        $gsrc = Join-Path $Source 'guidelines'
        $gdst = Join-Path $Target 'guidelines'
        if ((Test-Path $gsrc) -and -not (Test-Path $gdst)) {
            Copy-Item $gsrc $gdst -Recurse -Force
            $script:Data.guidelinesSkeleton = $true
            Say 'guidelines/ 放了一份骨架 —— 這份是**你的**，換成你們自己的規範；不需要就整個刪掉，流程照常跑。升級不會覆蓋它。'
        } elseif ((Update-GuidelinesReadme $Target $Source $false) -eq 'replaced') {
            $script:Data.guidelinesReadme = 'replaced'
            Say "$GuideReadmeRel 是舊版的原廠說明（你沒改過），換成了新版 —— 說明本體搬到 .codex/bdd-workflow/guidelines-guide.md。"
        }
    }
    $script:Data.written    = $writes.Count
    $script:Data.needsMerge = @($needsMerge)

    # 設定檔
    if (Test-Path $cfgPath) {
        $script:Data.config = [ordered]@{ created = $false; preset = $null }
        Say "$ConfigFile 已存在，保留不動。"
    } else {
        Write-JsonFile $cfgPath (Get-DefaultConfig $Source $srcVer.contract $Preset)
        $script:Data.config = [ordered]@{ created = $true; preset = $(if ($Preset) { $Preset } else { $null }) }
        Say "建立 $ConfigFile$(if ($Preset) { "（preset: $Preset）" } else { '（全部 inherit）' })"
    }

    # 基準線：只記我們真的寫出去的檔。沒寫的（要合併的 AGENTS.md）不記 ——
    # 它沒有「原廠狀態」，記進去會讓下一次 update 把使用者的合併判成「改過」。
    $baseline = [ordered]@{}
    $recordSet = if ($Adopt) { Get-ToolFileList $Target } else { $writes }
    foreach ($rel in $recordSet) {
        $p = Join-Path $Target $rel
        if (Test-Path $p) { $baseline[$rel] = Get-ComparableSha $Target $rel }
    }
    Write-JsonFile (Join-Path $Target $BaselineRel) ([ordered]@{
        'workflow-version' = if ($Adopt) { (Get-ContractVersion $Target).contract } else { $srcVer.contract }
        'recorded-at'      = (Get-Date).ToString('o')
        'adopted'          = [bool]$Adopt
        'files'            = $baseline
    })

    $code = Complete-Install $needsMerge ($HooksRel -in $writes)
    # extension 放在最後、而且在基準線寫完之後 —— 它從頭到尾都不是這個專案的檔。
    $script:Data.editor = Install-Editor $(if ($Adopt) { $null } else { Find-ReleaseVsix $Source $srcVer.contract })
    return $code
}

function Complete-Install([string[]]$needsMerge, [bool]$hooksWritten) {
    $cfg = Read-JsonFile (Join-Path $Target $ConfigFile)
    $res = Invoke-TuningApply $Target $cfg
    if ($res.changed.Count -gt 0) { Say "apply：更新了 $($res.changed -join '、') 的 SDLC-TUNING 區塊" }
    foreach ($w in $res.warnings) { Warn $w }
    $script:Data.tuning = [ordered]@{ changed = @($res.changed); warnings = @($res.warnings) }

    foreach ($m in $needsMerge) {
        Warn "$m 你已經有一份，沒有覆蓋 —— 新版寫成 $m.new，請把流程那幾節合進你自己那份，然後刪掉 .new。少了它整套流程不會啟動。"
    }

    $findings = @(Test-Guidelines $Target $Source)
    foreach ($f in $findings) { if ($f.level -eq 'warn') { Warn $f.text } else { Say $f.text } }
    $script:Data.guidelines = @(Get-FindingData $findings)

    $lint = Invoke-Lint $Target
    $script:Data.lint = $lint

    # hooks.json 寫出去了 = Codex 那邊一定要（重新）信任。沒信任之前強制層一條都不會跑，而 Codex 不會主動說。
    # -TrustHooks（4.28.0）：同意已經給了，裝完直接替他信任 —— hooks.json 這次沒換也照跑一次：舊專案可能從來沒信任過
    # （只用 VS Code chat 的人看不到審核畫面），而已經信任的話它只問一次 Codex 就回 already-trusted。
    # 信任沒成不讓 install／update 失敗：檔都裝好了，失敗的理由與修法由它自己講，結果在 data.trust。
    $script:Data.hooksWritten = $hooksWritten
    $script:Data.trust = $null
    if ($TrustHooks -and (Test-Path -LiteralPath (Join-Path $Target $HooksRel) -PathType Leaf)) {
        $script:Data.trust = Invoke-HookTrustWrite $Target $true
    } elseif ($hooksWritten) {
        Say "hooks 寫好了，但 **Codex 要你信任之後才會跑**。沒信任之前 handoff-lint／dlp-gate／guideline-gate／build-check 一條都不會跑，而且沒有任何提示。$TrustHint 之後隨時可以用 sdlc.ps1 doctor -CheckHookTrust 確認（doctor 預設不查這一項）。"
    }

    $cfg = Read-JsonFile (Join-Path $Target $ConfigFile)
    $orch = Get-AgentConfig $cfg 'orchestrator'
    $script:Data.orchestratorHint = $null
    if ($orch -and (($orch.model -and $orch.model -ne 'inherit') -or ($orch.effort -and $orch.effort -ne 'inherit'))) {
        # orchestrator 沒有 agent 定義檔（它就是 AGENTS.md），設定檔強制不了它。
        $hint = 'codex'
        if ($orch.model  -and $orch.model  -ne 'inherit') { $hint += " --model $($orch.model)" }
        if ($orch.effort -and $orch.effort -ne 'inherit') { $hint += " -c model_reasoning_effort=$($orch.effort)" }
        $script:Data.orchestratorHint = $hint
        Say "orchestrator 的設定強制不了（它沒有 agent 定義檔，就是 AGENTS.md 本身）。要用你記的那組值，啟動時自己下：$hint"
    }

    Say ''
    Say '裝好了。在專案裡開 Codex，直接說你要什麼即可。'
    return $(if ($lint.passed) { 0 } else { 2 })
}

function Invoke-Update {
    $srcVer = Get-ContractVersion $Source
    $tgtVer = Get-ContractVersion $Target
    if (-not $srcVer) { Warn "來源沒有 $VersionRel —— 這不是一份完整的發佈物。"; $script:Data.error = 'not-a-release'; return 2 }
    if ((Resolve-Path $Source).Path -eq (Resolve-Path $Target).Path) {
        Warn '來源與目標是同一個目錄。把新版發佈物解壓到別處，再從那裡跑 update -Target <你的專案>。'
        $script:Data.error = 'same-path'
        return 2
    }
    $cfgPath = Join-Path $Target $ConfigFile
    if (-not (Test-Path $cfgPath)) {
        Warn "$ConfigFile 不存在 —— 這個專案還沒被 sdlc.ps1 接管過。先跑：pwsh .codex/scripts/sdlc.ps1 install -Adopt"
        $script:Data.error = 'not-managed'
        return 2
    }

    $baseline = Read-JsonFile (Join-Path $Target $BaselineRel)
    $degraded = -not ($baseline -and $baseline.files)
    if ($degraded) {
        Warn '找不到基準線（bdd-docs/.sdlc/installed-manifest.json）—— 我分不出哪些工具檔是你改過的。'
        Warn '所以下面每一個會被覆蓋的檔都會先備份，不會假設「沒動過」。'
    }

    $srcFiles = Get-ToolFileList $Source
    $unchanged = @(); $modified = @(); $added = @(); $removed = @()

    foreach ($rel in $srcFiles) {
        $t = Join-Path $Target $rel
        if (-not (Test-Path $t)) { $added += $rel; continue }
        $cur = Get-ComparableSha $Target $rel
        if ($cur -eq (Get-ComparableSha $Source $rel)) { continue }   # 內容已相同，無事可做
        $base = if (-not $degraded) { $baseline.files.PSObject.Properties | Where-Object Name -eq $rel | ForEach-Object { $_.Value } | Select-Object -First 1 } else { $null }
        if ((-not $degraded) -and $base -and $base -eq $cur) { $unchanged += $rel } else { $modified += $rel }
    }
    if (-not $degraded) {
        foreach ($p in $baseline.files.PSObject.Properties) {
            if ($p.Name -notin $srcFiles -and (Test-Path (Join-Path $Target $p.Name))) { $removed += $p.Name }
        }
    }

    $breaking = [bool]($tgtVer -and $srcVer.minCompat -and ((Compare-Semver $tgtVer.contract $srcVer.minCompat) -lt 0))
    # 拿比專案現有還舊的發佈物跑 update = 降級。CLI 上有人是故意的（退回上一版），所以照做，但要講；
    # extension 的「升級」看到這個旗標就停 —— 遠端拿不到時 fetch 會退回 vsix 內附的那一份，它可能比專案舊。
    $downgrade = [bool]($tgtVer -and ((Compare-Semver $srcVer.contract $tgtVer.contract) -lt 0))
    $script:Data.from      = if ($tgtVer) { $tgtVer.contract } else { $null }
    $script:Data.to        = $srcVer.contract
    $script:Data.breaking  = $breaking
    $script:Data.downgrade = $downgrade
    $script:Data.degraded  = [bool]$degraded
    $script:Data.unchanged = @($unchanged)
    $script:Data.modified  = @($modified)
    $script:Data.added     = @($added)
    $script:Data.removed   = @($removed)
    # guidelines/README.md 不在工具清單裡（guidelines/ 是使用者的），另外判斷：一字未改的舊版原廠才換。
    $readmeSwap = (Update-GuidelinesReadme $Target $Source $true) -eq 'will-replace'
    $script:Data.guidelinesReadme = if ($readmeSwap) { 'will-replace' } else { $null }

    Say "升級：$(if ($tgtVer) { $tgtVer.contract } else { '未知' }) → $($srcVer.contract)"
    Say ''
    if ($downgrade) {
        Warn "這份發佈物（$($srcVer.contract)）比專案現在的 $($tgtVer.contract) 舊 —— 照做的話是降級。"
    }
    if ($breaking) {
        Say "** 破壞性升級 ** 你的 $($tgtVer.contract) 低於新版要求的最低相容版本 $($srcVer.minCompat)。"
        Say '   升級前先看 CHANGELOG.md 的「從 v… 升上來」那幾節（或跑 whatsnew），手上跑到一半的需求先跑完。'
        Say ''
    }
    Say "會覆蓋（你沒動過）：$($unchanged.Count) 個"
    Say "新增：$($added.Count) 個"
    if ($readmeSwap) { Say "另外：$GuideReadmeRel 是舊版的原廠說明（你沒改過），會換成新版的指標頁。" }
    if ($modified.Count -gt 0) {
        Say ''
        Say "** 你改過的檔（$($modified.Count) 個）** —— 會先備份再覆蓋："
        foreach ($m in $modified) { Say "   $m" }
    }
    if ($removed.Count -gt 0) {
        Say ''
        Say "** 這一版刪掉的檔（$($removed.Count) 個）** —— 會備份後刪除（留著的症狀通常是靜默的）："
        foreach ($m in $removed) { Say "   $m" }
    }
    # 這一版的說明：先找檔名對得上新版號的那幾條（4.7.0 → v47*），沒有才退回第一條。
    # 拿錯條目的代價是使用者照著**別的版本**的說明做升級決定。
    $script:Data.notes = @()
    if ($srcVer.raw) {
        $tag = 'v' + (($srcVer.contract -split '\.')[0..1] -join '')
        $notes = @($srcVer.raw.PSObject.Properties | Where-Object { $_.Name -like "$tag*" })
        if (-not $notes) { $notes = @($srcVer.raw.PSObject.Properties | Where-Object { $_.Name -match '^v\d' } | Select-Object -First 1) }
        foreach ($n in $notes) {
            $txt = [string]$n.Value
            $script:Data.notes += [ordered]@{ key = $n.Name; text = $txt }
            Say ''
            Say "這一版[$($n.Name)]：$($txt.Substring(0, [Math]::Min(500, $txt.Length)))$(if ($txt.Length -gt 500) { '…（全文：sdlc.ps1 whatsnew）' })"
        }
    }
    Say ''

    if ($unchanged.Count -eq 0 -and $modified.Count -eq 0 -and $added.Count -eq 0 -and $removed.Count -eq 0 -and -not $readmeSwap) {
        $script:Data.result = 'up-to-date'
        Say '已經是最新，沒有檔要動。'
        return 0
    }
    # -Preview：上面算好的計畫就是給人確認用的，到這裡為止一個檔都還沒寫。extension 的「升級」先拿它
    # 填確認對話框，同意了才帶 -Yes 再跑一次 —— 讓「會蓋掉你改過的哪幾個檔」出現在按下去**之前**。
    if ($Preview) {
        $script:Data.result = 'preview'
        $script:Data.vsix   = Find-ReleaseVsix $Source $srcVer.contract
        $script:Data.hooksChanged = [bool]($HooksRel -in @($unchanged + $modified + $added))
        Say '（-Preview：只列出計畫，一個檔都沒動。）'
        return 0
    }
    if (-not (Confirm-Step '要升級嗎？')) { $script:Data.result = 'cancelled'; Say '已取消，一個檔都沒動。'; return 2 }

    $backupDir = Join-Path $Target "$StateDir/backup-$(if ($tgtVer) { $tgtVer.contract } else { 'unknown' })"
    foreach ($rel in @($modified + $removed)) {
        $src = Join-Path $Target $rel
        if (-not (Test-Path $src)) { continue }
        $dst = Join-Path $backupDir $rel
        $d = Split-Path $dst -Parent
        if ($d -and -not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
        Copy-Item $src $dst -Force
    }
    $script:Data.backup = $null
    if ($modified.Count + $removed.Count -gt 0) {
        $script:Data.backup = ConvertTo-Rel $Target (Resolve-Path $backupDir).Path
        Say "備份：$($script:Data.backup)"
    }

    foreach ($rel in @($unchanged + $modified + $added)) {
        $t = Join-Path $Target $rel
        $d = Split-Path $t -Parent
        if ($d -and -not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
        Copy-Item (Join-Path $Source $rel) $t -Force
    }
    foreach ($rel in $removed) { Remove-Item (Join-Path $Target $rel) -Force -ErrorAction SilentlyContinue }
    if ($readmeSwap) { $script:Data.guidelinesReadme = Update-GuidelinesReadme $Target $Source $false }

    $cfg = Read-JsonFile $cfgPath
    $newAgents = Merge-Config $cfg $Source $srcVer.contract
    # 舊版的設定檔沒有 review 這一節。補上預設值 = 跟以前寫死的 3 輪一模一樣，只是從此看得到、改得到。
    $script:Data.reviewAdded = $false
    if (-not $cfg.PSObject.Properties['review']) {
        $cfg | Add-Member -NotePropertyName 'review' -NotePropertyValue ([pscustomobject]@{ maxRounds = $DefaultReviewRounds })
        $script:Data.reviewAdded = $true
    }
    # 4.9 起設定檔帶 $schema：編輯器有補全與波浪線，沒裝 extension 也有。
    $script:Data.schemaAdded = $false
    if (-not $cfg.PSObject.Properties['$schema']) {
        $cfg = ConvertTo-ConfigWithSchemaRef $cfg
        $script:Data.schemaAdded = $true
    }
    # 4.14 起來源要分辨得出是哪一家（$ReleaseSourcePattern）。4.13 以前的 GitHub 寫法比較寬（開頭沒錨定：github.com/o/r、
    # ssh://git@github.com/o/r.git 都收過）—— 換成 https 的寫法；換不了的要講，否則更新通知從這一版起靜默消失。
    $script:Data.sourceMigrated = $null
    $oldSrc = if ($cfg.PSObject.Properties['update'] -and $cfg.update.PSObject.Properties['source']) { ([string]$cfg.update.source).Trim() } else { '' }
    if ($oldSrc -and -not (Get-ReleaseRepo $oldSrc) -and $oldSrc -match 'github\.com[/:]([^/\s]+)/([^/\s]+?)(\.git)?/?$') {
        $cfg.update.source = "https://github.com/$($Matches[1])/$($Matches[2])"
        $script:Data.sourceMigrated = [ordered]@{ from = $oldSrc; to = $cfg.update.source }
    }
    # 空的才補：發佈物還沒填 source 時裝的專案，update.source 是空字串 —— 之後發佈物填好了，不補的話那些專案
    # 永遠查不到新版（症狀是零）。使用者自己填過的（包括認不得的）一個字不動。
    $script:Data.sourceFilled = $null
    $relSrc = if ($srcVer.raw -and $srcVer.raw.PSObject.Properties['source']) { ([string]$srcVer.raw.source).Trim() } else { '' }
    if (-not $oldSrc -and $relSrc -and (Get-ReleaseRepo $relSrc)) {
        if (-not $cfg.PSObject.Properties['update']) {
            $cfg | Add-Member -NotePropertyName 'update' -NotePropertyValue ([pscustomobject]@{ source = $relSrc; check = 'daily' })
        } elseif (-not $cfg.update.PSObject.Properties['source']) {
            $cfg.update | Add-Member -NotePropertyName 'source' -NotePropertyValue $relSrc
        } else {
            $cfg.update.source = $relSrc
        }
        $script:Data.sourceFilled = $relSrc
    }
    # 下面整份改寫會把註解吃掉 —— 先備份原檔，再說一聲。
    $script:Data.configCommentsBackup = $null
    if (Test-JsonHasComments ([IO.File]::ReadAllText($cfgPath))) {
        $dst = Join-Path $backupDir $ConfigFile
        New-Item -ItemType Directory -Path (Split-Path $dst -Parent) -Force | Out-Null
        Copy-Item $cfgPath $dst -Force
        $script:Data.configCommentsBackup = ConvertTo-Rel $Target (Resolve-Path $dst).Path
        Warn "$ConfigFile 裡有註解 —— 這個檔不支援註解，改寫後它們不見了。原檔備份在 $($script:Data.configCommentsBackup)；要留的說明請搬進 _note。"
    }
    Write-JsonFile $cfgPath $cfg
    $script:Data.newAgents = @($newAgents)
    if ($newAgents.Count -gt 0) { Say "$ConfigFile：新增 agent $($newAgents -join '、')（值填 inherit），既有設定一個字沒動。" }
    if ($script:Data.reviewAdded) { Say "$ConfigFile：新增 review.maxRounds = $DefaultReviewRounds（⑤ 的修正輪上限，跟以前寫死的一樣；可改成 1–5）。" }
    if ($script:Data.schemaAdded) { Say "$ConfigFile：加上 `$schema —— 在編輯器裡改這個檔會有補全與錯字提示。" }
    if ($script:Data.sourceMigrated) { Say "$ConfigFile：update.source 換成 $($cfg.update.source)（原本的 $oldSrc 這一版起認不得）。" }
    elseif ($script:Data.sourceFilled) { Say "$ConfigFile：update.source 原本是空的，補上 $($script:Data.sourceFilled) —— 從此查得到新版。" }
    elseif ($oldSrc -and -not (Get-ReleaseRepo $oldSrc)) { Warn "update.source 認不得（$oldSrc）—— 更新通知查不到。$ReleaseSourceHint：pwsh .codex/scripts/sdlc.ps1 set update.source=<網址>" }

    $bl = [ordered]@{}
    foreach ($rel in (Get-ToolFileList $Target)) {
        $p = Join-Path $Target $rel
        if (Test-Path $p) { $bl[$rel] = Get-ComparableSha $Target $rel }
    }
    Write-JsonFile (Join-Path $Target $BaselineRel) ([ordered]@{
        'workflow-version' = $srcVer.contract
        'recorded-at'      = (Get-Date).ToString('o')
        'adopted'          = $false
        'files'            = $bl
    })
    $script:Data.result = 'applied'

    # 新版的 toml 是原廠檔，裡面沒有 TUNING 區塊 —— 不重跑 apply，使用者的 effort 設定就沒生效。
    # hooks.json 只要內容換了（不管你有沒有改過它），Codex 那邊的信任就要重來。
    $code = Complete-Install @() ($HooksRel -in @($unchanged + $modified + $added))

    # extension 不替你重裝（它是整台機器共用的），只在版本對不上時說一行。
    $installedExt = @(Get-InstalledExtensions)
    $vsix = Find-ReleaseVsix $Source $srcVer.contract
    $script:Data.editor = [ordered]@{ installed = @($installedExt | ForEach-Object { [ordered]@{ product = $_.product; version = $_.version; compatible = $_.compatible } }); vsix = $vsix; mismatch = $false }
    foreach ($x in $installedExt) {
        if ($x.version -ne $srcVer.contract) {
            $script:Data.editor.mismatch = $true
            $how = if ($vsix) { "要換：code --install-extension `"$vsix`" --force" } else { '要換就裝這一版發佈物附的 vsix' }
            Say "$($x.product) 裡的 VS Code extension 還是 $($x.version)（這個專案現在是 $($srcVer.contract)）—— 沒有替你重裝，因為它是整台機器共用的。$how"
        }
    }
    return $code
}

function Invoke-Apply {
    $cfgPath = Join-Path $Target $ConfigFile
    $cfg = Read-JsonFile $cfgPath
    if (-not $cfg) {
        if (Test-Path $cfgPath) { Warn "$ConfigFile 解析不了 —— 先把 JSON 修好。"; $script:Data.error = 'config-unreadable' }
        else {
            # 沒有設定檔是合法狀態（全部 inherit）—— 沒有東西要套用，但別叫他去跑 install，這個專案已經裝好了。
            Warn "沒有 $ConfigFile —— 沒有東西要套用（全部 inherit，跟現在一樣）。要開始調校：pwsh .codex/scripts/sdlc.ps1 set agents.reviewer.effort=high -Apply（它會替你建設定檔）"
            $script:Data.error = 'no-config'
        }
        return 2
    }
    $res = Invoke-TuningApply $Target $cfg
    foreach ($w in $res.warnings) { Warn $w }
    $script:Data.changed  = @($res.changed)
    $script:Data.warnings = @($res.warnings)
    if ($res.changed.Count -gt 0) { Say "更新了：$($res.changed -join '、')" } else { Say '沒有變更 —— toml 的 SDLC-TUNING 區塊已經跟設定檔一致。' }
    return 0
}

# ---- set：改設定的單一入口 ----
#
# 手改 JSON 的三種壞法都是靜默的：值打錯（Codex 不檢查 effort，要到呼叫 API 才出事）、
# key 打錯（沒有人讀它，設定等於沒設）、改完忘了 apply（流程用的是舊值）。
# 所以這裡**先依 schema 驗完全部的值才寫** —— 有一組不對，一個字都不動 —— 而 -Apply 讓「寫」跟「套用」是同一個動作。
# VS Code extension 的設定面板也只經過這裡寫檔。

function Get-ConfigSchema([string]$root) {
    return Read-JsonFile (Join-Path $root $ConfigSchemaRel)
}

# 沿著 key 路徑往 schema 裡走（properties → additionalProperties，途中展開 $ref）。走不到 = 不認得的 key。
function Resolve-SchemaRef($schema, $node) {
    $guard = 0
    while ($node -and $node.PSObject.Properties['$ref'] -and $guard -lt 10) {
        $m = [regex]::Match([string]$node.'$ref', '^#/definitions/(.+)$')
        if (-not $m.Success -or -not $schema.definitions.PSObject.Properties[$m.Groups[1].Value]) { return $null }
        $node = $schema.definitions.PSObject.Properties[$m.Groups[1].Value].Value
        $guard++
    }
    return $node
}
function Get-SchemaNode($schema, [string[]]$segments) {
    $node = $schema
    foreach ($s in $segments) {
        $node = Resolve-SchemaRef $schema $node
        if (-not $node) { return $null }
        if ($node.properties -and $node.properties.PSObject.Properties[$s]) { $node = $node.properties.PSObject.Properties[$s].Value }
        elseif ($node.additionalProperties -is [pscustomobject]) { $node = $node.additionalProperties }
        else { return $null }
    }
    return Resolve-SchemaRef $schema $node
}

function Get-EditDistance([string]$a, [string]$b) {
    $a = $a.ToLowerInvariant(); $b = $b.ToLowerInvariant()
    $prev = 0..$b.Length
    for ($i = 1; $i -le $a.Length; $i++) {
        $cur = @($i) + @(0) * $b.Length
        for ($j = 1; $j -le $b.Length; $j++) {
            $cost = if ($a[$i - 1] -eq $b[$j - 1]) { 0 } else { 1 }
            $cur[$j] = [Math]::Min([Math]::Min($cur[$j - 1] + 1, $prev[$j] + 1), $prev[$j - 1] + $cost)
        }
        $prev = $cur
    }
    return $prev[$b.Length]
}
function Get-ClosestText([string]$text, [string[]]$candidates) {
    $best = $null; $bestD = [int]::MaxValue
    foreach ($c in $candidates) { $d = Get-EditDistance $text $c; if ($d -lt $bestD) { $bestD = $d; $best = $c } }
    # 差太多就不猜 —— 亂猜一個 key 比不給建議更誤導。
    if ($best -and $bestD -le [Math]::Max(2, [int]($text.Length / 3))) { return $best }
    return $null
}

function Get-KnownAgentNames([string]$root, $cfg) {
    $names = @('orchestrator')
    $dir = Join-Path $root '.codex/agents'
    if (Test-Path $dir) { $names += @(Get-ChildItem $dir -Filter *.toml -File | ForEach-Object { $_.BaseName }) }
    if ($cfg -and $cfg.agents) { $names += @($cfg.agents.PSObject.Properties.Name) }
    return @($names | Sort-Object -Unique)
}

# 驗一組 key=value。回 @{ ok; key; value（已轉型）; message; suggestion; needsApply }。
function Test-SettingAssignment($schema, [string]$key, [string]$raw, [string[]]$agentNames, [string[]]$codexEfforts = @()) {
    $settable = @('review.maxRounds', 'update.check', 'update.source') +
                @($agentNames | ForEach-Object { "agents.$_.effort"; "agents.$_.model" })
    $fail = { param($msg, $sug) [pscustomobject]@{ ok = $false; key = $key; value = $raw; message = $msg; suggestion = $sug; needsApply = $false } }

    if ($key -in @('$schema', '_note', 'workflow-version')) { return & $fail "$key 由 install／update 維護，不能用 set 改" $null }
    if ($key -eq 'models-checked-with') { return & $fail "$key 由 set 自己記（最後一次改 model／effort 時，那台的 Codex 版本），不能直接改" $null }
    if ($key -eq 'update.channel') { return & $fail 'update.channel 已棄用 —— 沒有任何一方讀它，設了也沒有作用' $null }
    $segments = @($key -split '\.')
    if ($segments[0] -ceq 'agents' -and $segments.Count -eq 3 -and $segments[1] -cnotin $agentNames) {
        $near = Get-ClosestText $segments[1] $agentNames
        return & $fail "沒有叫 $($segments[1]) 的 agent（有：$($agentNames -join '、')）" $(if ($near) { "agents.$near.$($segments[2])" } else { $null })
    }
    # 大小寫要完全一樣：JSON 的 key 分大小寫，Review.MaxRounds 會被寫成另一個沒有人讀的 key。
    $node = if ($key -cin $settable) { Get-SchemaNode $schema $segments } else { $null }
    if (-not $node) {
        return & $fail "不認得的設定 $key" (Get-ClosestText $key $settable)
    }

    $value = $raw
    if ($node.type -eq 'integer') {
        $n = 0
        if (-not [int]::TryParse($raw, [ref]$n)) { return & $fail "要是整數，收到 `"$raw`"" $null }
        $value = $n
        $lo = $node.minimum; $hi = $node.maximum
        if (($null -ne $lo -and $n -lt $lo) -or ($null -ne $hi -and $n -gt $hi)) { return & $fail "要是 $lo–$hi 的整數，收到 $n" $null }
    }
    if ($node.enum) {
        $allowed = @($node.enum | ForEach-Object { [string]$_ })
        # effort：這台的 Codex 認得、schema 還沒列的（Codex 升版新增的值）也收 —— 合不合那個模型，Invoke-SettingWrite 跟 model 一起驗。
        $codexKnows = $segments[0] -ceq 'agents' -and $segments.Count -eq 3 -and $segments[2] -ceq 'effort' -and $raw -cin $codexEfforts
        if ($raw -cnotin $allowed -and -not $codexKnows) {
            $near = Get-ClosestText $raw $allowed
            return & $fail "不是合法值 —— 可用：$($allowed -join '、')" $(if ($near) { "$key=$near" } else { $null })
        }
    }
    if ($node.type -eq 'string') {
        if ($null -ne $node.minLength -and $raw.Length -lt $node.minLength) { return & $fail '不能是空的' $null }
        if ($node.pattern -and $raw -notmatch [string]$node.pattern) {
            $why = if ($node.patternErrorMessage) { [string]$node.patternErrorMessage } else { "格式不對（要符合 $($node.pattern)）" }
            return & $fail $why $null
        }
    }
    # orchestrator 沒有 agent 定義檔：它的值只是記錄，apply 不會動任何檔。
    $needsApply = ($segments[0] -eq 'agents' -and $segments[1] -ne 'orchestrator')
    return [pscustomobject]@{ ok = $true; key = $key; value = $value; message = $null; suggestion = $null; needsApply = $needsApply }
}

function Get-ConfigValue($cfg, [string[]]$segments) {
    $node = $cfg
    foreach ($s in $segments) {
        if ($node -isnot [pscustomobject] -or -not $node.PSObject.Properties[$s]) { return $null }
        $node = $node.PSObject.Properties[$s].Value
    }
    return $node
}
function Set-ConfigValue($cfg, [string[]]$segments, $value) {
    $node = $cfg
    for ($i = 0; $i -lt $segments.Count - 1; $i++) {
        $s = $segments[$i]
        if (-not $node.PSObject.Properties[$s] -or $node.PSObject.Properties[$s].Value -isnot [pscustomobject]) {
            # 新的 agent 項目補齊兩個 key，跟 install 產生的形狀一樣。
            $fresh = if ($i -eq 1 -and $segments[0] -eq 'agents') { [pscustomobject]@{ model = 'inherit'; effort = 'inherit' } } else { [pscustomobject]@{} }
            $node | Add-Member -NotePropertyName $s -NotePropertyValue $fresh -Force
        }
        $node = $node.PSObject.Properties[$s].Value
    }
    $leaf = $segments[-1]
    if ($node.PSObject.Properties[$leaf]) { $node.$leaf = $value }
    else { $node | Add-Member -NotePropertyName $leaf -NotePropertyValue $value }
}

# 驗 → 寫 → （-Apply）套用。tune -ApplyProposal 也走這裡。
# $pairs：@( @{ key; raw } )。回 exit code；結果寫進 $script:Data。
function Invoke-SettingWrite([object[]]$pairs, [bool]$preview, [bool]$applyAfter, [bool]$showDiff = $true) {
    $cfgPath = Join-Path $Target $ConfigFile
    $script:Data.changes = @(); $script:Data.errors = @()
    $script:Data.written = $false; $script:Data.applied = $false; $script:Data.preview = $preview; $script:Data.backup = $null

    # 沒有設定檔是合法狀態（＝全部 inherit、修正輪 3）。但你既然叫它改值，就替你建一份預設的 ——
    # 內容跟 install 建的一樣，所以「建檔」這件事本身不改變任何行為，只是讓你有地方放這個值。
    $script:Data.configCreated = $false
    if (-not (Test-Path $cfgPath)) {
        $ver = Get-ContractVersion $Target
        if (-not $ver) {
            Warn "這個資料夾還沒安裝這套工作流（找不到 $VersionRel）—— 先跑 install。"
            $script:Data.error = 'not-installed'
            return 2
        }
        if (-not $preview) {
            Write-JsonFile $cfgPath (Get-DefaultConfig $Target $ver.contract $null)
            $script:Data.configCreated = $true
            Say "建立 $ConfigFile（全部 inherit、修正輪 $DefaultReviewRounds —— 跟沒有這個檔的時候一樣）。"
        }
    }
    # 預覽時檔案可能還不存在：拿一份空的當現況，差異就會顯示成「（沒設）→ 新值」。
    $rawText = if (Test-Path $cfgPath) { [IO.File]::ReadAllText($cfgPath) } else { '{}' }
    $cfg = $null
    try { $cfg = $rawText | ConvertFrom-Json -ErrorAction Stop } catch { }
    if ($cfg -isnot [pscustomobject]) { Warn "$ConfigFile 解析不了 —— 先把 JSON 修好（set 不在壞掉的檔上寫）。"; $script:Data.error = 'config-unreadable'; return 2 }
    $schema = Get-ConfigSchema $Target
    if (-not $schema) { Warn "找不到或解析不了 $ConfigSchemaRel —— 沒有它就驗不了值，所以一個字都沒寫。重跑 update 補回工具檔。"; $script:Data.error = 'schema-unreadable'; return 2 }
    if ($pairs.Count -eq 0) { Warn '沒有要改的值。用法：sdlc.ps1 set agents.reviewer.effort=high review.maxRounds=4 [-Apply]'; $script:Data.error = 'no-assignments'; return 2 }

    $agentNames = Get-KnownAgentNames $Target $cfg
    # model／effort 要對這台的 Codex 驗：有這兩種 key 才去問 codex（只改 review.* 之類的不付那半秒）。
    $catalog = $null
    if (@($pairs | Where-Object { $_.key -match '^agents\.[^.]+\.(model|effort)$' }).Count -gt 0) { $catalog = Get-ModelCatalog $Target }
    $codexEfforts = if ($catalog -and $catalog.available) { @(Get-CatalogEffortOrder $catalog) } else { @() }
    $checked = @()
    foreach ($p in $pairs) {
        $r = Test-SettingAssignment $schema $p.key $p.raw $agentNames $codexEfforts
        if (-not $r.ok) {
            $script:Data.errors += [ordered]@{ key = $r.key; value = $r.value; message = $r.message; suggestion = $r.suggestion }
        } else {
            $checked += $r
        }
    }
    if ($script:Data.errors.Count -gt 0) {
        foreach ($e in $script:Data.errors) {
            Warn "$($e.key)=$($e.value)：$($e.message)$(if ($e.suggestion) { " —— 是不是要 $($e.suggestion)？" })"
        }
        Warn '有值不合法，這次一個值都沒寫。'
        $script:Data.error = 'invalid'
        return 2
    }

    # 同一個 key 給兩次：以後面的為準（-Preset 之後再個別覆寫就是這樣用的）。
    $final = [ordered]@{}
    foreach ($r in $checked) { $final[$r.key] = $r }
    $changed = 0
    foreach ($r in $final.Values) {
        $segments = @($r.key -split '\.')
        $before = Get-ConfigValue $cfg $segments
        # JSON 讀回來的整數是 Int64，驗過的值是 Int32 —— 比數值；字串 "3" 對整數 3 則算不同（寫回去會修好型別）。
        $isNum = { param($x) $x -is [int] -or $x -is [long] }
        $same = if ($null -eq $before) { $false }
                elseif ((& $isNum $before) -and (& $isNum $r.value)) { [long]$before -eq [long]$r.value }
                elseif ($before -is [string] -and $r.value -is [string]) { $before -ceq $r.value }
                else { $false }
        $script:Data.changes += [ordered]@{
            key = $r.key
            from = $before
            to = $r.value
            changed = -not $same
            needsApply = $r.needsApply
        }
        if (-not $same) { $changed++; Set-ConfigValue $cfg $segments $r.value }
    }

    # model／effort：照這台 Codex 的模型清單驗「改完之後」每個被動到的 agent —— 同一個 agent 的 model 與 effort 要一起看
    # （effort 合不合法由模型決定）。會讓子代理起不來的跟「值不合法」一樣擋；只在別台才會出事的照寫，但講。
    $touched = @($final.Keys | Where-Object { $_ -match '^agents\.[^.]+\.(model|effort)$' } | ForEach-Object { ($_ -split '\.')[1] } | Sort-Object -Unique)
    if ($touched.Count -gt 0) {
        if (-not $catalog) { $catalog = Get-ModelCatalog $Target }
        $session = Get-SessionModel $Target $catalog
        $checkedWith = if ($cfg.PSObject.Properties['models-checked-with']) { [string]$cfg.'models-checked-with' } else { $null }
        $mf = @(foreach ($a in $touched) {
            $ac = Get-AgentConfig $cfg $a
            Test-ModelChoice $catalog $session $a $(if ($ac) { [string]$ac.model } else { $null }) $(if ($ac) { [string]$ac.effort } else { $null }) $checkedWith
        })
        foreach ($f in @($mf | Where-Object level -eq 'problem')) {
            $isModel = $f.status -eq 'unknown-model'
            $script:Data.errors += [ordered]@{ key = "agents.$($f.agent).$(if ($isModel) { 'model' } else { 'effort' })"; value = $(if ($isModel) { $f.model } else { $f.effort }); message = $f.message; suggestion = $f.suggestion }
        }
        if ($script:Data.errors.Count -gt 0) {
            foreach ($e in $script:Data.errors) {
                Warn "$($e.key)=$($e.value)：$($e.message)$(if ($e.suggestion) { " —— 是不是要 $($e.suggestion)？" })"
            }
            Warn '有值在這台的 Codex 上跑不起來，這次一個值都沒寫。'
            $script:Data.error = 'invalid'
            return 2
        }
        foreach ($f in @($mf | Where-Object level -eq 'warn')) { Warn (Format-ModelFinding $f) }
        $modelChanged = @($script:Data.changes | Where-Object { $_.changed -and $_.key -match '^agents\.[^.]+\.(model|effort)$' }).Count
        if (-not $catalog.available) {
            Say "model／effort 只照 schema 驗了 —— $(Get-CatalogReasonText $catalog)。這台的模型支不支援沒有驗。"
        } elseif ($modelChanged -gt 0) {
            # 記下這組值是在哪一版 Codex 上選的：別台的 doctor 才分得出「這台太舊，該升級」還是「新版拿掉了，該換」。
            Set-ConfigValue $cfg @('models-checked-with') ([string]$catalog.codex.version)
        }
    }

    $width = (@($final.Keys | ForEach-Object { $_.Length }) | Measure-Object -Maximum).Maximum
    foreach ($c in @($script:Data.changes | Where-Object { $showDiff })) {
        $show = { param($v) if ($null -eq $v) { '（沒設）' } elseif ([string]$v -eq '') { '（空）' } else { [string]$v } }
        $note = if (-not $c.changed) { '（沒變）' }
                elseif ($c.key -like 'agents.orchestrator.*') { '只是記錄，強制不了 —— 啟動 codex 時要自己帶' }
                elseif ($c.key -like 'review.*') { '不必 apply，下一次委派就生效' }
                elseif (-not $c.needsApply) { '不必 apply' }
                else { '' }
        Say ("{0}  {1} → {2}  {3}" -f $c.key.PadRight($width), (& $show $c.from), (& $show $c.to), $note).TrimEnd()
    }

    if ($preview) { Say '（預覽 —— 什麼都沒寫）'; return 0 }

    if ($changed -gt 0) {
        # 改寫整份會吃掉註解。沒有明確同意就不寫；同意了先備份。
        if (Test-JsonHasComments $rawText) {
            if (-not $Yes) {
                Warn "$ConfigFile 裡有註解 —— 這個檔不支援註解，改寫會把它們吃掉。把說明搬進 _note 再跑一次，或加 -Yes 照寫（原檔會先備份）。"
                $script:Data.error = 'has-comments'
                return 2
            }
            $dst = Join-Path $Target "$StateDir/sdlc.config.with-comments.json"
            New-Item -ItemType Directory -Path (Split-Path $dst -Parent) -Force | Out-Null
            Copy-Item $cfgPath $dst -Force
            $script:Data.backup = ConvertTo-Rel $Target (Resolve-Path $dst).Path
            Warn "原檔（含註解）備份在 $($script:Data.backup)。"
        }
        Write-JsonFile $cfgPath $cfg
        $script:Data.written = $true
        Say "已寫入 $ConfigFile。"
    } else {
        Say '值都跟現在一樣，沒有寫檔。'
    }

    $pending = @($script:Data.changes | Where-Object { $_.changed -and $_.needsApply })
    if ($applyAfter) {
        $keep = @{ changes = $script:Data.changes; written = $script:Data.written; backup = $script:Data.backup; preview = $false }
        $code = Invoke-Apply
        foreach ($k in $keep.Keys) { $script:Data[$k] = $keep[$k] }
        $script:Data.errors = @()
        $script:Data.applied = ($code -eq 0)
        return $code
    }
    if ($pending.Count -gt 0) { Say '還沒套用 —— 跑 pwsh .codex/scripts/sdlc.ps1 apply（或下次加 -Apply），流程才會用新值。' }
    return 0
}

function Invoke-Set {
    $pairs = @()
    $script:Data.preset = $null
    if ($Preset) {
        $profiles = Read-JsonFile (Join-Path $Target $ProfilesRel)
        $map = if ($profiles -and $profiles.presets) { $profiles.presets.PSObject.Properties[$Preset].Value } else { $null }
        if (-not $map) { Warn "找不到預設組合 `"$Preset`"（$ProfilesRel）。"; $script:Data.error = 'preset-not-found'; return 2 }
        $script:Data.preset = $Preset
        foreach ($a in $map.PSObject.Properties) {
            foreach ($k in @('model', 'effort')) {
                if ($a.Value.PSObject.Properties[$k]) { $pairs += @{ key = "agents.$($a.Name).$k"; raw = [string]$a.Value.$k } }
            }
        }
    }
    foreach ($a in @($Assignments)) {
        if (-not $a) { continue }
        $i = $a.IndexOf('=')
        if ($i -lt 1) {
            Warn "`"$a`" 不是 key=value 的形狀（例如 agents.reviewer.effort=high）。這次一個值都沒寫。"
            $script:Data.error = 'invalid'
            $script:Data.errors = @([ordered]@{ key = $a; value = $null; message = '不是 key=value 的形狀'; suggestion = $null })
            return 2
        }
        $pairs += @{ key = $a.Substring(0, $i).Trim(); raw = $a.Substring($i + 1) }
    }

    # 換一整組預設是「一次改很多值」—— 先給人看要改什麼，確認了才寫。個別指定的值是明確的，不必再問。
    if ($Preset -and -not $Preview -and -not $Yes) {
        $code = Invoke-SettingWrite $pairs $true $false
        if ($code -ne 0) { return $code }
        if (-not (Confirm-Step "換成預設組合 $Preset 嗎？")) { $script:Data.error = 'cancelled'; Say '已取消，一個字都沒寫。'; return 2 }
        return (Invoke-SettingWrite $pairs $false ([bool]$Apply) $false)
    }
    return (Invoke-SettingWrite $pairs ([bool]$Preview) ([bool]$Apply))
}

# update.check 的頻率。daily = 距上次查過滿 24 小時才再查；查失敗（離線）的話一小時內不重試 ——
# extension 的背景刷新每開一次視窗就叫一次，離線的人不該每次都等一個 8 秒的逾時。
# 快取記的 installed 跟現在的版本對不上（剛升級完）一律視為到期：那份快取說的是升級前的世界。
function Test-UpdateDue($cache, [string]$installed) {
    if (-not $cache) { return $true }
    if ([string]$cache.installed -ne $installed) { return $true }
    $now = [DateTime]::UtcNow
    $checked = $null; $attempted = $null
    try { if ($cache.'checked-at') { $checked = ([DateTime]$cache.'checked-at').ToUniversalTime() } } catch { }
    try { if ($cache.'attempted-at') { $attempted = ([DateTime]$cache.'attempted-at').ToUniversalTime() } } catch { }
    if ($checked -and ($now - $checked).TotalHours -lt 24) { return $false }
    if ($attempted -and ($now - $attempted).TotalHours -lt 1) { return $false }
    return $true
}

function Invoke-CheckUpdate {
    $cfg = Read-JsonFile (Join-Path $Target $ConfigFile)
    $tgtVer = Get-ContractVersion $Target
    if (-not $cfg -or -not $tgtVer) { Warn '這個專案還沒安裝這套工作流。'; $script:Data.status = 'not-installed'; return 2 }
    $script:Data.installed = $tgtVer.contract
    if ($cfg.update -and $cfg.update.check -eq 'never') {
        $script:Data.status = 'disabled'
        Say '設定為不檢查更新（update.check = never）。'
        return 0
    }
    # 不認得的值照 daily 算（會連網）。打成 "nevr" 的人以為關掉了 —— 所以要講。
    if ($cfg.update -and $cfg.update.check -and [string]$cfg.update.check -notin $UpdateChecks) {
        Warn "update.check 是 `"$($cfg.update.check)`"，不是 $($UpdateChecks -join '／') —— 照 daily 算，會連網檢查。改法：pwsh .codex/scripts/sdlc.ps1 set update.check=never"
    }

    $cachePath = Join-Path $Target $CacheRel
    $cache = Read-JsonFile $cachePath
    if ($IfDue -and -not (Test-UpdateDue $cache $tgtVer.contract)) {
        $script:Data.status = 'not-due'
        $script:Data.latest = if ($cache.latest) { [string]$cache.latest } else { $null }
        $script:Data.newer  = [bool]$cache.newer
        Say "上次檢查還沒滿一天（update.check = daily），這次不連網。"
        return 0
    }

    $src = if ($cfg.update) { [string]$cfg.update.source } else { '' }
    $repo = Get-ReleaseRepo $src
    if (-not $repo) {
        $script:Data.status = 'unsupported-source'
        Warn "update.source 認不得（$src）—— $ReleaseSourceHint。這次無法自動檢查，請手動看發佈頁。"
        return 0
    }
    $script:Data.provider = $repo.provider

    $rel = $null
    try {
        $rel = Get-LatestRelease $repo
        if (-not $rel) { throw 'no release' }
    } catch {
        # 離線、逾時、私有 repo（沒設 token）、還沒有任何發佈一律靜默 —— 檢查更新失敗不是使用者要處理的事。
        # 只記下「試過了」，好讓 -IfDue 一小時內不重試；其餘欄位原樣保留（newer 沒有就是 false，通知不會亂喊）。
        $keep = [ordered]@{}
        if ($cache) { foreach ($p in $cache.PSObject.Properties) { $keep[$p.Name] = $(if ($p.Value -is [DateTime]) { $p.Value.ToString('o') } else { $p.Value }) } }
        if (-not $keep.Contains('installed')) { $keep['installed'] = $tgtVer.contract; $keep['newer'] = $false; $keep['latest'] = ''; $keep['seen'] = '' }
        $keep['attempted-at'] = (Get-Date).ToString('o')
        Write-JsonFile $cachePath $keep
        $script:Data.status = 'unreachable'
        Say '檢查不到更新（離線或來源不可達）。不影響任何流程。'
        return 0
    }

    $latest = ([string]$rel.tag) -replace '^v', ''
    $newer  = [bool]($latest -and ((Compare-Semver $latest $tgtVer.contract) -gt 0))
    $checkedAt = (Get-Date).ToString('o')
    Write-JsonFile $cachePath ([ordered]@{
        'checked-at' = $checkedAt
        'installed'  = $tgtVer.contract
        'latest'     = $latest
        'newer'      = $newer
        'notes'      = if ($rel.body) { [string]$rel.body } else { '' }
        'url'        = [string]$rel.url
        'seen'       = ''
    })
    $script:Data.status    = if ($newer) { 'newer' } else { 'up-to-date' }
    $script:Data.latest    = $latest
    $script:Data.newer     = $newer
    $script:Data.url       = [string]$rel.url
    $script:Data.checkedAt = $checkedAt
    if ($newer) { Say "有新版 $latest（你在 $($tgtVer.contract)）。看變更：pwsh .codex/scripts/sdlc.ps1 whatsnew"; Write-UpgradeHow $latest }
    else        { Say "已是最新（$($tgtVer.contract)）。" }
    return 0
}

# 「怎麼升級」照這台裝的 extension 講。4.16.0 以前的 extension 沒有一鍵升級，點「有新版」只會跑 whatsnew ——
# 這段文字就是它顯示在輸出面板的東西，所以要在這裡告訴他先換 extension，不然他會一直點、一直只看到說明。
function Write-UpgradeHow([string]$latest) {
    $ext = @(Get-InstalledExtensions | Where-Object { $_.version })
    $old = @($ext | Where-Object { (Compare-Semver $_.version $MinUpgradeExtension) -lt 0 })
    $new = @($ext | Where-Object { (Compare-Semver $_.version $MinUpgradeExtension) -ge 0 })
    foreach ($x in $old) {
        Say "VS Code：$($x.product) 裡的 extension 是 $($x.version)，還沒有一鍵升級（$MinUpgradeExtension 起才有）。先換 extension：從發佈頁下載附件 codex-sdlc-$latest.vsix，跑 code --install-extension codex-sdlc-$latest.vsix --force，重新載入視窗；之後點側欄的「有新版」就會直接升級這個專案。"
    }
    if ($new.Count -gt 0) { Say "VS Code：點側欄的「有新版 $latest」或狀態列選「升級到 $latest」—— 先列出會動哪些檔，你確認了才升級。" }
    Say '終端機：把新版發佈物解壓到別處，然後 pwsh <發佈物>/.codex/scripts/sdlc.ps1 update -Target .'
}

function Invoke-WhatsNew {
    $cachePath = Join-Path $Target $CacheRel
    $cache = Read-JsonFile $cachePath
    $v = Get-ContractVersion $Target
    # 快取說的 installed 跟現在的版本對不上 = 升級前留下來的，不拿它唸「有新版」。
    if ($cache -and $cache.newer -and (-not $v -or [string]$cache.installed -eq $v.contract)) {
        $script:Data.source    = 'cache'
        $script:Data.latest    = [string]$cache.latest
        $script:Data.installed = [string]$cache.installed
        $script:Data.url       = [string]$cache.url
        $script:Data.notes     = [string]$cache.notes
        Say "新版 $($cache.latest)（你在 $($cache.installed)）"
        if ($cache.url) { Say $cache.url }
        Say ''
        if ($cache.notes) { Say $cache.notes }
        # 看過就安靜下來，直到下一個版本 —— 通知的目的是讓你看一次，不是每次 spawn 都提醒。
        $cache.seen = $cache.latest
        Write-JsonFile $cachePath $cache
        $script:Data.markedSeen = $true
        Say ''
        Write-UpgradeHow ([string]$cache.latest)
        return 0
    }
    if (-not $v) { Warn '這個專案還沒安裝這套工作流。'; $script:Data.source = 'not-installed'; return 2 }
    $script:Data.source    = 'installed'
    $script:Data.installed = $v.contract
    $script:Data.minCompatible = $v.minCompat
    $script:Data.entries   = @()
    Say "目前版本 $($v.contract)（最低相容 $($v.minCompat)）。這一版的變更說明："
    foreach ($p in @($v.raw.PSObject.Properties | Where-Object { $_.Name -match '^v\d' })) {
        $script:Data.entries += [ordered]@{ key = $p.Name; text = [string]$p.Value }
        Say ''
        Say "[$($p.Name)] $($p.Value)"
    }
    return 0
}

# tune -ApplyProposal：套**存下來的那份**提議，不重算。
# 以前是重算一次再套 —— 看提議與按套用之間 repo 變了（例如 legacy-schema 多了檔），套進去的就跟畫面上的不一樣。
function Invoke-ApplyStoredProposal {
    $script:Data.applied = $false
    $script:Data.proposal = @()
    $stored = Read-JsonFile (Join-Path $Target $ProposalRel)
    if (-not $stored -or -not $stored.proposal) {
        Warn '還沒有提議可以套用 —— 先跑 pwsh .codex/scripts/sdlc.ps1 tune 看一次。'
        $script:Data.error = 'no-proposal'
        return 2
    }
    $cfg = Read-JsonFile (Join-Path $Target $ConfigFile)
    $items = @($stored.proposal)
    $only = @($Only | ForEach-Object { $_ -split ',' } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    if ($only.Count -gt 0) {
        $names = @($items | ForEach-Object { [string]$_.agent })
        $unknown = @($only | Where-Object { $_ -cnotin $names })
        if ($unknown.Count -gt 0) {
            Warn "提議裡沒有 $($unknown -join '、')（有：$($names -join '、')）。這次什麼都沒套。"
            $script:Data.error = 'unknown-agent'
            return 2
        }
        $items = @($items | Where-Object { [string]$_.agent -cin $only })
    }
    # 提議是照工作流的 agent 名冊產生的；這個專案沒有的 agent 略過，不讓它擋住其他幾個。
    $known = Get-KnownAgentNames $Target $cfg
    foreach ($skip in @($items | Where-Object { [string]$_.agent -cnotin $known })) { Say "略過 $($skip.agent)：這個專案沒有這個 agent。" }
    $items = @($items | Where-Object { [string]$_.agent -cin $known })

    $proposal = @($items | ForEach-Object {
        $cur = Get-AgentConfig $cfg ([string]$_.agent)
        [ordered]@{
            agent    = [string]$_.agent
            current  = $(if ($cur -and $cur.effort) { [string]$cur.effort } else { 'inherit' })
            proposed = [string]$_.effort
            reason   = [string]$_.reason
            signal   = [string]$_.signal
        }
    })
    $generatedAt = ConvertTo-IsoText $stored.'generated-at'
    Say "套用 $generatedAt 的提議$(if ($only.Count -gt 0) { "（只套 $($only -join '、')）" })。不重算 —— 套的就是你看到的那一份。"

    $pairs = @($proposal | ForEach-Object { @{ key = "agents.$($_.agent).effort"; raw = $_.proposed } })
    $code = Invoke-SettingWrite $pairs $false $true
    $script:Data.proposal    = $proposal
    $script:Data.signals     = $stored.signals
    $script:Data.generatedAt = $generatedAt
    return $code
}

function Invoke-Tune {
    if ($ApplyProposal) { return Invoke-ApplyStoredProposal }
    $cfgPath = Join-Path $Target $ConfigFile
    $cfg = Read-JsonFile $cfgPath
    if (-not $cfg) {
        if (Test-Path $cfgPath) { Warn "$ConfigFile 解析不了 —— 先把 JSON 修好。"; $script:Data.error = 'config-unreadable'; return 2 }
        if (-not (Get-ContractVersion $Target)) { Warn '這個專案還沒安裝這套工作流。'; $script:Data.error = 'not-installed'; return 2 }
        # 沒有設定檔照樣能給建議：現值一律是 inherit，套用的時候 set 會替他建檔。
        Say "沒有 $ConfigFile —— 現值一律當成 inherit（套用建議時會替你建一份）。"
    }

    # 訊號：只用便宜的。repo-index -StatusOnly 不讀任何檔內容。
    $signals = [ordered]@{ file_count = $null; language = ''; build_tool = ''; legacy_schema = 0 }
    $idx = Join-Path $Target '.codex/scripts/repo-index.ps1'
    if (Test-Path $idx) {
        try {
            $r = Invoke-PwshScript $idx @('-StatusOnly') (Resolve-Path $Target).Path
            $st = $r.stdout | ConvertFrom-Json
            $signals.file_count = $st.file_count
            $signals.language   = [string]$st.language
            $signals.build_tool = [string]$st.build_tool
        } catch {
            # 索引拿不到就用不到訊號，但 tune 仍然要能跑完 —— 它是使用者主動叫的，不該卡住。
            Warn "repo-index 取不到訊號（$($_.Exception.Message)），改用可得的部分。"
        }
    }
    $legacy = Join-Path $Target 'bdd-docs/artifacts/legacy-schema'
    if (Test-Path $legacy) { $signals.legacy_schema = @(Get-ChildItem $legacy -Filter *.sql -File -ErrorAction SilentlyContinue).Count }

    $fc = if ($null -ne $signals.file_count) { [int]$signals.file_count } else { -1 }
    $items = @()

    # sa-analyst：成本驅動是**讀取量**，而讀取量大時的失敗模式是逾時，不是想得不夠深。
    # 所以大 repo 往下調 —— 釘 high 正是大型 legacy repo 分析逾時的成因（1d8e411 → 7159725）。
    if ($fc -ge 8000) {
        $items += @{ agent='sa-analyst'; effort='low'; reason='repo 很大，analyze 的失敗模式是逾時而不是想得不夠深'; signal="file_count=$fc" }
    } elseif ($fc -ge 3000 -or $signals.legacy_schema -gt 0) {
        $items += @{ agent='sa-analyst'; effort='medium'; reason='讀取量偏大或有舊系統逆推，往下調並把 analyze 的範圍切小'; signal="file_count=$fc, legacy-schema=$($signals.legacy_schema)" }
    } else {
        $items += @{ agent='sa-analyst'; effort='inherit'; reason='規模不大，沒有理由付'; signal="file_count=$fc" }
    }

    if ($signals.legacy_schema -gt 0) {
        $items += @{ agent='implementer'; effort='medium'; reason='要對著逆推回來的舊邏輯寫，測試回圈會變長'; signal="legacy-schema=$($signals.legacy_schema) 個 .sql" }
    } else {
        $items += @{ agent='implementer'; effort='inherit'; reason='成本在測試回圈的次數，不在單次推理深度；衝 high 買不到東西'; signal='—' }
    }

    $items += @{ agent='reviewer'; effort='high'; reason='輸入小、判斷密度高，而且 ⑤ 的修正輪有上限（預設 3）—— 審得淺就是白付'; signal='一律' }
    $items += @{ agent='orchestrator'; effort='inherit'; reason='它沒有 agent 定義檔，這裡只是記錄；要生效得在 CLI 啟動時自己下'; signal='—' }

    Write-JsonFile (Join-Path $Target $ProposalRel) ([ordered]@{
        'generated-at' = (Get-Date).ToString('o')
        'signals'      = $signals
        'proposal'     = $items
    })

    $script:Data.signals  = $signals
    $script:Data.proposal = @()
    Say "訊號：file_count=$fc、language=$($signals.language)、build_tool=$($signals.build_tool)、legacy-schema=$($signals.legacy_schema)"
    Say ''
    foreach ($i in $items) {
        $cur = Get-AgentConfig $cfg $i.agent
        $now = if ($cur -and $cur.effort) { [string]$cur.effort } else { 'inherit' }
        $script:Data.proposal += [ordered]@{ agent = $i.agent; current = $now; proposed = $i.effort; reason = $i.reason; signal = $i.signal }
        $mark = if ($now -eq $i.effort) { ' ' } else { '*' }
        Say "$mark $($i.agent)：$now → $($i.effort)"
        Say "    理由：$($i.reason)"
        Say "    訊號：$($i.signal)"
    }
    Say ''
    Say "提議寫在 $ProposalRel。這是提議不是動作 —— 要套用：sdlc.ps1 tune -ApplyProposal（只套其中幾個：-Only reviewer,sa-analyst）"

    $script:Data.applied = $false
    $script:Data.generatedAt = ConvertTo-IsoText (Read-JsonFile (Join-Path $Target $ProposalRel)).'generated-at'
    return 0
}

function Invoke-Doctor {
    $problems = 0
    $v = Get-ContractVersion $Target
    if (-not $v) { Warn "$VersionRel 不存在或解析不了。"; $script:Data.error = 'not-installed'; return 2 }
    $script:Data.version = [ordered]@{ contract = [string]$v.contract; minCompatible = [string]$v.minCompat }
    Say "版本 $($v.contract)（最低相容 $($v.minCompat)）"

    $cfgPath = Join-Path $Target $ConfigFile
    $cfg = Read-JsonFile $cfgPath
    $script:Data.unverifiedModel = @()
    if (-not $cfg) {
        $exists = Test-Path $cfgPath
        $script:Data.config = [ordered]@{ exists = $exists; parsable = $false }
        $script:Data.tuning = [ordered]@{ status = $(if ($exists) { 'unparsable' } else { 'no-config' }); stale = @() }
        if ($exists) { Warn "$ConfigFile 解析不了 —— apply 與 doctor 都讀不到你的設定。"; $problems++ }
        else { Say "$ConfigFile 不存在 —— per-agent 調校未啟用，全部交由 Codex CLI 決定（這是合法狀態）。" }
    } else {
        # 註解：讀得進去，但下一次 update／set／tune 改寫時會不見 —— 不算問題，但要先說。
        $hasComments = Test-JsonHasComments ([IO.File]::ReadAllText($cfgPath))
        $script:Data.config = [ordered]@{ exists = $true; parsable = $true; comments = $hasComments; schemaRef = [bool]$cfg.PSObject.Properties['$schema'] }
        if ($hasComments) { Warn "$ConfigFile 裡有註解 —— 這個檔不支援註解，下一次 update／set 改寫時會不見。要留的說明請搬進 _note。" }
        $stale = @()
        foreach ($f in @(Get-ChildItem (Join-Path $Target '.codex/agents') -Filter *.toml -File -ErrorAction SilentlyContinue)) {
            $text = [IO.File]::ReadAllText($f.FullName)
            $want = Get-TuningSha (Get-AgentConfig $cfg $f.BaseName)
            $m = [regex]::Match($text, [regex]::Escape($TuneBegin) + '\s+sha=([0-9a-f]{8})')
            if (-not $m.Success -or $m.Groups[1].Value -ne $want) { $stale += $f.Name }
        }
        $script:Data.tuning = [ordered]@{ status = $(if ($stale.Count -gt 0) { 'stale' } else { 'in-sync' }); stale = @($stale) }
        if ($stale.Count -gt 0) {
            Warn "SDLC-TUNING 區塊跟設定檔對不上：$($stale -join '、') —— 跑 pwsh .codex/scripts/sdlc.ps1 apply"
            $problems++
        } else {
            Say '調校區塊與設定檔一致。'
        }
        # 不算問題（不影響流程），但要講：check-update 對認不得的來源只會靜默地查不到。
        $src = if ($cfg.PSObject.Properties['update'] -and $cfg.update.PSObject.Properties['source']) { ([string]$cfg.update.source).Trim() } else { '' }
        if ($src -and -not (Get-ReleaseRepo $src)) {
            Warn "update.source 認不得（$src）—— 更新通知查不到。$ReleaseSourceHint：pwsh .codex/scripts/sdlc.ps1 set update.source=<網址>"
        }
    }

    $baseline = Read-JsonFile (Join-Path $Target $BaselineRel)
    if (-not $baseline) {
        $script:Data.baseline = [ordered]@{ exists = $false; version = $null; fileCount = 0 }
        Say '沒有基準線 —— update 將無法分辨你改過哪些工具檔。跑 install -Adopt 建立一次。'
    } else {
        $n = @($baseline.files.PSObject.Properties).Count
        $script:Data.baseline = [ordered]@{ exists = $true; version = [string]$baseline.'workflow-version'; fileCount = $n }
        Say "基準線：$($baseline.'workflow-version')（$n 個檔）"
    }

    $findings = @(Test-Guidelines $Target $Target)
    foreach ($f in $findings) { if ($f.level -eq 'warn') { Warn $f.text; $problems++ } else { Say $f.text } }
    $script:Data.guidelines = @(Get-FindingData $findings)

    $lint = Invoke-Lint $Target
    $script:Data.lint = $lint
    if (-not $lint.passed) { $problems++ }

    # 修正輪上限。值合不合法由 agent-lint 檢查 13 判（上面已經算進問題數），這裡只算出「實際生效的是幾輪」給人與 extension 看。
    $rawRounds = $null
    if ($cfg -and $cfg.PSObject.Properties['review'] -and $cfg.review -is [pscustomobject] -and $cfg.review.PSObject.Properties['maxRounds']) { $rawRounds = $cfg.review.maxRounds }
    $roundsInvalid = @($lint.violations | Where-Object { $_.rule -in @('review-max-rounds-invalid', 'review-config-invalid') }).Count -gt 0
    $roundsFromConfig = (-not $roundsInvalid) -and ($rawRounds -is [int] -or $rawRounds -is [long])
    $script:Data.review = [ordered]@{
        maxRounds  = $(if ($roundsFromConfig) { [int]$rawRounds } else { $DefaultReviewRounds })
        source     = $(if ($roundsFromConfig) { 'config' } else { 'default' })
        valid      = -not $roundsInvalid
    }
    if ($roundsInvalid) { Say "修正輪上限：$DefaultReviewRounds 輪（review.maxRounds 寫壞了，handoff-lint 照預設算 —— 見上面的 agent-lint）" }
    else { Say "修正輪上限：$($script:Data.review.maxRounds) 輪（$(if ($roundsFromConfig) { "$ConfigFile 的 review.maxRounds" } else { '預設' })）" }

    $trust = Get-HookTrust $Target
    $script:Data.hooks = $trust
    $problems += (Show-HookTrust $trust)
    $heartbeat = Get-HookHeartbeat $Target
    $script:Data.heartbeat = $heartbeat
    $problems += (Show-HookHeartbeat $heartbeat)
    $gitHooks = Get-GitHooksStatus $Target
    $script:Data.gitHooks = $gitHooks
    Show-GitHooks $gitHooks

    $envItems = @(Get-EnvironmentReport $Target)
    $script:Data.environment = @($envItems)
    $problems += (Show-Environment $envItems)

    # model／effort 對這台的 Codex：會讓子代理起不來的算問題；只在別台／別的主對話模型才會出事的，講但不算。
    $catalog = Get-ModelCatalog $Target
    $session = Get-SessionModel $Target $catalog
    $mf = @(Get-ModelFindings $catalog $session $cfg $Target)
    $script:Data.models = Get-ModelsData $catalog $session $mf $cfg
    # 4.8 起的欄位：「釘了 model，但沒能對這台的 Codex 驗」（4.15 以前是「model 這個 key 沒驗證過」—— 已經實測會生效）。
    $script:Data.unverifiedModel = @($mf | Where-Object { $_.status -eq 'unverified' -and $_.model -ne 'inherit' } | ForEach-Object { $_.agent })
    $pinned = @($mf | Where-Object { $_.status -ne 'ok' })
    if (-not $catalog.available) {
        if ($pinned.Count) { Say "model／effort：沒有對 Codex 驗證 —— $(Get-CatalogReasonText $catalog)。" }
    } else {
        foreach ($f in @($mf | Where-Object { $_.level -in @('problem', 'warn') })) {
            Warn (Format-ModelFinding $f)
            if ($f.level -eq 'problem') { $problems++ }
        }
        if (-not @($mf | Where-Object { $_.level -in @('problem', 'warn') }).Count) {
            Say "model／effort：對照這台 Codex $($catalog.codex.version) 的模型清單，沒有問題$(if ($pinned.Count -eq 0) { '（全部 inherit）' })。"
        }
    }

    # 更新快取：installed 跟現在的版本對不上 = 升級前留下來的，不當真（見 handoff-lint 尾端同一條）。
    $cache = Read-JsonFile (Join-Path $Target $CacheRel)
    $cacheStale = [bool]($cache -and [string]$cache.installed -ne [string]$v.contract)
    $newer = [bool]($cache -and $cache.newer -and -not $cacheStale)
    $script:Data.update = [ordered]@{
        cached    = [bool]$cache
        stale     = $cacheStale
        newer     = $newer
        latest    = $(if ($cache -and $cache.latest) { [string]$cache.latest } else { $null })
        seen      = [bool]($cache -and $cache.latest -and $cache.seen -eq $cache.latest)
        checkedAt = $(if ($cache) { ConvertTo-IsoText $cache.'checked-at' } else { $null })
        check     = $(if ($cfg -and $cfg.update -and $cfg.update.check) { [string]$cfg.update.check } else { 'daily' })
    }
    if ($newer -and $cache.seen -ne $cache.latest) { Say "有新版 $($cache.latest) —— pwsh .codex/scripts/sdlc.ps1 whatsnew" }

    # 編輯器那一層：只報、不擋（它是整台機器共用的，不是這個專案的健康狀態）。
    $ext = @(Get-InstalledExtensions)
    $script:Data.editor = [ordered]@{ installed = @($ext | ForEach-Object { [ordered]@{ product = $_.product; version = $_.version; jsonSchema = $_.jsonSchema; compatible = $_.compatible } }) }
    # 沒裝也說一行：在 VS Code 裡找不到介面的人會來跑 doctor，而沒裝的 extension 自己不可能告訴他。
    if ($ext.Count -eq 0) { Say "VS Code extension：這台機器沒裝（選用）。要狀態列與一鍵指令，用發佈頁的附件 codex-sdlc-<版本>.vsix 裝：code --install-extension <那個檔>。" }
    foreach ($x in $ext) {
        if ($x.compatible) { Say "VS Code extension：$($x.product) 裝的是 $($x.version)，跟這個專案相容。" }
        else { Say "VS Code extension：$($x.product) 裝的是 $($x.version)，跟這個專案（$($v.contract)）的 -Json 形狀對不上 —— 狀態列會顯示不了；換成這一版發佈物附的 vsix。" }
    }

    $script:Data.problems = $problems
    return $(if ($problems -gt 0) { 2 } else { 0 })
}

# 這台的 Codex 有哪些模型、各支援哪些 effort，以及每個 agent 現在的值在這台會怎樣。
# 沒裝工作流的資料夾也能用（只列清單）。問不到清單 → exit 2：這個指令要回答的就是這件事。
function Invoke-Models {
    $catalog = Get-ModelCatalog $Target
    $cfg = Read-JsonFile (Join-Path $Target $ConfigFile)
    $session = Get-SessionModel $Target $catalog
    $installed = [bool](Get-ContractVersion $Target)
    $mf = if ($installed) { @(Get-ModelFindings $catalog $session $cfg $Target) } else { @() }
    $script:Data.models = Get-ModelsData $catalog $session $mf $cfg
    if (-not $catalog.available) {
        Warn "問不到模型清單 —— $(Get-CatalogReasonText $catalog)。set 只能照 schema 驗值，這台支不支援沒有驗。"
        return 2
    }

    $src = if ($catalog.source -eq 'cache') { '快取' } else { '剛問過' }
    Say "Codex $($catalog.codex.version) 的模型清單（$($catalog.codex.path)；$src）："
    $shown = @($catalog.models | Where-Object { $_.visible } | Sort-Object { $_.priority })
    $w = (@($shown | ForEach-Object { $_.slug.Length }) + 8 | Measure-Object -Maximum).Maximum
    foreach ($m in $shown) {
        $levels = @($m.efforts | ForEach-Object { if ($_ -eq $m.defaultEffort) { "$_*" } else { $_ } }) -join ' '
        $tag = if ($m.slug -eq $catalog.default) { '   ← 沒設模型時用它' } else { '' }
        Say ("  {0}  {1}{2}" -f $m.slug.PadRight($w), $levels, $tag)
    }
    $hidden = @($catalog.models | Where-Object { -not $_.visible } | ForEach-Object { $_.slug })
    Say "  （* = 那個模型的預設 effort$(if ($hidden.Count) { "；沒列出的隱藏模型：$($hidden -join '、')" })）"
    Say "主對話：$(if ($session.model) { "$($session.model)（$($session.source)）" } else { '看不出來' }) —— model 是 inherit 的 agent 用它。"
    if (-not $installed) { return 0 }

    $problems = 0
    Say '各 agent：'
    foreach ($f in $mf) {
        $mark = switch ($f.level) { 'problem' { '✖' } 'warn' { '⚠' } default { '✓' } }
        $line = "  $mark $($f.agent)：model=$($f.model)$(if ($f.model -eq 'inherit' -and $f.effectiveModel) { "（$($f.effectiveModel)）" })　effort=$($f.effort)"
        Say $line
        if ($f.level -in @('problem', 'warn')) { Warn (Format-ModelFinding $f) }
        if ($f.level -eq 'problem') { $problems++ }
    }
    return $(if ($problems -gt 0) { 2 } else { 0 })
}

# ---- learn：審核一再抓到的問題，收成一份清單 ----
#
# ⑤ 抓到的錯只會讓**這一個**需求多跑一輪修正；下一個需求，implementer 還是可能犯同一個。同一類錯在不同需求裡
# 被抓第二次，就該往前移：能機械判定的進 guidelines/rules.json（寫檔當下 guideline-gate 就擋），要判斷的進
# guidelines/*.md 的 MUST（implementer 動手前就讀到）。這裡只做機械的那一半 —— 把每個需求、每一輪的發現讀出來、
# 同一需求內去重；「哪幾項是同一類、該寫成什麼規則」要讀懂問題才分得出來，交給 skill `review-learning`。
# **一個字都不寫**：規範是團隊的，寫進去要他點頭。
#
# 來源：bdd-docs/{feature-id}/reviews/*.md（dlp-gate 替每一輪留的快照，4.19.0 起）＋ 最新的 review.md。
# 更早的需求只剩最後一輪 —— PASS 那一輪通常只有 [建議]，已經修掉的 [必修] 看不到。
function Read-ReviewFindings([string]$file) {
    $lines = [IO.File]::ReadAllLines($file)
    $out = @()
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $m = [regex]::Match($lines[$i], '^\s*\d+\.\s*\[(必修|建議)\]\s*(.+?)\s+——\s+(.+?)\s*$')
        if (-not $m.Success) { continue }
        $loc = $m.Groups[2].Value.Trim().Trim('`', '{', '}')
        $failure = $null
        if ($i + 1 -lt $lines.Count) {
            $f = [regex]::Match($lines[$i + 1], '^\s+會怎麼壞[:：]\s*(.+?)\s*$')
            if ($f.Success) { $failure = $f.Groups[1].Value }
        }
        $out += [pscustomobject]@{
            severity = $m.Groups[1].Value
            location = $loc
            file     = ($loc -replace '(:\d+(-\d+)?)+$', '')
            problem  = $m.Groups[3].Value
            failure  = $failure
        }
    }
    return $out
}

function Invoke-Learn {
    if (-not (Get-ContractVersion $Target)) { Warn "$VersionRel 不存在或解析不了。"; $script:Data.error = 'not-installed'; return 2 }
    $root = (Resolve-Path $Target).Path
    $docs = Join-Path $root 'bdd-docs'
    $features = @(); $all = @(); $snapshots = 0
    foreach ($d in @(Get-ChildItem $docs -Directory -ErrorAction SilentlyContinue | Where-Object { -not $_.Name.StartsWith('.') } | Sort-Object Name)) {
        $snaps = @(Get-ChildItem (Join-Path $d.FullName 'reviews') -Filter '*.md' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTimeUtc, Name)
        $sources = @($snaps | ForEach-Object { $_.FullName })
        $latest = Join-Path $d.FullName 'review.md'
        # 最新那份通常就是最後一個快照；內容一樣就不重讀。
        if ((Test-Path $latest) -and -not ($snaps.Count -and [IO.File]::ReadAllText($latest) -eq [IO.File]::ReadAllText($snaps[-1].FullName))) { $sources += $latest }
        if (-not $sources.Count) { continue }
        $snapshots += $snaps.Count
        $seen = [ordered]@{}
        foreach ($s in $sources) {
            foreach ($f in @(Read-ReviewFindings $s)) {
                $key = "$($f.severity)|$($f.file)|$(($f.problem -replace '\s+', ' ').Trim())"
                if ($seen.Contains($key)) { $seen[$key].rounds++; continue }
                $seen[$key] = [ordered]@{ feature = $d.Name; severity = $f.severity; location = $f.location; file = $f.file; problem = $f.problem; failure = $f.failure; rounds = 1 }
            }
        }
        $items = @($seen.Values)
        $features += [ordered]@{ id = $d.Name; rounds = $sources.Count; snapshots = $snaps.Count; findings = $items.Count }
        $all += $items
    }

    $glDir = Join-Path $root 'guidelines'
    $glFiles = @(Get-ChildItem $glDir -Filter '*.md' -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'README.md' } | ForEach-Object { $_.Name } | Sort-Object)
    $ruleIds = @()
    $rules = Read-JsonFile (Join-Path $glDir 'rules.json')
    if ($rules -and $rules.PSObject.Properties['rules']) { $ruleIds = @($rules.rules | ForEach-Object { [string]$_.id } | Where-Object { $_ }) }

    $must = @($all | Where-Object { $_.severity -eq '必修' })
    $script:Data.learn = [ordered]@{
        features   = @($features)
        findings   = @($all)
        counts     = [ordered]@{ features = $features.Count; snapshots = $snapshots; findings = $all.Count; must = $must.Count }
        guidelines = [ordered]@{ files = @($glFiles); ruleIds = @($ruleIds) }
    }

    if (-not $features.Count) {
        Say 'bdd-docs/ 底下還沒有任何審核紀錄（review.md）—— 跑過幾個需求再來。'
        return 0
    }
    Say "讀了 $($features.Count) 個需求的審核紀錄（$snapshots 份每輪快照）：$($all.Count) 項發現，其中 [必修] $($must.Count) 項。"
    $noSnap = @($features | Where-Object { $_.snapshots -eq 0 } | ForEach-Object { $_.id })
    if ($noSnap.Count) { Say "  沒有每輪快照、只看得到最後一輪的：$($noSnap -join '、')（4.19.0 以前跑的；已經修掉的 [必修] 看不到）" }
    foreach ($f in @($must | Select-Object -First 20)) { Say "  [必修] $($f.feature)　$($f.location) —— $($f.problem)" }
    if ($must.Count -gt 20) { Say "  ……另外 $($must.Count - 20) 項（-Json 看全部）" }
    Say '要把一再出現的那幾類寫成規範：在 Codex 裡說「把審核一再抓到的問題整理成規範」—— 它照 skill review-learning 歸類、起草，等你確認才寫進 guidelines/。'
    return 0
}

# ---- 派送 ----
# ---- managed-hooks：給管理員的部署包 ----
# 組織政策只允許管理員部署的 hooks（requirements.toml 的 allow_managed_hooks_only）時，專案的 hooks.json 一律被略過。
# 這裡產出管理員要的兩樣：腳本目錄（派送到 windows_managed_dir／managed_dir 底下；Codex 不替你派送）與
# requirements.toml 的 [[hooks.*]] 片段。事件、matcher、timeout、statusMessage 一律從 hooks.json 抄 —— 不在這裡再寫一份。
# 指令帶 -Managed：managed hooks 對這台機器的每一個 Codex session 都會叫，沒裝工作流的 repo 由腳本自己放行。
# TOML 的字串一律用 ''' 字面字串：Windows 的指令同時有單引號、反斜線與 $，basic string 要逐字跳脫，寫錯就整份政策檔讀不起來。
function Invoke-ManagedHooks {
    if (-not $OutDir) { Warn 'managed-hooks 要給 -OutDir（部署包寫到哪個資料夾）。'; return 2 }
    $hooksPath = Join-Path $Source $HooksRel
    $hooks = Read-JsonFile $hooksPath
    if (-not $hooks -or -not $hooks.hooks) { Warn "讀不到 $hooksPath。"; return 2 }
    $v = Get-ContractVersion $Source
    $pkg = Join-Path $OutDir 'codex-sdlc'
    [void][IO.Directory]::CreateDirectory((Join-Path $pkg 'lib'))
    $scriptsDir = Join-Path $Source '.codex/scripts'
    $copied = @()
    foreach ($n in @($HookScriptNames) + @('dlp-residual-scan')) {
        Copy-Item -LiteralPath (Join-Path $scriptsDir "$n.ps1") -Destination (Join-Path $pkg "$n.ps1") -Force
        $copied += "$n.ps1"
    }
    foreach ($f in @(Get-ChildItem -LiteralPath (Join-Path $scriptsDir 'lib') -Filter '*.ps1' -File)) {
        Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $pkg "lib/$($f.Name)") -Force
        $copied += "lib/$($f.Name)"
    }
    [IO.File]::WriteAllText((Join-Path $pkg 'VERSION'), "$($v.contract)`n", $Utf8NoBom)

    $win = $ManagedDir.TrimEnd('\', '/'); $unix = $UnixManagedDir.TrimEnd('/')
    $lines = [Collections.Generic.List[string]]::new()
    $lines.Add("# Codex SDLC $($v.contract) 的 managed hooks —— 併入 requirements.toml（Windows：%ProgramData%\OpenAI\Codex\requirements.toml）。")
    $lines.Add("# 先把 codex-sdlc\ 整個目錄派送到 $win\codex-sdlc\（macOS／Linux：$unix/codex-sdlc/）；Codex 不會替你派送。")
    $lines.Add('# 沒裝這套工作流的 repo，腳本自己放行（指令帶 -Managed）。專案自己的 hooks.json 若也在跑，每支會跑兩次 —— 只在政策擋掉專案 hooks 時才部署這一份。')
    $lines.Add('#')
    $lines.Add('# 下面三項你們的 requirements.toml 多半已經有；沒有才加（[hooks] 表在 TOML 裡只能出現一次）：')
    $lines.Add('#   allow_managed_hooks_only = true')
    $lines.Add('#   [features]')
    $lines.Add('#   hooks = true')
    $lines.Add('#   [hooks]')
    $lines.Add("#   windows_managed_dir = '$win'")
    $lines.Add("#   managed_dir = '$unix'")
    $count = 0
    foreach ($ev in $hooks.hooks.PSObject.Properties) {
        foreach ($group in @($ev.Value)) {
            foreach ($h in @($group.hooks)) {
                $m = [regex]::Match([string]$h.commandWindows, '(?i)\.codex/scripts/([\w-]+)\.ps1')
                if (-not $m.Success) { Warn "hooks.json 的 $($ev.Name) 有一條認不出腳本：$($h.commandWindows)"; return 2 }
                $name = $m.Groups[1].Value
                $lines.Add('')
                $lines.Add("[[hooks.$($ev.Name)]]")
                if ($group.matcher) { $lines.Add("matcher = '''$($group.matcher)'''") }
                $lines.Add("[[hooks.$($ev.Name).hooks]]")
                $lines.Add('type = "command"')
                $lines.Add("command = '''pwsh -NoProfile -ExecutionPolicy Bypass -File '$unix/codex-sdlc/$name.ps1' -Managed'''")
                $lines.Add("command_windows = '''`$env:PSExecutionPolicyPreference='Bypass'; & '$win\codex-sdlc\$name.ps1' -Managed; exit `$LASTEXITCODE'''")
                if ($h.timeout) { $lines.Add("timeout = $([int]$h.timeout)") }
                if ($h.statusMessage) { $lines.Add("statusMessage = '''$($h.statusMessage)'''") }
                $count++
            }
        }
    }
    $toml = Join-Path $OutDir 'requirements-hooks.toml'
    [IO.File]::WriteAllText($toml, (($lines -join "`n") + "`n"), $Utf8NoBom)
    $script:Data.managedHooks = [ordered]@{ version = [string]$v.contract; package = $pkg; requirements = $toml; hooks = $count; files = $copied; windowsDir = $win; unixDir = $unix }
    Say "managed hooks 部署包（$($v.contract)，$count 條 hook）："
    Say "  腳本：$pkg —— 派送到 $win\codex-sdlc\（macOS／Linux：$unix/codex-sdlc/）"
    Say "  requirements 片段：$toml —— 併入 requirements.toml（檔頭註解說明哪幾項可能已經有）"
    Say '部署後在任一個專案跑 doctor -CheckHookTrust 確認 Codex 載入了；專案升級時用新版重產、重新派送（doctor 會比對版本）。'
    return 0
}

# ---- git-hooks：管理員不部署 managed hooks 時，不靠他也做得到的那一層（4.30.0）----
# allow_managed_hooks_only 管的是 Codex，管不到 git。這裡做兩件事：
#   1. 工作區每個 repo 裝一個 pre-commit，commit 前跑 .codex/scripts/commit-check.ps1（殘留掃描、規範的 block 規則、build）。
#      裝在 git 自己的 hooks 目錄（git rev-parse --git-path）—— 每份 clone 各自一份、不進版控：這是「這台機器的 Codex
#      hooks 跑不起來」的補位，不是整個團隊的設定。repo 已經有自己的 pre-commit、或設了 core.hooksPath（husky、公司統一的
#      hooks）→ 一個字都不動，給一行讓人自己加進去：蓋掉別人的 hook 比沒裝更糟。
#   2. 寫 bdd-docs/.cache/no-codex-hooks：AGENTS.md 叫 orchestrator 看到它就在每次委派前自己跑 handoff-lint -SelfCheck
#      （委派的內容不落地、不經過 git，沒有機械的替代）。
# hook 本身只負責找到工作流、叫 commit-check：規則都在 commit-check 與三支 gate 裡，update 升級它們，hook 不必重裝。
$GitHookMarker = 'codex-sdlc pre-commit'
function Get-GitHookText([string]$root) {
    $hint = ($root -replace '\\', '/') -replace "'", "'\''"
    $t = @'
#!/bin/sh
# codex-sdlc pre-commit —— sdlc.ps1 git-hooks 產生；重跑會更新，git-hooks -Remove 拿掉。
# Codex 的 hooks 跑不起來時（組織政策只允許管理員部署的 hooks），寫檔當下沒有人擋 ——
# commit 前在這裡補跑殘留掃描、規範的 block 規則與 build（.codex/scripts/commit-check.ps1）。
# 先找裝的時候記下的工作流根目錄；移走了就從這個 repo 往上找兩層（工作流裝在上層、前後端各一個 repo）。
top=$(git rev-parse --show-toplevel) || exit 0
hint='{{ROOT}}'
for d in "$hint" "$top" "$(dirname "$top")" "$(dirname "$(dirname "$top")")"; do
  [ -f "$d/.codex/scripts/commit-check.ps1" ] || continue
  if ! command -v pwsh >/dev/null 2>&1; then
    echo "[codex-sdlc] 找不到 pwsh —— commit 前的檢查沒有跑。" >&2
    exit 0
  fi
  cd "$d" || exit 0
  exec pwsh -NoProfile -ExecutionPolicy Bypass -File .codex/scripts/commit-check.ps1 -Repo "$top"
done
echo "[codex-sdlc] 找不到 .codex/scripts/commit-check.ps1 —— commit 前的檢查沒有跑（工作流移走了：重跑 sdlc.ps1 git-hooks；不要了：git-hooks -Remove）。" >&2
exit 0
'@
    return ($t -replace "`r`n", "`n").Replace('{{ROOT}}', $hint)
}

# 已經有自己 pre-commit 的 repo，要人自己加的那一行（括號：cd 不能影響那支 hook 後面的指令）。
function Get-GitHookManualLine([string]$root) {
    return "(cd '$(($root -replace '\\', '/') -replace "'", "'\''")' && pwsh -NoProfile -ExecutionPolicy Bypass -File .codex/scripts/commit-check.ps1 -Repo `"`$(git rev-parse --show-toplevel)`") || exit 1"
}

# 一個 repo 的 pre-commit：installed（是這一版的）｜outdated（是這套裝的、內容不同）｜missing｜foreign（別人的）｜
# hooks-path（設了 core.hooksPath，不歸這裡寫）｜error
function Get-GitHookState([string]$repoDir, [string]$root) {
    $hp = Invoke-GitUtf8 $repoDir @('config', '--get', 'core.hooksPath')
    $hooksPath = if ($hp.ok -and $hp.lines.Count) { [string]$hp.lines[0] } else { $null }
    $gp = Invoke-GitUtf8 $repoDir @('rev-parse', '--git-path', 'hooks/pre-commit')
    if (-not $gp.ok -or -not $gp.lines.Count) { return [ordered]@{ file = $null; status = 'error'; hooksPath = $hooksPath } }
    $file = [string]$gp.lines[0]
    if (-not [IO.Path]::IsPathRooted($file)) { $file = Join-Path $repoDir $file }
    $file = [IO.Path]::GetFullPath($file)
    $status = if (Test-Path -LiteralPath $file -PathType Leaf) {
        $text = [IO.File]::ReadAllText($file) -replace "`r`n", "`n"
        if (-not $text.Contains($GitHookMarker)) { if ($hooksPath) { 'hooks-path' } else { 'foreign' } }
        elseif ($text -eq (Get-GitHookText $root)) { 'installed' }
        else { 'outdated' }
    } elseif ($hooksPath) { 'hooks-path' } else { 'missing' }
    return [ordered]@{ file = $file; status = $status; hooksPath = $hooksPath }
}

function Get-GitHooksStatus([string]$target) {
    $root = (Resolve-Path -LiteralPath $target).Path
    $out = [ordered]@{ marker = (Test-Path -LiteralPath (Join-Path $root $NoHooksMarkerRel) -PathType Leaf); repos = @() }
    if (-not (Get-Command Get-WorkspaceRepos -ErrorAction SilentlyContinue) -or -not (Get-Command git -ErrorAction SilentlyContinue)) { return $out }
    $out.repos = @(foreach ($r in @(Get-WorkspaceRepos $root)) {
        $s = Get-GitHookState $r.dir $root
        [ordered]@{ repo = $(if ($r.rel) { $r.rel } else { '.' }); file = $s.file; status = $s.status; hooksPath = $s.hooksPath }
    })
    return $out
}

# doctor：只報、不算問題（沒有 Codex hooks 的那個問題已經由 Show-HookTrust 算過了）。
function Show-GitHooks($gh) {
    $mine = @($gh.repos | Where-Object { $_.status -in @('installed', 'outdated') })
    if (-not $mine.Count -and -not $gh.marker) { return }
    if ($mine.Count) {
        Say "commit 前的檢查（git-hooks）：裝在 $(@($mine | ForEach-Object { $_.repo }) -join '、')$(if ($mine.Count -lt @($gh.repos).Count) { "（共 $(@($gh.repos).Count) 個 repo）" })。"
    }
    if (@($mine | Where-Object status -eq 'outdated').Count) { Say '  其中有舊版的 pre-commit —— 重跑 sdlc.ps1 git-hooks 更新。' }
    if ($gh.marker) { Say "  $NoHooksMarkerRel 在：orchestrator 每次委派前自己跑 handoff-lint。Codex hooks 能跑了（管理員部署了 managed hooks）就 git-hooks -Remove。" }
    elseif ($mine.Count) { Say "  $NoHooksMarkerRel 不在：orchestrator 不會自己跑 handoff-lint —— Codex hooks 跑不起來的話重跑 sdlc.ps1 git-hooks。" }
}

function Invoke-GitHooks {
    $v = Get-ContractVersion $Target
    if (-not $v) { Warn "$VersionRel 不存在 —— 這裡沒裝工作流（commit-check 要在工作流的根目錄跑）。"; $script:Data.error = 'not-installed'; return 2 }
    $root = (Resolve-Path -LiteralPath $Target).Path
    $marker = Join-Path $root $NoHooksMarkerRel
    $results = @()
    $haveGit = (Get-Command Get-WorkspaceRepos -ErrorAction SilentlyContinue) -and (Get-Command git -ErrorAction SilentlyContinue)
    $repos = if ($haveGit) { @(Get-WorkspaceRepos $root) } else { @() }
    $text = Get-GitHookText $root
    $manual = Get-GitHookManualLine $root
    foreach ($r in $repos) {
        $name = if ($r.rel) { $r.rel } else { '.' }
        $s = Get-GitHookState $r.dir $root
        $res = [ordered]@{ repo = $name; file = $s.file; status = $s.status; hooksPath = $s.hooksPath }
        if ($Remove) {
            if ($s.status -in @('installed', 'outdated')) {
                Remove-Item -LiteralPath $s.file -Force
                $res.status = 'removed'
                Say "${name}：拿掉了 $($s.file)"
            }
        } else {
            switch ($s.status) {
                'installed' { Say "${name}：pre-commit 已經是這一版（$($s.file)）。" }
                { $_ -in @('missing', 'outdated') } {
                    [void][IO.Directory]::CreateDirectory((Split-Path $s.file -Parent))
                    [IO.File]::WriteAllText($s.file, $text, $Utf8NoBom)
                    if (-not ($IsWindows -or $env:OS -eq 'Windows_NT')) {
                        try { [IO.File]::SetUnixFileMode($s.file, [IO.UnixFileMode]'UserRead, UserWrite, UserExecute, GroupRead, GroupExecute, OtherRead, OtherExecute') } catch { }
                    }
                    Say "${name}：$(if ($s.status -eq 'outdated') { '更新了' } else { '裝好了' }) $($s.file)"
                    $res.status = 'installed'
                }
                'foreign' { Warn "${name}：已經有自己的 pre-commit（$($s.file)），沒動它。在它裡面加這一行：$manual" }
                'hooks-path' { Warn "${name}：設了 core.hooksPath（$($s.hooksPath)），git 不讀 .git/hooks，沒動它。在那裡的 pre-commit 加這一行：$manual" }
                default { Warn "${name}：問不到 git 的 hooks 目錄，沒裝。" }
            }
        }
        $results += $res
    }

    if ($Remove) {
        if (Test-Path -LiteralPath $marker) { Remove-Item -LiteralPath $marker -Force; Say "拿掉了 $NoHooksMarkerRel —— orchestrator 不再自己跑 handoff-lint。" }
    } else {
        [void][IO.Directory]::CreateDirectory((Split-Path $marker -Parent))
        [IO.File]::WriteAllText($marker, "這台機器的 Codex hooks 跑不起來（組織政策只允許管理員部署的 hooks）—— sdlc.ps1 git-hooks 寫的。`norchestrator 看到這個檔：每次委派前自己跑 handoff-lint -SelfCheck（AGENTS.md 的「機械強制層」）。`nCodex hooks 能跑了（管理員部署了 managed hooks）：sdlc.ps1 git-hooks -Remove。`n", $Utf8NoBom)
    }
    $script:Data.gitHooks = [ordered]@{ action = $(if ($Remove) { 'remove' } else { 'install' }); root = $root; marker = $NoHooksMarkerRel; markerPresent = (Test-Path -LiteralPath $marker); repos = @($results); manualLine = $manual }
    if ($Remove) { return 0 }

    if (-not $repos.Count) {
        Warn "$(if ($haveGit) { '這裡跟底下兩層都不是 git repo' } else { '找不到 git' }) —— 沒有 pre-commit 可以裝。委派前的 handoff-lint 照樣生效（寫了 $NoHooksMarkerRel）；寫檔那三道只剩 ⑥ 的 delivery-check。"
        $script:Data.error = 'no-git'
        return 2
    }
    $done = @($results | Where-Object status -eq 'installed').Count
    Say "寫了 $NoHooksMarkerRel —— orchestrator 每次委派前會自己跑 handoff-lint（新開的對話才讀得到 AGENTS.md 的這一條）。"
    if ($done) {
        Say "之後每次 commit 會跑 .codex/scripts/commit-check.ps1：殘留掃描、規範的 block 規則、build。git commit --no-verify 跳得過；要沒人跳得過，在 CI 跑：pwsh -NoProfile -File .codex/scripts/commit-check.ps1 -Base origin/main"
    }
    return $(if ($done -eq $repos.Count) { 0 } else { 2 })
}

$code = switch ($Command) {
    'install'      { Invoke-Install }
    'update'       { Invoke-Update }
    'apply'        { Invoke-Apply }
    'set'          { Invoke-Set }
    'check-update' { Invoke-CheckUpdate }
    'fetch'        { Invoke-Fetch }
    'whatsnew'     { Invoke-WhatsNew }
    'tune'         { Invoke-Tune }
    'doctor'       { Invoke-Doctor }
    'models'       { Invoke-Models }
    'learn'        { Invoke-Learn }
    'managed-hooks' { Invoke-ManagedHooks }
    'trust-hooks'   { Invoke-TrustHooks }
    'git-hooks'     { Invoke-GitHooks }
}

if ($Json) {
    [Console]::Out.WriteLine(([ordered]@{
        schema   = $JsonSchema
        command  = $Command
        exit     = $code
        data     = $script:Data
        warnings = @($script:Warnings)
        output   = @($script:Notes)
    } | ConvertTo-Json -Depth 10 -Compress))
}
exit $code
